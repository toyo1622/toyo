package com.eastweather.app

import android.app.Activity
import android.app.AlertDialog
import android.Manifest
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.google.firebase.FirebaseException
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.time.Duration
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sqrt

class MainActivity : Activity() {

    data class AreaDef(
        val name: String,
        val zh: String,
        val lat: Double,
        val lon: Double,
        val country: String = "SG",
        val group: String = "Singapore"
    )
    data class Station(val id: String, val name: String, val lat: Double, val lon: Double)
    data class ReadingSet(
        val timestamp: String,
        val stations: List<Station>,
        val values: Map<String, Double>,
        val unit: String
    )
    data class ModelPoint(
        val time: ZonedDateTime,
        val probability: Double,
        val rainMm: Double,
        val tempC: Double,
        val windKmh: Double,
        val gustKmh: Double
    )
    data class ModelSeries(val model: String, val points: List<ModelPoint>)
    data class BlockResult(
        val time: ZonedDateTime,
        val severity: Int,
        val probability: Double,
        val rainMm: Double,
        val tempC: Double,
        val windKmh: Double,
        val gustKmh: Double,
        val confidence: String,
        val modelCount: Int
    )
    data class AreaResult(
        val area: AreaDef,
        val forecastRaw: String,
        val tempC: Double,
        val rainMm: Double,
        val windKmh: Double,
        val rainStation: String,
        val blocks: List<BlockResult>,
        val adviceLevel: Int
    )

    private val prefs by lazy { getSharedPreferences("hi_rider", MODE_PRIVATE) }
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val analytics by lazy { FirebaseAnalytics.getInstance(this) }

    private var isDark = false
    private var isZh = false
    private var bgColor = Color.rgb(244, 247, 250)
    private var cardColor = Color.WHITE
    private var textColor = Color.rgb(25, 38, 50)
    private var subTextColor = Color.rgb(89, 103, 117)
    private var mutedColor = Color.rgb(230, 235, 240)
    private var accentColor = Color.rgb(23, 91, 138)

    private lateinit var root: LinearLayout
    private lateinit var regionContainer: LinearLayout
    private lateinit var selectedText: TextView
    private lateinit var refreshButton: Button
    private lateinit var statusText: TextView

    private var verificationId: String? = null
    private var resendToken: PhoneAuthProvider.ForceResendingToken? = null
    private var loginPhone: String = ""

    // Singapore keeps the existing NEA/MSS + observation-station logic.
    // Malaysia uses a separate model-only path so it never attaches to a Singapore NEA station.
    private val singaporeAreas = listOf(
        AreaDef("Ang Mo Kio", "宏茂桥", 1.375, 103.839),
        AreaDef("Bedok", "勿洛", 1.321, 103.924),
        AreaDef("Bishan", "碧山", 1.350772, 103.839),
        AreaDef("Boon Lay", "文礼", 1.304, 103.701),
        AreaDef("Bukit Batok", "武吉巴督", 1.353, 103.754),
        AreaDef("Bukit Merah", "红山", 1.277, 103.819),
        AreaDef("Bukit Panjang", "武吉班让", 1.362, 103.77195),
        AreaDef("Bukit Timah", "武吉知马", 1.325, 103.791),
        AreaDef("Central Water Catchment", "中央集水区", 1.38, 103.805),
        AreaDef("Changi", "樟宜", 1.357, 103.987),
        AreaDef("Choa Chu Kang", "蔡厝港", 1.377, 103.745),
        AreaDef("City", "市中心", 1.292, 103.844),
        AreaDef("Clementi", "金文泰", 1.315, 103.76),
        AreaDef("Geylang", "芽笼", 1.318, 103.884),
        AreaDef("Hougang", "后港", 1.361218, 103.886),
        AreaDef("Jalan Bahar", "惹兰巴哈", 1.347, 103.67),
        AreaDef("Jurong East", "裕廊东", 1.326, 103.737),
        AreaDef("Jurong Island", "裕廊岛", 1.266, 103.699),
        AreaDef("Jurong West", "裕廊西", 1.34039, 103.705),
        AreaDef("Kallang", "加冷", 1.312, 103.862),
        AreaDef("Lim Chu Kang", "林厝港", 1.423, 103.717332),
        AreaDef("Mandai", "万礼", 1.419, 103.812),
        AreaDef("Marine Parade", "马林百列", 1.297, 103.891),
        AreaDef("Novena", "诺维娜", 1.327, 103.826),
        AreaDef("Pasir Ris", "巴西立", 1.37, 103.948),
        AreaDef("Paya Lebar", "巴耶利峇", 1.358, 103.914),
        AreaDef("Pioneer", "先驱", 1.315, 103.675),
        AreaDef("Pulau Tekong", "德光岛", 1.403, 104.053),
        AreaDef("Pulau Ubin", "乌敏岛", 1.404, 103.96),
        AreaDef("Punggol", "榜鹅", 1.401, 103.904),
        AreaDef("Queenstown", "女皇镇", 1.291, 103.78576),
        AreaDef("Seletar", "实里达", 1.404, 103.869),
        AreaDef("Sembawang", "三巴旺", 1.445, 103.818495),
        AreaDef("Sengkang", "盛港", 1.384, 103.891443),
        AreaDef("Sentosa", "圣淘沙", 1.243, 103.832),
        AreaDef("Serangoon", "实龙岗", 1.357, 103.865),
        AreaDef("Southern Islands", "南部岛屿", 1.208, 103.842),
        AreaDef("Sungei Kadut", "双溪加株", 1.413, 103.756),
        AreaDef("Tampines", "淡滨尼", 1.345, 103.944),
        AreaDef("Tanglin", "东陵", 1.308, 103.813),
        AreaDef("Tengah", "登加", 1.374, 103.715),
        AreaDef("Toa Payoh", "大巴窑", 1.334304, 103.856327),
        AreaDef("Tuas", "大士", 1.294947, 103.635),
        AreaDef("Western Islands", "西部岛屿", 1.205926, 103.746),
        AreaDef("Western Water Catchment", "西部集水区", 1.405, 103.689),
        AreaDef("Woodlands", "兀兰", 1.432, 103.786528),
        AreaDef("Yishun", "义顺", 1.418, 103.839)
    )

    private val malaysiaAreas = listOf(
        // Johor - all 10 districts plus major rider towns / corridors
        AreaDef("Johor Bahru", "新山", 1.4927, 103.7414, "MY", "Johor"),
        AreaDef("Skudai", "士姑来", 1.5374, 103.6578, "MY", "Johor"),
        AreaDef("Ulu Tiram", "乌鲁地南", 1.6006, 103.8161, "MY", "Johor"),
        AreaDef("Iskandar Puteri", "依斯干达公主城", 1.4200, 103.6300, "MY", "Johor"),
        AreaDef("Gelang Patah", "振林山", 1.4462, 103.5960, "MY", "Johor"),
        AreaDef("Pasir Gudang", "巴西古当", 1.4700, 103.9020, "MY", "Johor"),
        AreaDef("Masai", "马赛", 1.4854, 103.8771, "MY", "Johor"),
        AreaDef("Senai", "士乃", 1.6006, 103.6419, "MY", "Johor"),
        AreaDef("Kulai", "古来", 1.6560, 103.6030, "MY", "Johor"),
        AreaDef("Pontian", "笨珍", 1.4866, 103.3896, "MY", "Johor"),
        AreaDef("Pekan Nanas", "北干那那", 1.5153, 103.5137, "MY", "Johor"),
        AreaDef("Kota Tinggi", "哥打丁宜", 1.7381, 103.8999, "MY", "Johor"),
        AreaDef("Desaru", "迪沙鲁", 1.5797, 104.2436, "MY", "Johor"),
        AreaDef("Pengerang", "边佳兰", 1.3660, 104.1180, "MY", "Johor"),
        AreaDef("Kluang", "居銮", 2.0300, 103.3210, "MY", "Johor"),
        AreaDef("Simpang Renggam", "新邦令金", 1.8275, 103.3117, "MY", "Johor"),
        AreaDef("Ayer Hitam", "亚依淡", 1.9183, 103.1769, "MY", "Johor"),
        AreaDef("Batu Pahat", "峇株巴辖", 1.8548, 102.9325, "MY", "Johor"),
        AreaDef("Parit Raja", "巴力拉惹", 1.8687, 103.1120, "MY", "Johor"),
        AreaDef("Rengit", "龙引", 1.6817, 103.1364, "MY", "Johor"),
        AreaDef("Yong Peng", "永平", 2.0136, 103.0653, "MY", "Johor"),
        AreaDef("Muar", "麻坡", 2.0442, 102.5689, "MY", "Johor"),
        AreaDef("Tangkak", "东甲", 2.2673, 102.5453, "MY", "Johor"),
        AreaDef("Segamat", "昔加末", 2.5148, 102.8158, "MY", "Johor"),
        AreaDef("Labis", "拉美士", 2.3850, 103.0210, "MY", "Johor"),
        AreaDef("Chaah", "三合港", 2.2492, 103.0484, "MY", "Johor"),
        AreaDef("Mersing", "丰盛港", 2.4312, 103.8405, "MY", "Johor"),
        AreaDef("Endau", "兴楼", 2.6560, 103.6230, "MY", "Johor"),

        // Kuala Lumpur
        AreaDef("Kuala Lumpur", "吉隆坡", 3.1390, 101.6869, "MY", "Kuala Lumpur"),
        AreaDef("KLCC", "吉隆坡城中城", 3.1579, 101.7116, "MY", "Kuala Lumpur"),
        AreaDef("Cheras", "蕉赖", 3.1073, 101.7257, "MY", "Kuala Lumpur"),
        AreaDef("Kepong", "甲洞", 3.2140, 101.6350, "MY", "Kuala Lumpur"),
        AreaDef("Setapak", "文良港", 3.1880, 101.7100, "MY", "Kuala Lumpur"),
        AreaDef("Bukit Jalil", "武吉加里尔", 3.0580, 101.6910, "MY", "Kuala Lumpur"),

        // Selangor / Putrajaya - important family + Klang Valley coverage
        AreaDef("Serdang", "沙登", 2.9920, 101.7160, "MY", "Selangor"),
        AreaDef("Seri Kembangan", "史里肯邦安", 3.0260, 101.7050, "MY", "Selangor"),
        AreaDef("Cyberjaya", "赛城", 2.9213, 101.6559, "MY", "Selangor"),
        AreaDef("Petaling Jaya", "八打灵再也", 3.1073, 101.6067, "MY", "Selangor"),
        AreaDef("Shah Alam", "莎阿南", 3.0738, 101.5183, "MY", "Selangor"),
        AreaDef("Subang Jaya", "梳邦再也", 3.0430, 101.5800, "MY", "Selangor"),
        AreaDef("Puchong", "蒲种", 3.0327, 101.6188, "MY", "Selangor"),
        AreaDef("Kajang", "加影", 2.9935, 101.7880, "MY", "Selangor"),
        AreaDef("Bangi", "万宜", 2.9210, 101.7740, "MY", "Selangor"),
        AreaDef("Ampang", "安邦", 3.1491, 101.7610, "MY", "Selangor"),
        AreaDef("Klang", "巴生", 3.0449, 101.4456, "MY", "Selangor"),
        AreaDef("Putrajaya", "布城", 2.9264, 101.6964, "MY", "Putrajaya")
    )

    private val areas = singaporeAreas + malaysiaAreas

    private val defaultNames = listOf("Tampines", "Pasir Ris", "Bedok", "Paya Lebar", "Changi", "City")

    override fun onCreate(savedInstanceState: Bundle?) {
        val p = getSharedPreferences("hi_rider", MODE_PRIVATE)
        isDark = p.getString("theme", "light") == "dark"
        isZh = p.getString("language", "en") == "zh"
        setTheme(if (isDark) R.style.AppThemeDark else R.style.AppThemeLight)
        super.onCreate(savedInstanceState)
        applyPalette()

        // Require Firebase Phone OTP for new users. Existing signed-in users can enter directly.
        if (auth.currentUser != null) {
            showMain()
        } else {
            showLogin()
        }
    }

    private fun applyPalette() {
        if (isDark) {
            bgColor = Color.rgb(17, 24, 32)
            cardColor = Color.rgb(29, 39, 49)
            textColor = Color.rgb(240, 244, 248)
            subTextColor = Color.rgb(176, 189, 201)
            mutedColor = Color.rgb(48, 61, 73)
            accentColor = Color.rgb(91, 174, 230)
        } else {
            bgColor = Color.rgb(244, 247, 250)
            cardColor = Color.WHITE
            textColor = Color.rgb(25, 38, 50)
            subTextColor = Color.rgb(89, 103, 117)
            mutedColor = Color.rgb(230, 235, 240)
            accentColor = Color.rgb(23, 91, 138)
        }
        window.statusBarColor = bgColor
        window.navigationBarColor = bgColor
    }

    private fun t(en: String, zh: String): String = if (isZh) zh else en

    // ---------------------- Firebase Phone OTP ----------------------

    private fun showLogin() {
        auth.setLanguageCode(if (isZh) "zh" else "en")

        val scroll = ScrollView(this).apply { setBackgroundColor(bgColor) }
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(42), dp(24), dp(32))
        }
        scroll.addView(wrap, LinearLayout.LayoutParams(-1, -2))

        val title = TextView(this).apply {
            text = "Hi Rider v0.8"
            textSize = 30f
            setTextColor(textColor)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        wrap.addView(title)

        val subtitle = TextView(this).apply {
            text = t(
                "Sign in with your phone number to continue.",
                "使用手机号码登录后才可以继续。"
            )
            textSize = 16f
            setTextColor(subTextColor)
            setPadding(0, dp(8), 0, dp(22))
        }
        wrap.addView(subtitle)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(cardColor, 18f)
        }
        wrap.addView(box, LinearLayout.LayoutParams(-1, -2))

        val phoneLabel = label(t("Phone number", "手机号码"))
        box.addView(phoneLabel)

        val phoneInput = EditText(this).apply {
            hint = "+65 91234567 / +60 ..."
            setTextColor(textColor)
            setHintTextColor(subTextColor)
            inputType = InputType.TYPE_CLASS_PHONE
            textSize = 18f
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            backgroundTintList = ColorStateList.valueOf(accentColor)
        }
        box.addView(phoneInput, LinearLayout.LayoutParams(-1, -2))

        val sendButton = Button(this).apply {
            text = t("Send OTP", "发送验证码")
            styleButton(this)
        }
        box.addView(sendButton, marginTop(12))

        val otpInput = EditText(this).apply {
            hint = t("6-digit OTP", "6位验证码")
            setTextColor(textColor)
            setHintTextColor(subTextColor)
            inputType = InputType.TYPE_CLASS_NUMBER
            textSize = 20f
            setSingleLine(true)
            visibility = View.GONE
            setPadding(dp(12), dp(10), dp(12), dp(10))
            backgroundTintList = ColorStateList.valueOf(accentColor)
        }
        box.addView(otpInput, marginTop(14))

        val verifyButton = Button(this).apply {
            text = t("Verify & enter", "验证并进入")
            styleButton(this)
            visibility = View.GONE
        }
        box.addView(verifyButton, marginTop(10))

        val resendButton = Button(this).apply {
            text = t("Resend OTP", "重新发送验证码")
            setAllCaps(false)
            setTextColor(accentColor)
            backgroundTintList = ColorStateList.valueOf(if (isDark) Color.rgb(40, 52, 64) else Color.rgb(236, 244, 250))
            visibility = View.GONE
        }
        box.addView(resendButton, marginTop(8))

        val loginStatus = TextView(this).apply {
            textSize = 14f
            setTextColor(subTextColor)
            setPadding(0, dp(14), 0, 0)
        }
        box.addView(loginStatus)

        val privacy = TextView(this).apply {
            text = t(
                "Your phone number is used for Firebase sign-in/account records. Hi Rider Analytics records app usage, not your phone number.",
                "手机号码只用于 Firebase 登录及账户记录。Hi Rider 的使用统计不会把你的手机号码作为分析资料发送。"
            )
            textSize = 13f
            setTextColor(subTextColor)
            setPadding(0, dp(18), 0, 0)
        }
        wrap.addView(privacy)

        val language = Button(this).apply {
            text = if (isZh) "English" else "中文"
            setAllCaps(false)
            setTextColor(accentColor)
            backgroundTintList = ColorStateList.valueOf(if (isDark) Color.rgb(40, 52, 64) else Color.rgb(236, 244, 250))
            setOnClickListener {
                isZh = !isZh
                prefs.edit().putString("language", if (isZh) "zh" else "en").apply()
                recreate()
            }
        }
        wrap.addView(language, marginTop(18))

        fun requestOtp(force: Boolean) {
            val normalized = normalizePhone(phoneInput.text.toString())
            if (!normalized.matches(Regex("^\\+[1-9]\\d{7,14}$"))) {
                loginStatus.text = t(
                    "Enter a valid international phone number, for example +65 91234567.",
                    "请输入正确的国际手机号码，例如 +65 91234567。"
                )
                return
            }
            loginPhone = normalized
            sendButton.isEnabled = false
            resendButton.isEnabled = false
            loginStatus.text = t("Sending OTP…", "正在发送验证码…")

            val builder = PhoneAuthOptions.newBuilder(auth)
                .setPhoneNumber(normalized)
                .setTimeout(60L, TimeUnit.SECONDS)
                .setActivity(this)
                .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                    override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                        loginStatus.text = t("Number verified. Signing in…", "号码已验证，正在登录…")
                        signInWithCredential(credential, loginStatus)
                    }

                    override fun onVerificationFailed(e: FirebaseException) {
                        sendButton.isEnabled = true
                        resendButton.isEnabled = true
                        loginStatus.text = t("OTP failed: ", "验证码发送失败：") + friendlyAuthError(e)
                    }

                    override fun onCodeSent(
                        id: String,
                        token: PhoneAuthProvider.ForceResendingToken
                    ) {
                        verificationId = id
                        resendToken = token
                        otpInput.visibility = View.VISIBLE
                        verifyButton.visibility = View.VISIBLE
                        resendButton.visibility = View.VISIBLE
                        sendButton.isEnabled = true
                        resendButton.isEnabled = true
                        loginStatus.text = t(
                            "OTP sent. Enter the 6-digit code.",
                            "验证码已发送，请输入6位验证码。"
                        )
                    }
                })

            if (force && resendToken != null) builder.setForceResendingToken(resendToken!!)
            PhoneAuthProvider.verifyPhoneNumber(builder.build())
        }

        sendButton.setOnClickListener { requestOtp(false) }
        resendButton.setOnClickListener { requestOtp(true) }
        verifyButton.setOnClickListener {
            val id = verificationId
            val code = otpInput.text.toString().trim()
            if (id.isNullOrBlank() || code.length < 6) {
                loginStatus.text = t("Enter the 6-digit OTP first.", "请先输入6位验证码。")
            } else {
                verifyButton.isEnabled = false
                loginStatus.text = t("Checking OTP…", "正在验证验证码…")
                val credential = PhoneAuthProvider.getCredential(id, code)
                signInWithCredential(credential, loginStatus) { verifyButton.isEnabled = true }
            }
        }

        setContentView(scroll)
    }

    private fun signInWithCredential(
        credential: PhoneAuthCredential,
        status: TextView,
        onDone: (() -> Unit)? = null
    ) {
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                onDone?.invoke()
                if (task.isSuccessful) {
                    val b = Bundle().apply {
                        putString(FirebaseAnalytics.Param.METHOD, "phone")
                    }
                    analytics.logEvent(FirebaseAnalytics.Event.LOGIN, b)
                    Toast.makeText(this, t("Login successful", "登录成功"), Toast.LENGTH_SHORT).show()
                    showMain()
                } else {
                    status.text = t("Verification failed: ", "验证失败：") +
                        friendlyAuthError(task.exception ?: Exception("Unknown error"))
                }
            }
    }

    private fun friendlyAuthError(e: Throwable): String {
        val raw = e.message ?: e.javaClass.simpleName
        return raw.take(180)
    }

    private fun normalizePhone(raw: String): String {
        val clean = raw.trim().replace(Regex("[\\s()\\-]"), "")
        if (clean.startsWith("+")) return clean
        return if (clean.length == 8 && clean.all { it.isDigit() }) "+65$clean" else clean
    }

    // ---------------------- Main weather screen ----------------------

    private fun showMain() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bgColor)
            isFillViewport = true
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(32))
        }
        scroll.addView(root, LinearLayout.LayoutParams(-1, -2))
        setContentView(scroll)

        syncWeatherAlertSchedule()
        maybeRequestNotificationPermission()

        buildHeader()
        buildControls()

        statusText = TextView(this).apply {
            text = t("Preparing", "准备中")
            textSize = 14f
            setTextColor(subTextColor)
            setPadding(dp(4), dp(12), dp(4), dp(8))
        }
        root.addView(statusText)

        regionContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        root.addView(regionContainer, LinearLayout.LayoutParams(-1, -2))

        val note = TextView(this).apply {
            text = t(
                "Select up to 6 areas. Singapore keeps NEA/MSS + nearby stations; Malaysia uses a separate ECMWF/GFS/ICON model layer. Tap an area for hourly details.",
                "最多选择6个地区。新加坡继续使用 NEA/MSS + 附近观测站；马来西亚使用独立的 ECMWF/GFS/ICON 多模型资料。点击地区查看逐小时详情。"
            )
            textSize = 12.5f
            setTextColor(subTextColor)
            setPadding(dp(4), dp(18), dp(4), dp(6))
        }
        root.addView(note)

        load()
    }

    private fun buildHeader() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val title = TextView(this).apply {
            text = "Hi Rider"
            textSize = 28f
            setTextColor(textColor)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val subtitle = TextView(this).apply {
            text = t("Weather companion for riders", "骑士天气助手")
            textSize = 14f
            setTextColor(subTextColor)
        }
        titleWrap.addView(title)
        titleWrap.addView(subtitle)
        row.addView(titleWrap, LinearLayout.LayoutParams(0, -2, 1f))

        val settings = Button(this).apply {
            text = "⚙"
            textSize = 20f
            contentDescription = t("Settings", "设置")
            setAllCaps(false)
            setTextColor(textColor)
            backgroundTintList = ColorStateList.valueOf(if (isDark) Color.rgb(40, 52, 64) else Color.rgb(232, 238, 244))
            setOnClickListener { showSettings() }
        }
        row.addView(settings, LinearLayout.LayoutParams(dp(58), dp(52)))
        root.addView(row)
    }

    private fun buildControls() {
        selectedText = TextView(this).apply {
            textSize = 14f
            setTextColor(subTextColor)
            setPadding(0, dp(18), 0, dp(8))
        }
        root.addView(selectedText)
        updateSelectedLabel()

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val chooseButton = Button(this).apply {
            text = t("Choose areas", "选择地区")
            styleButton(this)
            setOnClickListener { showAreaPicker() }
        }
        refreshButton = Button(this).apply {
            text = t("Refresh", "刷新")
            styleButton(this)
            setOnClickListener { load() }
        }
        controls.addView(chooseButton, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        controls.addView(refreshButton, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        root.addView(controls)
    }

    private fun selectedAreas(): List<AreaDef> {
        val saved = prefs.getString("selected_areas", null)
        val names = if (saved.isNullOrBlank()) defaultNames else saved.split("|").filter { it.isNotBlank() }
        val selected = names.mapNotNull { n -> areas.firstOrNull { it.name == n } }
        return if (selected.isEmpty()) areas.filter { it.name in defaultNames } else selected.take(6)
    }

    private fun selectedNames(): List<String> = selectedAreas().map { if (isZh) it.zh else it.name }

    private fun updateSelectedLabel() {
        selectedText.text = t("Selected: ", "已选：") + selectedNames().joinToString(", ")
    }

    private fun showAreaPicker() {
        val countries = arrayOf(
            "🇸🇬 " + t("Singapore", "新加坡"),
            "🇲🇾 " + t("Malaysia", "马来西亚")
        )
        AlertDialog.Builder(this)
            .setTitle(t("Choose country", "选择国家"))
            .setItems(countries) { _, which ->
                showCountryAreaPicker(if (which == 0) "SG" else "MY")
            }
            .setNegativeButton(t("Cancel", "取消"), null)
            .show()
    }

    private fun showCountryAreaPicker(country: String) {
        val countryAreas = areas.filter { it.country == country }
        val current = selectedAreas().map { it.name }.toMutableSet()
        val otherCount = selectedAreas().count { it.country != country }
        val labels = countryAreas.map { a ->
            val groupPrefix = if (country == "MY") "${a.group} · " else ""
            groupPrefix + if (isZh) a.zh else a.name
        }.toTypedArray()
        val checked = BooleanArray(countryAreas.size) { countryAreas[it].name in current }
        val title = if (country == "SG") {
            t("Singapore areas (max 6 total)", "新加坡地区（总共最多6个）")
        } else {
            t("Malaysia areas (max 6 total)", "马来西亚地区（总共最多6个）")
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setMultiChoiceItems(labels, checked) { dlg, which, isChecked ->
                checked[which] = isChecked
                if (otherCount + checked.count { it } > 6) {
                    checked[which] = false
                    (dlg as AlertDialog).listView.setItemChecked(which, false)
                    Toast.makeText(this, t("You can select up to 6 areas", "最多只能选择6个地区"), Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(t("Back", "返回")) { _, _ -> showAreaPicker() }
            .setPositiveButton(t("Save", "保存"), null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val pickedThisCountry = countryAreas.filterIndexed { index, _ -> dialog.listView.isItemChecked(index) }
                val preservedOtherCountry = selectedAreas().filter { it.country != country }
                val combined = (preservedOtherCountry + pickedThisCountry).distinctBy { it.name }.take(6)
                if (combined.isEmpty()) {
                    Toast.makeText(this, t("Select at least 1 area", "至少选择1个地区"), Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                prefs.edit().putString("selected_areas", combined.joinToString("|") { it.name }).apply()
                updateSelectedLabel()
                syncWeatherAlertSchedule()
                dialog.dismiss()
                load()
            }
        }
        dialog.show()
    }

    private fun showSettings() {
        val alertsOn = prefs.getBoolean("weather_alerts", true)
        val items = arrayOf(
            t("Areas (${selectedAreas().size})", "地区（${selectedAreas().size}）"),
            t("Forecast start time", "预报开始时间"),
            t("Weather alerts: ", "天气预警：") + if (alertsOn) t("On", "开启") else t("Off", "关闭"),
            t("Language: English", "语言：中文"),
            t("Theme: ", "主题：") + if (isDark) t("Dark", "深色") else t("Light", "浅色"),
            t("About Hi Rider", "关于 Hi Rider")
        )
        AlertDialog.Builder(this)
            .setTitle(t("Settings", "设置"))
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showAreaPicker()
                    1 -> showForecastTimeDialog()
                    2 -> showWeatherAlertDialog()
                    3 -> showLanguageDialog()
                    4 -> showThemeDialog()
                    5 -> showAbout()
                }
            }
            .setNegativeButton(t("Close", "关闭"), null)
            .show()
    }

    private fun showForecastTimeDialog() {
        val hours = (6..23).toList().toIntArray()
        val labels = hours.map { formatHourLabel(it) }.toTypedArray()
        val current = prefs.getInt("forecast_start_hour", 6).coerceIn(6, 23)
        AlertDialog.Builder(this)
            .setTitle(t("Forecast start time", "预报开始时间"))
            .setSingleChoiceItems(labels, hours.indexOf(current)) { dialog, index ->
                prefs.edit().putInt("forecast_start_hour", hours[index]).apply()
                dialog.dismiss()
                load()
            }
            .show()
    }

    private fun showWeatherAlertDialog() {
        val labels = arrayOf(t("On", "开启"), t("Off", "关闭"))
        val enabled = prefs.getBoolean("weather_alerts", true)
        AlertDialog.Builder(this)
            .setTitle(t("Weather alerts", "天气预警"))
            .setMessage(t(
                "Checks selected areas about once per hour and warns for likely rain or strong gusts in the next hour.",
                "大约每小时检查一次已选地区，如下一小时可能下雨或出现强阵风，就发出提醒。"
            ))
            .setSingleChoiceItems(labels, if (enabled) 0 else 1) { dialog, which ->
                val turnOn = which == 0
                prefs.edit().putBoolean("weather_alerts", turnOn).apply()
                if (turnOn) ensureNotificationPermission()
                syncWeatherAlertSchedule()
                dialog.dismiss()
            }
            .show()
    }

    private fun maybeRequestNotificationPermission() {
        if (!prefs.getBoolean("weather_alerts", true)) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        if (prefs.getBoolean("notification_permission_asked", false)) return
        prefs.edit().putBoolean("notification_permission_asked", true).apply()
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1008)
    }

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1008)
        }
    }

    private fun serializeSelectedAreas(): String {
        val arr = JSONArray()
        selectedAreas().forEach { area ->
            arr.put(JSONObject().apply {
                put("name", area.name)
                put("zh", area.zh)
                put("lat", area.lat)
                put("lon", area.lon)
                put("country", area.country)
            })
        }
        return arr.toString()
    }

    private fun syncWeatherAlertSchedule() {
        val manager = WorkManager.getInstance(applicationContext)
        if (!prefs.getBoolean("weather_alerts", true)) {
            manager.cancelUniqueWork("hirider-weather-alerts")
            return
        }

        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val input = Data.Builder()
            .putString("areas_json", serializeSelectedAreas())
            .putString("language", if (isZh) "zh" else "en")
            .build()
        val request = PeriodicWorkRequestBuilder<WeatherAlertWorker>(1, TimeUnit.HOURS)
            .setConstraints(constraints)
            .setInputData(input)
            .build()

        manager.enqueueUniquePeriodicWork(
            "hirider-weather-alerts",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    private fun showLanguageDialog() {
        val labels = arrayOf("English", "中文")
        AlertDialog.Builder(this)
            .setTitle(t("Choose Language", "选择语言"))
            .setSingleChoiceItems(labels, if (isZh) 1 else 0) { dialog, which ->
                prefs.edit().putString("language", if (which == 1) "zh" else "en").apply()
                dialog.dismiss()
                recreate()
            }
            .show()
    }

    private fun showThemeDialog() {
        val labels = arrayOf(t("Light", "浅色"), t("Dark", "深色"))
        AlertDialog.Builder(this)
            .setTitle(t("Choose Theme", "选择主题"))
            .setSingleChoiceItems(labels, if (isDark) 1 else 0) { dialog, which ->
                prefs.edit().putString("theme", if (which == 1) "dark" else "light").apply()
                dialog.dismiss()
                recreate()
            }
            .show()
    }

    private fun showAbout() {
        AlertDialog.Builder(this)
            .setTitle(t("About Hi Rider", "关于 Hi Rider"))
            .setMessage(
                t(
                    "Hi Rider v0.8\n\nHi Rider is a practical companion for riders. Phone OTP is required whenever there is no active Firebase sign-in session. Firebase Analytics remains enabled for usage statistics.\n\nSingapore: NEA/MSS + ECMWF/GFS/ICON. Malaysia: separate ECMWF/GFS/ICON layer.",
                    "Hi Rider v0.8\n\nHi Rider 是给骑士使用的实用助手。没有有效 Firebase 登录状态时，必须使用手机 OTP 登录；Firebase Analytics 使用统计继续保留。\n\n新加坡：NEA/MSS + ECMWF/GFS/ICON。马来西亚：独立 ECMWF/GFS/ICON 多模型资料层。"
                )
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun confirmSignOut() {
        AlertDialog.Builder(this)
            .setTitle(t("Sign out", "退出登录"))
            .setMessage(t("You will need OTP to enter again.", "下次进入时需要重新使用验证码登录。"))
            .setNegativeButton(t("Cancel", "取消"), null)
            .setPositiveButton(t("Sign out", "退出")) { _, _ ->
                auth.signOut()
                showLogin()
            }
            .show()
    }

    private fun load() {
        refreshButton.isEnabled = false
        statusText.text = t(
            "Loading official and multi-model data for ${selectedAreas().size} areas…",
            "正在载入 ${selectedAreas().size} 个地区的官方及多模型天气资料…"
        )
        regionContainer.removeAllViews()
        val loading = card(t("Rider Weather Overview\n\nCalculating…", "骑士天气总览\n\n计算中…"))
        regionContainer.addView(loading)

        analytics.logEvent("weather_refresh", Bundle().apply {
            putLong("area_count", selectedAreas().size.toLong())
        })

        Thread {
            try {
                val selected = selectedAreas()
                val hasSingapore = selected.any { it.country == "SG" }
                val emptyRain = ReadingSet("", emptyList(), emptyMap(), "mm")
                val emptyTemp = ReadingSet("", emptyList(), emptyMap(), "°C")
                val emptyWind = ReadingSet("", emptyList(), emptyMap(), "km/h")

                // Only Singapore areas call Singapore official APIs. Malaysia never uses SG stations.
                val nea = if (hasSingapore) {
                    runCatching { fetchTwoHourForecast() }.getOrElse { Triple(emptyMap(), "", "") }
                } else Triple(emptyMap(), "", "")
                val rain = if (hasSingapore) runCatching {
                    fetchReading("https://api-open.data.gov.sg/v2/real-time/api/rainfall", "mm")
                }.getOrElse { emptyRain } else emptyRain
                val temp = if (hasSingapore) runCatching {
                    fetchReading("https://api-open.data.gov.sg/v2/real-time/api/air-temperature", "°C")
                }.getOrElse { emptyTemp } else emptyTemp
                val wind = if (hasSingapore) runCatching {
                    fetchReading("https://api-open.data.gov.sg/v2/real-time/api/wind-speed", "km/h")
                }.getOrElse { emptyWind } else emptyWind

                val targets = targetTimes()
                val results = selected.map { area ->
                    val ecmwf = runCatching { fetchModel(area, "ecmwf_ifs025") }.getOrNull()
                    val gfs = runCatching { fetchModel(area, "ncep_gfs_global") }.getOrNull()
                    val icon = runCatching { fetchModel(area, "icon_global") }.getOrNull()
                    val isSingapore = area.country == "SG"
                    buildAreaResult(
                        area = area,
                        forecast = if (isSingapore) nea.first[area.name].orEmpty() else "",
                        rain = if (isSingapore) rain else emptyRain,
                        temp = if (isSingapore) temp else emptyTemp,
                        wind = if (isSingapore) wind else emptyWind,
                        series = listOfNotNull(ecmwf, gfs, icon),
                        targets = targets
                    )
                }

                runOnUiThread {
                    renderResults(results, nea.second, rain.timestamp)
                    refreshButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    regionContainer.removeAllViews()
                    regionContainer.addView(
                        card(
                            t(
                                "Unable to complete the assessment\n\nNetwork or weather data unavailable.\nPlease tap Refresh and try again later.\n\n${e.message ?: ""}",
                                "无法完成天气评估\n\n网络或天气资料暂时不可用。\n请稍后按刷新再试。\n\n${e.message ?: ""}"
                            )
                        )
                    )
                    statusText.text = t("Update failed", "更新失败")
                    refreshButton.isEnabled = true
                }
            }
        }.start()
    }

    private fun renderResults(results: List<AreaResult>, neaUpdated: String, rainUpdated: String) {
        regionContainer.removeAllViews()
        if (results.isEmpty()) {
            regionContainer.addView(card(t("No weather data available", "暂时没有天气资料")))
            return
        }

        val red = results.filter { it.adviceLevel >= 2 }
        val yellow = results.filter { it.adviceLevel == 1 }
        val green = results.filter { it.adviceLevel == 0 }

        val summary = buildString {
            append(t("Rider Weather Overview", "骑士天气总览"))
            append("\n\n")
            if (red.isNotEmpty()) {
                append("🔴 ").append(t("Not recommended: ", "不建议："))
                append(red.joinToString(", ") { areaLabel(it.area) }).append("\n")
            }
            if (yellow.isNotEmpty()) {
                append("🟡 ").append(t("Monitor: ", "先观察："))
                append(yellow.joinToString(", ") { areaLabel(it.area) }).append("\n")
            }
            if (green.isNotEmpty()) {
                append("🟢 ").append(t("Good to go: ", "可以出发："))
                append(green.joinToString(", ") { areaLabel(it.area) }).append("\n")
            }
            append("\n")
            val hasSg = results.any { it.area.country == "SG" }
            val hasMy = results.any { it.area.country == "MY" }
            append(when {
                hasSg && hasMy -> t(
                    "Singapore uses NEA/MSS + nearby stations; Malaysia uses a separate multi-model layer.",
                    "新加坡依据 NEA/MSS + 附近观测站；马来西亚使用独立多模型资料层。"
                )
                hasMy -> t(
                    "Malaysia areas use ECMWF/GFS/ICON multi-model guidance.",
                    "马来西亚地区使用 ECMWF/GFS/ICON 多模型参考。"
                )
                else -> t(
                    "Based on NEA/MSS, the nearest rain station and remaining multi-model guidance.",
                    "依据 NEA/MSS、附近雨量站，以及其余时段的多模型参考。"
                )
            })
        }
        regionContainer.addView(card(summary.toString()))

        results.forEach { addRegionCard(it) }

        val updated = listOf(neaUpdated, rainUpdated).firstOrNull { it.isNotBlank() }
        statusText.text = if (updated.isNullOrBlank()) {
            t("Updated ${formatClock(ZonedDateTime.now(zone))}",
                "已更新 ${formatClock(ZonedDateTime.now(zone))}")
        } else {
            t("Updated ${formatApiTime(updated)}", "已更新 ${formatApiTime(updated)}")
        }
    }

    private fun addRegionCard(r: AreaResult) {
        val first = r.blocks.firstOrNull()
        val preview = buildString {
            append(areaLabel(r.area)).append("  ·  ").append(advice(r.adviceLevel))
            if (r.area.country == "SG") {
                append("\nNEA/MSS: ").append(if (r.forecastRaw.isBlank()) "—" else forecastDisplay(r.forecastRaw))
            } else {
                append("\n").append(t("Malaysia models: ECMWF · GFS · ICON", "马来西亚模型：ECMWF · GFS · ICON"))
            }
            if (first != null) append("  ·  ").append(blockLabel(first.time))
            append("\n").append(t("Tap for hourly details", "点击查看逐小时详情"))
        }
        val compact = card(preview)
        compact.setOnClickListener { showRegionDetails(r) }
        regionContainer.addView(compact, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
    }

    private fun showRegionDetails(r: AreaResult) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(cardColor, 16f)
        }

        val headingRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = areaLabel(r.area)
            textSize = 21f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(textColor)
        }
        headingRow.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val badge = TextView(this).apply {
            text = when (r.adviceLevel) {
                2 -> "🔴 " + t("Not recommended", "不建议")
                1 -> "🟡 " + t("Monitor first", "先观察")
                else -> "🟢 " + t("Good to go", "可以出发")
            }
            textSize = 13f
            setTextColor(textColor)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = rounded(if (isDark) Color.rgb(45, 58, 70) else Color.rgb(238, 243, 247), 18f)
        }
        headingRow.addView(badge)
        box.addView(headingRow)

        val official = TextView(this).apply {
            text = if (r.area.country == "SG") {
                val forecast = if (r.forecastRaw.isBlank()) t("Official forecast unavailable", "官方预报暂时不可用") else forecastDisplay(r.forecastRaw)
                "NEA/MSS  ·  $forecast"
            } else {
                t(
                    "Malaysia weather layer · ECMWF / GFS / ICON",
                    "马来西亚天气层 · ECMWF / GFS / ICON"
                )
            }
            textSize = 15f
            setTextColor(textColor)
            setPadding(0, dp(10), 0, dp(5))
        }
        box.addView(official)

        if (r.area.country == "SG") {
            val obs = TextView(this).apply {
                text = buildString {
                    append(t("Nearby station", "附近观测站")).append(": ").append(r.rainStation.ifBlank { "—" })
                    append("\n")
                    append(t("5-min rain", "5分钟雨量")).append(": ").append(num(r.rainMm)).append(" mm")
                    if (!r.tempC.isNaN()) append("  ·  ").append(num(r.tempC)).append("°C")
                    if (!r.windKmh.isNaN()) append("  ·  ").append(t("Wind ", "风速 ")).append(num(r.windKmh)).append(" km/h")
                }
                textSize = 13.5f
                setTextColor(subTextColor)
                setPadding(0, 0, 0, dp(9))
            }
            box.addView(obs)
        } else {
            val myNote = TextView(this).apply {
                text = t(
                    "Separate Malaysia path: no Singapore NEA station is used for this area.",
                    "独立马来西亚路径：这个地区不会使用任何新加坡 NEA 观测站。"
                )
                textSize = 13.5f
                setTextColor(subTextColor)
                setPadding(0, 0, 0, dp(9))
            }
            box.addView(myNote)
        }

        if (r.blocks.isEmpty()) {
            val ended = TextView(this).apply {
                text = t("Today's selected forecast window has ended.", "今天所选的预报时段已经结束。")
                textSize = 14f
                setTextColor(subTextColor)
            }
            box.addView(ended)
        } else {
            r.blocks.forEach { b ->
                val tv = TextView(this).apply {
                    val icon = when (b.severity) { 2 -> "🔴"; 1 -> "🟡"; else -> "🟢" }
                    text = buildString {
                        append(icon).append("  ").append(blockLabel(b.time)).append("   ")
                        append(advice(b.severity)).append("\n")
                        if (b.modelCount > 0) {
                            append(t("Rain ", "降雨 ")).append(num0(b.probability)).append("%")
                            append("  ·  ").append(num(b.rainMm)).append(" mm")
                            if (!b.tempC.isNaN()) append("  ·  ").append(num(b.tempC)).append("°C")
                            if (!b.gustKmh.isNaN()) append("  ·  ").append(t("Gust ", "阵风 ")).append(num0(b.gustKmh)).append(" km/h")
                            append("\n").append(t("Confidence ", "可信度 ")).append(confidenceLabel(b.confidence))
                            append("  ·  ").append(b.modelCount).append(" ").append(t("models", "模型"))
                        } else {
                            append(t("Multi-model data unavailable", "多模型资料暂时不可用"))
                        }
                    }
                    textSize = 13.5f
                    setTextColor(textColor)
                    setPadding(dp(10), dp(9), dp(10), dp(9))
                    background = rounded(if (isDark) Color.rgb(35, 47, 58) else Color.rgb(247, 249, 251), 10f)
                }
                box.addView(tv, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })
            }
        }

        val scroll = ScrollView(this).apply { addView(box) }
        AlertDialog.Builder(this)
            .setView(scroll)
            .setPositiveButton(t("Close", "关闭"), null)
            .show()
    }

    // ---------------------- Weather data ----------------------

    private val zone: ZoneId = ZoneId.of("Asia/Singapore")

    private fun fetchTwoHourForecast(): Triple<Map<String, String>, String, String> {
        val json = getJson("https://api-open.data.gov.sg/v2/real-time/api/two-hr-forecast")
        val data = json.optJSONObject("data") ?: json
        val items = data.optJSONArray("items") ?: JSONArray()
        if (items.length() == 0) return Triple(emptyMap(), "", "")
        val item = items.optJSONObject(0) ?: return Triple(emptyMap(), "", "")
        val forecasts = item.optJSONArray("forecasts") ?: JSONArray()
        val map = linkedMapOf<String, String>()
        for (i in 0 until forecasts.length()) {
            val o = forecasts.optJSONObject(i) ?: continue
            val area = o.optString("area")
            val forecast = o.optString("forecast")
            if (area.isNotBlank()) map[area] = forecast
        }
        val updated = item.optString("updated_timestamp", data.optString("updated_timestamp", ""))
        val valid = item.optJSONObject("valid_period")?.let {
            listOf(it.optString("start"), it.optString("end")).filter { s -> s.isNotBlank() }.joinToString(" – ")
        }.orEmpty()
        return Triple(map, updated, valid)
    }

    private fun fetchReading(url: String, unit: String): ReadingSet {
        val json = getJson(url)
        val data = json.optJSONObject("data") ?: json
        val stationsJson = data.optJSONArray("stations") ?: JSONArray()
        val stations = mutableListOf<Station>()
        for (i in 0 until stationsJson.length()) {
            val o = stationsJson.optJSONObject(i) ?: continue
            val loc = o.optJSONObject("location") ?: continue
            val lat = loc.optDouble("latitude", Double.NaN)
            val lon = loc.optDouble("longitude", Double.NaN)
            if (lat.isNaN() || lon.isNaN()) continue
            stations += Station(
                id = o.optString("id", o.optString("deviceId")),
                name = o.optString("name", o.optString("id")),
                lat = lat,
                lon = lon
            )
        }

        val readings = data.optJSONArray("readings") ?: JSONArray()
        val reading = if (readings.length() > 0) readings.optJSONObject(0) else null
        val valuesJson = reading?.optJSONArray("data") ?: JSONArray()
        val values = linkedMapOf<String, Double>()
        for (i in 0 until valuesJson.length()) {
            val o = valuesJson.optJSONObject(i) ?: continue
            val id = o.optString("stationId", o.optString("station_id"))
            val value = o.optDouble("value", Double.NaN)
            if (id.isNotBlank() && !value.isNaN()) values[id] = value
        }
        val timestamp = reading?.optString("timestamp").orEmpty()
        return ReadingSet(timestamp, stations, values, unit)
    }

    private fun fetchModel(area: AreaDef, model: String): ModelSeries {
        val url = buildString {
            append("https://api.open-meteo.com/v1/forecast?latitude=").append(area.lat)
            append("&longitude=").append(area.lon)
            append("&hourly=temperature_2m,precipitation_probability,precipitation,weather_code,wind_speed_10m,wind_gusts_10m")
            append("&models=").append(model)
            append("&timezone=").append(if (area.country == "MY") "Asia%2FKuala_Lumpur" else "Asia%2FSingapore")
            append("&forecast_days=2")
        }
        val json = getJson(url)
        val hourly = json.optJSONObject("hourly") ?: return ModelSeries(model, emptyList())
        val times = hourly.optJSONArray("time") ?: JSONArray()
        val temp = hourly.optJSONArray("temperature_2m") ?: JSONArray()
        val probs = hourly.optJSONArray("precipitation_probability") ?: JSONArray()
        val rain = hourly.optJSONArray("precipitation") ?: JSONArray()
        val winds = hourly.optJSONArray("wind_speed_10m") ?: JSONArray()
        val gusts = hourly.optJSONArray("wind_gusts_10m") ?: JSONArray()
        val points = mutableListOf<ModelPoint>()
        for (i in 0 until times.length()) {
            val timeText = times.optString(i)
            val ldt = runCatching { LocalDateTime.parse(timeText) }.getOrNull() ?: continue
            points += ModelPoint(
                time = ldt.atZone(zone),
                probability = probs.optDouble(i, Double.NaN),
                rainMm = rain.optDouble(i, Double.NaN),
                tempC = temp.optDouble(i, Double.NaN),
                windKmh = winds.optDouble(i, Double.NaN),
                gustKmh = gusts.optDouble(i, Double.NaN)
            )
        }
        return ModelSeries(model, points)
    }

    private fun buildAreaResult(
        area: AreaDef,
        forecast: String,
        rain: ReadingSet,
        temp: ReadingSet,
        wind: ReadingSet,
        series: List<ModelSeries>,
        targets: List<ZonedDateTime>
    ): AreaResult {
        val rainNear = nearest(area, rain)
        val tempNear = nearest(area, temp)
        val windNear = nearest(area, wind)

        val rainMm = rainNear?.second ?: Double.NaN
        val tempC = tempNear?.second ?: Double.NaN
        val windKmh = windNear?.second ?: Double.NaN
        val stationName = rainNear?.first?.name.orEmpty()

        val nearSeverity = max(forecastSeverity(forecast), observationSeverity(rainMm, windKmh))
        val now = ZonedDateTime.now(zone)

        val blocks = targets.map { target ->
            val pts = series.mapNotNull { nearest(it, target) }
            val probs = pts.map { it.probability }.filterNot { it.isNaN() }
            val rains = pts.map { it.rainMm }.filterNot { it.isNaN() }
            val temps = pts.map { it.tempC }.filterNot { it.isNaN() }
            val winds = pts.map { it.windKmh }.filterNot { it.isNaN() }
            val gusts = pts.map { it.gustKmh }.filterNot { it.isNaN() }

            val pAvg = probs.averageOrNaN()
            val rainAvg = rains.averageOrNaN()
            val tempAvg = temps.averageOrNaN()
            val windAvg = winds.averageOrNaN()
            val gustMax = gusts.maxOrNull() ?: Double.NaN
            val spread = if (probs.size >= 2) (probs.maxOrNull()!! - probs.minOrNull()!!) else Double.NaN
            var sev = modelSeverity(pAvg, rainAvg, gustMax)
            if (Duration.between(now, target).toMinutes() in 0..150) sev = max(sev, nearSeverity)
            val confidence = when {
                pts.size >= 3 && (spread.isNaN() || spread <= 25.0) -> "High"
                pts.size >= 2 -> "Medium"
                else -> "Low"
            }
            BlockResult(target, sev, pAvg, rainAvg, tempAvg, windAvg, gustMax, confidence, pts.size)
        }

        // v0.8 near-term summary fix:
        // The top recommendation should describe conditions around now, not the
        // worst weather many hours later in the day. Use current observations plus
        // forecast blocks within the next 150 minutes for the headline status.
        val nearBlocks = blocks.filter {
            Duration.between(now, it.time).toMinutes() in 0..150
        }
        val overall = max(nearSeverity, nearBlocks.maxOfOrNull { it.severity } ?: 0)
        return AreaResult(area, forecast, tempC, rainMm, windKmh, stationName, blocks, overall)
    }

    private fun targetTimes(): List<ZonedDateTime> {
        val now = ZonedDateTime.now(zone)
        val d = now.toLocalDate()
        val start = prefs.getInt("forecast_start_hour", 6).coerceIn(6, 23)

        // v0.8 midnight fix:
        // After 00:00 the main forecast may switch to the new calendar day,
        // but 01:00 / 02:00 / 03:00 of the current early morning must remain visible.
        // Then continue with today's selected start hour through 03:00 next day.
        val earlyMorning = if (now.hour < 4) {
            (1..3).map { d.atStartOfDay(zone).plusHours(it.toLong()) }
        } else {
            emptyList()
        }
        val mainWindow = (start..27).map { d.atStartOfDay(zone).plusHours(it.toLong()) }

        return (earlyMorning + mainWindow)
            .distinct()
            .sorted()
            .filter { !it.isBefore(now.minusMinutes(15)) }
    }

    private fun nearest(area: AreaDef, reading: ReadingSet): Pair<Station, Double>? {
        return reading.stations
            .filter { reading.values.containsKey(it.id) }
            .minByOrNull { distanceKm(area.lat, area.lon, it.lat, it.lon) }
            ?.let { it to (reading.values[it.id] ?: Double.NaN) }
    }

    private fun nearest(series: ModelSeries, target: ZonedDateTime): ModelPoint? {
        val usable = series.points.filter {
            abs(Duration.between(it.time, target).toMinutes()) <= 90
        }
        return usable.minByOrNull { abs(Duration.between(it.time, target).toMinutes()) }
    }

    private fun distanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val x = Math.toRadians(lon2 - lon1) * cos(Math.toRadians((lat1 + lat2) / 2.0))
        val y = Math.toRadians(lat2 - lat1)
        return sqrt(x.pow(2) + y.pow(2)) * 6371.0
    }

    private fun forecastSeverity(raw: String): Int {
        val s = raw.lowercase(Locale.ROOT)
        return when {
            s.contains("thundery") || s.contains("heavy rain") -> 2
            s.contains("moderate rain") || s.contains("showers") || s.contains("rain") -> 1
            else -> 0
        }
    }

    private fun observationSeverity(rainMm: Double, windKmh: Double): Int {
        var sev = 0
        if (!rainMm.isNaN()) {
            sev = when {
                rainMm >= 2.0 -> 2
                rainMm >= 0.2 -> 1
                else -> sev
            }
        }
        if (!windKmh.isNaN()) {
            sev = max(sev, when {
                windKmh >= 45 -> 2
                windKmh >= 30 -> 1
                else -> 0
            })
        }
        return sev
    }

    private fun modelSeverity(prob: Double, rainMm: Double, gustKmh: Double): Int {
        return when {
            (!prob.isNaN() && prob >= 70) || (!rainMm.isNaN() && rainMm >= 4.0) || (!gustKmh.isNaN() && gustKmh >= 55) -> 2
            (!prob.isNaN() && prob >= 40) || (!rainMm.isNaN() && rainMm >= 1.0) || (!gustKmh.isNaN() && gustKmh >= 40) -> 1
            else -> 0
        }
    }

    private fun getJson(urlText: String): JSONObject {
        val conn = (URL(urlText).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 9000
            readTimeout = 12000
            setRequestProperty("User-Agent", "HiRider/0.8 Android")
            setRequestProperty("Accept", "application/json")
        }
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return JSONObject(text)
        } finally {
            conn.disconnect()
        }
    }

    // ---------------------- Display helpers ----------------------

    private fun forecastDisplay(raw: String): String {
        if (!isZh) return raw
        val s = raw.lowercase(Locale.ROOT)
        return when {
            s.contains("thundery") -> "雷阵雨"
            s.contains("heavy rain") -> "大雨"
            s.contains("moderate rain") -> "中雨"
            s.contains("light rain") -> "小雨"
            s.contains("showers") -> "阵雨"
            s.contains("partly cloudy") -> "局部多云"
            s.contains("cloudy") -> "多云"
            s.contains("fair") -> "晴朗"
            s.contains("windy") -> "有风"
            else -> raw
        }
    }

    private fun advice(severity: Int): String = when (severity) {
        2 -> t("Not recommended", "不建议")
        1 -> t("Monitor first", "先观察")
        else -> t("Good to go", "可以出发")
    }

    private fun confidenceLabel(value: String): String = when (value) {
        "High" -> t("High", "高")
        "Medium" -> t("Medium", "中")
        else -> t("Low", "低")
    }

    private fun blockLabel(time: ZonedDateTime): String {
        val clock = formatClock(time)
        val today = ZonedDateTime.now(zone).toLocalDate()
        return if (time.toLocalDate().isAfter(today)) t("Next day $clock", "隔天 $clock") else clock
    }

    private fun formatClock(time: ZonedDateTime): String {
        return if (isZh) {
            val hour = time.hour
            val period = when (hour) {
                in 0..5 -> "凌晨"
                in 6..11 -> "上午"
                12 -> "中午"
                in 13..17 -> "下午"
                else -> "晚上"
            }
            val h12 = when (val h = hour % 12) { 0 -> 12; else -> h }
            String.format(Locale.US, "%s %d:%02d", period, h12, time.minute)
        } else {
            time.format(DateTimeFormatter.ofPattern("h:mm a", Locale.US))
        }
    }

    private fun formatHourLabel(hour24: Int): String {
        val h = hour24.coerceIn(0, 23)
        val period = if (h < 12) "AM" else "PM"
        val h12 = when (val v = h % 12) { 0 -> 12; else -> v }
        return if (isZh) {
            val zhPeriod = when (h) {
                in 0..5 -> "凌晨"
                in 6..11 -> "上午"
                12 -> "中午"
                in 13..17 -> "下午"
                else -> "晚上"
            }
            String.format(Locale.US, "%s %d:00", zhPeriod, h12)
        } else {
            String.format(Locale.US, "%d:00 %s", h12, period)
        }
    }

    private fun areaLabel(a: AreaDef): String = if (isZh) a.zh else a.name

    private fun formatApiTime(raw: String): String {
        return runCatching {
            formatClock(ZonedDateTime.parse(raw).withZoneSameInstant(zone))
        }.getOrElse { raw.takeLast(8).take(5).ifBlank { raw } }
    }

    private fun num(v: Double): String = if (v.isNaN()) "—" else String.format(Locale.US, "%.1f", v)
    private fun num0(v: Double): String = if (v.isNaN()) "—" else String.format(Locale.US, "%.0f", v)
    private fun List<Double>.averageOrNaN(): Double = if (isEmpty()) Double.NaN else average()

    private fun label(s: String): TextView = TextView(this).apply {
        text = s
        textSize = 14f
        setTextColor(subTextColor)
        setPadding(0, 0, 0, dp(4))
    }

    private fun card(s: String): TextView = TextView(this).apply {
        text = s
        textSize = 16f
        setTextColor(textColor)
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(cardColor, 16f)
    }

    private fun rounded(color: Int, radiusDp: Float): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radiusDp.toInt()).toFloat()
        setColor(color)
    }

    private fun styleButton(button: Button) {
        button.setAllCaps(false)
        button.setTextColor(Color.WHITE)
        button.textSize = 15f
        button.backgroundTintList = ColorStateList.valueOf(if (isDark) Color.rgb(47, 128, 181) else accentColor)
        button.setPadding(dp(12), dp(9), dp(12), dp(9))
    }

    private fun marginTop(top: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
}
