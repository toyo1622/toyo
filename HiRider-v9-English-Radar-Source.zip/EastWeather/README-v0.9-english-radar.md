# Hi Rider V9 — English-only radar patch

This package starts from `HiRider-v9-repaired-source-v2.zip`. It keeps the
existing V9 weather, sign-in and notification implementation.

## Changes

- The radar title, buttons, guidance, attribution and error messages are always
  in English. The main app may still use Chinese when selected by the user.
- Radar area names now use the English area name, such as `Yong Peng` rather
  than the Chinese display label.
- The radar Activity uses an English Android configuration for its WebView and
  sends an English `Accept-Language` header for the first Windy embed request.
- The Windy embed URL also requests `lang=en` and `englishLabels=true`.
  These query parameters are **best-effort** for the free embed, not a guaranteed
  override; Windy controls the embedded website and may ignore them.
- The `Open full radar map in browser` button remains available. That external
  browser may use the browser's own language preferences.

## Verify before sharing the APK

1. Open Hi Rider with the app language set to Chinese, then open rain radar.
   Confirm the title and selected area show English.
2. Check Windy controls and labels. If they are still localized, this is a
   limitation of the third-party embed rather than the app's native text.
3. Repeat on a Chinese-language phone and an English-language phone, then
   check zoom, radar animation, Windy attribution, and back navigation.
4. Build using the original Android package ID and signing key so upgrades
   work. No Gradle wrapper or signing material is included in this ZIP.

`versionCode` remains `9` and `versionName` remains `0.9`. If version 9 has
already been submitted to an app store, increment `versionCode` before
publishing another release there.
