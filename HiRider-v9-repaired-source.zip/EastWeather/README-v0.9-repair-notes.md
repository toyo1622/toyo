# Hi Rider v0.9 (versionCode 9) — repair notes

This is a repaired **V9 source** package, not V10. Existing sign-in, Singapore
and Malaysia area selection, hourly forecast, scheduled alerts, language/theme
settings and Windy radar remain present.

## Repairs made

1. Missing weather data now has a fourth, grey **Insufficient data / 资料不足**
   status. Missing readings do not automatically become green.
2. Singapore NEA wind observations are converted from the API's reported
   **knots** to km/h before display or risk evaluation.
3. Hourly rainfall/probability from Open-Meteo is aligned to the **preceding
   hour** represented by the API timestamp. A displayed 13:00–14:00 interval
   uses the forecast precipitation value timestamped 14:00.
4. Background alerts use the ending timestamp of the next full clock-hour
   interval and avoid treating an all-null model response as valid.
5. Stale NEA observations are withheld from current-weather assessment.
   The official 2-hour forecast's validity end is checked, and its
   `update_timestamp` response field is used.
6. Confidence is no longer labelled High just because three model time rows
   exist without corresponding precipitation probabilities.
7. Open-Meteo requests use multi-coordinate batches grouped by country;
   single-area requests remain a fallback when a batch fails.
8. Older overlapping UI refresh requests cannot overwrite newer selections,
   and Google credential requests use the Activity context directly.
9. The login/about version text is updated to v0.9. Android 15 system-bar
   insets are handled for the main/login and radar screens.
10. Radar attribution and the full browser fallback are retained; external
    navigation from the embedded map opens in the browser.

## Important limitations

- Forecasts are **guidance**, not a guarantee of safe travel. Local convective
  rain and gusts can occur between model update cycles.
- WorkManager's periodic alerts are approximate and can be delayed by Android
  power-saving policies.
- Windy radar requires network connectivity and Windy's service availability.
- The free Open-Meteo API is subject to its non-commercial terms and usage
  limits. Model data attribution is shown in About.
- The original ZIP did not include a Gradle wrapper, unit tests, Android SDK,
  release signing material or a CI workflow. A full Android build and device
  test **have not been completed in this environment**.
- Keep the existing Android applicationId and signing key to retain upgrade
  compatibility. If an APK with versionCode 9 has already been published to a
  store, a higher versionCode will normally be required for a new store update.

## Manual verification before distribution

1. Open in Android Studio with SDK 35, install build tools and Gradle as
   required, and run a clean debug build.
2. Test on a physical Android 13, 15, and newer device when available. Verify
   status/navigation bars do not obscure buttons or the radar.
3. Check phone OTP and Google sign-in with the correct Firebase SHA fingerprints
   and `google-services.json`. Verify sign-out and sign-in.
4. Select one and six Singapore areas; select mixed Singapore/Malaysia areas.
   Check the six-area limit, names, and saved selection after restart.
5. With internet connected, check that the displayed NEA wind number is in
   km/h (1 knot = 1.852 km/h), including a real station reading.
6. Force a network failure or block the forecast API, then refresh a
   Malaysia-only area: it must show **Insufficient data**, not green.
7. Test late-night and after-midnight forecast windows, including 00:00–03:00,
   and verify each block is the **hour-long interval** shown.
8. Test weather-alert permission denied/granted, alerts off/on, notification
   grouping, and duplicate suppression with clock-hour transitions.
9. Test radar load, pan/zoom, Windy logo/link, browser fallback and offline
   failure message.
10. Repeat refresh/area changes quickly and verify an older response cannot
    overwrite the newer area selection.
11. Review monitoring and app privacy disclosures before public release.
12. Test the release APK signed with the intended key before distributing it.
