package com.eastweather.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowInsets
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/** Opens Windy's public rain-radar embed for an existing Hi Rider area. */
class RadarActivity : Activity() {
    companion object {
        const val EXTRA_AREA = "radar_area"
        const val EXTRA_LAT = "radar_lat"
        const val EXTRA_LON = "radar_lon"
    }

    private lateinit var map: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val zh = getSharedPreferences("hi_rider", MODE_PRIVATE)
            .getString("language", "en") == "zh"
        val area = intent.getStringExtra(EXTRA_AREA).orEmpty().ifBlank { "Hi Rider" }
        val lat = intent.getDoubleExtra(EXTRA_LAT, 1.345).coerceIn(-85.0, 85.0)
        val lon = intent.getDoubleExtra(EXTRA_LON, 103.944).coerceIn(-180.0, 180.0)
        val latParam = String.format(Locale.US, "%.4f", lat)
        val lonParam = String.format(Locale.US, "%.4f", lon)
        val embedUrl = "https://embed.windy.com/embed2.html?lat=$latParam&lon=$lonParam" +
            "&detailLat=$latParam&detailLon=$lonParam&zoom=9&level=surface" +
            "&overlay=radar&product=radar&menu=true&message=true&marker=true" +
            "&calendar=now&pressure=&type=map&location=coordinates&detail=" +
            "&metricWind=default&metricTemp=default&radarRange=-1"
        val fullMapUrl = "https://www.windy.com/?radar,$latParam,$lonParam,9"

        val background = Color.rgb(15, 25, 38)
        val foreground = Color.WHITE
        val secondary = Color.rgb(170, 197, 217)
        val accent = Color.rgb(35, 102, 150)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(background)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                view.setPadding(dp(12), dp(12) + bars.top, dp(12), dp(12) + bars.bottom)
                insets
            }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val heading = TextView(this).apply {
            text = if (zh) "🌧 雨云雷达 · $area" else "🌧 Rain Radar · $area"
            textSize = 19f
            setTextColor(foreground)
            setTypeface(typeface, Typeface.BOLD)
        }
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        val close = Button(this).apply {
            text = if (zh) "返回" else "Back"
            setAllCaps(false)
            setTextColor(foreground)
            backgroundTintList = android.content.res.ColorStateList.valueOf(accent)
            setOnClickListener { finish() }
        }
        header.addView(close)
        root.addView(header)

        val hint = TextView(this).apply {
            text = if (zh) "最新可用降雨雷达 · 可拖动地图、缩放并查看雨云位置" else
                "Latest available rain radar · pan and zoom to inspect rain clouds"
            textSize = 12f
            setTextColor(secondary)
            setPadding(dp(3), 0, dp(3), dp(9))
        }
        root.addView(hint)

        map = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean {
                    if (!request.isForMainFrame || request.url.host == "embed.windy.com") {
                        return false
                    }
                    // Keep Windy's own external links out of the embedded map.
                    runCatching {
                        startActivity(Intent(Intent.ACTION_VIEW, request.url))
                    }.onFailure {
                        Toast.makeText(this@RadarActivity,
                            if (zh) "无法打开浏览器" else "Unable to open browser",
                            Toast.LENGTH_SHORT).show()
                    }
                    return true
                }

                override fun onReceivedError(
                    view: WebView,
                    request: WebResourceRequest,
                    error: WebResourceError
                ) {
                    if (request.isForMainFrame) {
                        Toast.makeText(this@RadarActivity,
                            if (zh) "雷达暂时无法载入，请尝试在浏览器打开" else
                                "Radar unavailable; try opening it in your browser",
                            Toast.LENGTH_LONG).show()
                    }
                }
            }
            loadUrl(embedUrl)
        }
        root.addView(map, LinearLayout.LayoutParams(-1, 0, 1f))

        val source = TextView(this).apply {
            text = if (zh) "雷达地图：Windy · 需联网 · 以地图显示时间为准" else
                "Radar map: Windy · internet required · check map timestamp"
            textSize = 11f
            setTextColor(secondary)
            gravity = Gravity.CENTER
            setPadding(0, dp(7), 0, dp(6))
        }
        root.addView(source)

        val browserButton = Button(this).apply {
            text = if (zh) "在浏览器打开完整雷达图 ↗" else "Open full radar map in browser ↗"
            setAllCaps(false)
            setTextColor(foreground)
            background = GradientDrawable().apply {
                setColor(accent)
                cornerRadius = dp(12).toFloat()
            }
            setOnClickListener {
                runCatching {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fullMapUrl)))
                }.onFailure {
                    Toast.makeText(this@RadarActivity,
                        if (zh) "无法打开浏览器" else "Unable to open browser",
                        Toast.LENGTH_SHORT).show()
                }
            }
        }
        root.addView(browserButton, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    override fun onDestroy() {
        if (::map.isInitialized) {
            map.stopLoading()
            (map.parent as? ViewGroup)?.removeView(map)
            map.destroy()
        }
        super.onDestroy()
    }

    private fun dp(value: Int) = (resources.displayMetrics.density * value + 0.5f).toInt()
}
