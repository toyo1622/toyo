Hi Rider v0.9 — Live Rain Radar
================================

What is new
- A Rain Radar button under the main Choose areas / Refresh controls.
- If more than one area is selected, choose the region whose radar map to open.
- Every area's hourly details also offer an Open rain radar button.
- A full-screen in-app rain radar map, centered on the chosen Singapore or
  Malaysia area, using Windy's public embedded weather-radar map.
- Pan/zoom the map or use Open full radar map in browser if the embedded
  view cannot load.

Notes
- This is a visualization of the latest available radar layer, not a live
  GPS location tracker or a promise of second-by-second data updates.
- It requires internet access and Windy's service availability.
- The Windy attribution and links must remain visible and usable.
- Weather forecasts, existing alert logic, and Malaysia's independent
  ECMWF / GFS / ICON model data have not been modified.
- Android package name and signing configuration are retained from v0.8;
  versionCode is raised to 9 for upgrade compatibility.
