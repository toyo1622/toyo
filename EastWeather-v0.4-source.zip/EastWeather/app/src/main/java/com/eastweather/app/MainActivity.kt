package com.eastweather.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.time.Duration
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import org.json.JSONObject
import kotlin.concurrent.thread
import kotlin.math.pow

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var selectedText: TextView
    private lateinit var summary: TextView
    private lateinit var regionContainer: LinearLayout
    private lateinit var chooseButton: Button
    private lateinit var refreshButton: Button

    private val zone = ZoneId.of("Asia/Singapore")
    private val prefs by lazy { getSharedPreferences("hi_rider", Context.MODE_PRIVATE) }

    private var isZh = true
    private var isDark = false
    private var bgColor = Color.WHITE
    private var cardColor = Color.rgb(245, 247, 250)
    private var textColor = Color.BLACK
    private var subTextColor = Color.DKGRAY
    private var mutedColor = Color.GRAY
    private var accentColor = Color.rgb(25, 118, 210)

    data class AreaDef(val name: String, val zh: String, val lat: Double, val lon: Double)
    data class Station(val id: String, val name: String, val lat: Double, val lon: Double)
    data class ReadingSet(
        val timestamp: String,
        val unit: String,
        val stations: List<Station>,
        val values: Map<String, Double>
    )
    data class AreaModel(
        val temp: Double,
        val wind: Double,
        val gust: Double,
        val blocks: IntArray,
        val spreads: IntArray
    )
    data class AreaResult(
        val area: AreaDef,
        val forecastRaw: String,
        val rainMm: Double,
        val rainStation: String,
        val tempC: Double,
        val windKmh: Double,
        val gustKmh: Double,
        val model: AreaModel,
        val adviceLevel: Int,
        val confidenceLevel: Int
    )

    private val areas = listOf(
        AreaDef("Tampines", "淡滨尼", 1.345, 103.944),
        AreaDef("Pasir Ris", "巴西立", 1.370, 103.948),
        AreaDef("Bedok", "勿洛", 1.321, 103.924),
        AreaDef("Changi", "樟宜", 1.357, 103.987),
        AreaDef("Paya Lebar", "巴耶利峇", 1.358, 103.914),
        AreaDef("Hougang", "后港", 1.361218, 103.886),
        AreaDef("Punggol", "榜鹅", 1.401, 103.904),
        AreaDef("Sengkang", "盛港", 1.384, 103.891443),
        AreaDef("Serangoon", "实龙岗", 1.357, 103.865),
        AreaDef("Geylang", "芽笼", 1.318, 103.884),
        AreaDef("Marine Parade", "马林百列", 1.297, 103.891),
        AreaDef("Kallang", "加冷", 1.312, 103.862),
        AreaDef("City", "市中心", 1.292, 103.844),
        AreaDef("Toa Payoh", "大巴窑", 1.334304, 103.856327),
        AreaDef("Ang Mo Kio", "宏茂桥", 1.375, 103.839),
        AreaDef("Bishan", "碧山", 1.350772, 103.839),
        AreaDef("Woodlands", "兀兰", 1.432, 103.786528),
        AreaDef("Yishun", "义顺", 1.418, 103.839),
        AreaDef("Sembawang", "三巴旺", 1.445, 103.818495),
        AreaDef("Jurong East", "裕廊东", 1.326, 103.737),
        AreaDef("Jurong West", "裕廊西", 1.34039, 103.705),
        AreaDef("Clementi", "金文泰", 1.315, 103.760),
        AreaDef("Bukit Batok", "武吉巴督", 1.353, 103.754),
        AreaDef("Queenstown", "女皇镇", 1.291, 103.78576),
        AreaDef("Sentosa", "圣淘沙", 1.243, 103.832)
    )

    private val defaultNames = listOf("Tampines", "Pasir Ris", "Bedok", "Changi")

    override fun onCreate(savedInstanceState: Bundle?) {
        val p = getSharedPreferences("hi_rider", Context.MODE_PRIVATE)
        isDark = p.getString("theme", "light") == "dark"
        setTheme(if (isDark) R.style.AppThemeDark else R.style.AppThemeLight)
        super.onCreate(savedInstanceState)

        isZh = p.getString("language", "zh") != "en"
        applyPalette()

        val scroll = ScrollView(this).apply { setBackgroundColor(bgColor) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 42)
            setBackgroundColor(bgColor)
        }
        scroll.addView(root)
        setContentView(scroll)

        buildHeader()
        buildControls()

        selectedText = addText("", 14, subTextColor)
        summary = card(tr("🏍️ 骑手天气总览\n读取中…", "🏍️ Rider Weather Overview\nLoading…"))
        regionContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(regionContainer)

        addText(
            tr(
                "说明：一次最多选择6个地区。NEA/MSS 官方2小时预报与本地实测优先，ECMWF/GFS/ICON 用来补足未来数小时；已过去时段会自动隐藏。",
                "Note: Select up to 6 areas. NEA/MSS 2-hour forecasts and local observations are prioritised, with ECMWF/GFS/ICON used for the remaining hours. Past time blocks are hidden automatically."
            ),
            13,
            mutedColor
        )
        updateSelectedLabel()
        load()
    }

    private fun applyPalette() {
        if (isDark) {
            bgColor = Color.rgb(16, 18, 20)
            cardColor = Color.rgb(29, 33, 37)
            textColor = Color.rgb(245, 247, 249)
            subTextColor = Color.rgb(196, 201, 207)
            mutedColor = Color.rgb(150, 157, 165)
            accentColor = Color.rgb(66, 165, 245)
        } else {
            bgColor = Color.WHITE
            cardColor = Color.rgb(245, 247, 250)
            textColor = Color.rgb(20, 24, 28)
            subTextColor = Color.rgb(70, 76, 82)
            mutedColor = Color.rgb(110, 116, 122)
            accentColor = Color.rgb(25, 118, 210)
        }
        window.statusBarColor = bgColor
        window.navigationBarColor = bgColor
    }

    private fun tr(zh: String, en: String): String = if (isZh) zh else en

    private fun areaLabel(area: AreaDef): String = if (isZh) "${area.zh} ${area.name}" else area.name

    private fun buildHeader() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleWrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "🌧️🛵 Hi Rider"
            textSize = 28f
            setTextColor(textColor)
        }
        val subtitle = TextView(this).apply {
            text = tr("骑手专用天气助手", "Weather companion for riders")
            textSize = 15f
            setTextColor(subTextColor)
            setPadding(0, 3, 0, 5)
        }
        titleWrap.addView(title)
        titleWrap.addView(subtitle)
        row.addView(titleWrap, LinearLayout.LayoutParams(0, -2, 1f))

        val settings = Button(this).apply {
            text = "⚙"
            textSize = 21f
            contentDescription = tr("设置", "Settings")
            setOnClickListener { showSettings() }
        }
        styleButton(settings)
        row.addView(settings, LinearLayout.LayoutParams(116, 116))
        root.addView(row)

        status = addText(tr("正在准备…", "Preparing…"), 14, mutedColor)
    }

    private fun buildControls() {
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chooseButton = Button(this).apply {
            textSize = 15f
            setOnClickListener { showAreaPicker() }
        }
        refreshButton = Button(this).apply {
            text = tr("重新更新", "Refresh")
            textSize = 15f
            setOnClickListener { load() }
        }
        styleButton(chooseButton)
        styleButton(refreshButton)
        controls.addView(chooseButton, LinearLayout.LayoutParams(0, 126, 1f).apply { marginEnd = 8 })
        controls.addView(refreshButton, LinearLayout.LayoutParams(0, 126, 1f).apply { marginStart = 8 })
        root.addView(controls, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
    }

    private fun styleButton(button: Button) {
        button.backgroundTintList = ColorStateList.valueOf(if (isDark) Color.rgb(48, 54, 60) else Color.rgb(232, 238, 244))
        button.setTextColor(if (isDark) Color.WHITE else Color.rgb(25, 35, 45))
        button.isAllCaps = false
    }

    private fun addText(s: String, size: Int, color: Int): TextView {
        val v = TextView(this)
        v.text = s
        v.textSize = size.toFloat()
        v.setTextColor(color)
        v.setPadding(0, 8, 0, 8)
        root.addView(v)
        return v
    }

    private fun card(s: String): TextView {
        val v = TextView(this)
        v.text = s
        v.textSize = 17f
        v.setTextColor(textColor)
        v.setPadding(24, 24, 24, 24)
        v.setBackgroundColor(cardColor)
        root.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 })
        return v
    }

    private fun addRegionCard(s: String): TextView {
        val v = TextView(this)
        v.text = s
        v.textSize = 16.5f
        v.setTextColor(textColor)
        v.setPadding(24, 24, 24, 24)
        v.setBackgroundColor(cardColor)
        regionContainer.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 })
        return v
    }

    private fun selectedNames(): List<String> {
        val saved = prefs.getString("selected_areas", null)
        val list = saved?.split("|")?.filter { it.isNotBlank() } ?: defaultNames
        return list.filter { n -> areas.any { it.name == n } }.ifEmpty { defaultNames }
    }

    private fun selectedAreas(): List<AreaDef> {
        val names = selectedNames()
        return names.mapNotNull { n -> areas.firstOrNull { it.name == n } }
    }

    private fun saveSelected(names: List<String>) {
        prefs.edit().putString("selected_areas", names.joinToString("|")).apply()
    }

    private fun updateSelectedLabel() {
        val picked = selectedAreas()
        chooseButton.text = tr("选择地区（${picked.size}）", "Areas (${picked.size})")
        selectedText.text = tr("常用地区：", "Selected: ") + picked.joinToString(if (isZh) "、" else ", ") { areaLabel(it) }
    }

    private fun showSettings() {
        val labels = arrayOf(
            tr("🌐 语言：${if (isZh) "中文" else "English"}", "🌐 Language: ${if (isZh) "中文" else "English"}"),
            tr("🌙 主题：${if (isDark) "黑夜模式" else "白天模式"}", "🌙 Theme: ${if (isDark) "Dark" else "Light"}"),
            tr("📍 已选地区", "📍 Selected Areas"),
            tr("ℹ️ 关于 Hi Rider", "ℹ️ About Hi Rider")
        )
        AlertDialog.Builder(this)
            .setTitle(tr("设置", "Settings"))
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> showLanguageDialog()
                    1 -> showThemeDialog()
                    2 -> showAreaPicker()
                    3 -> showAbout()
                }
            }
            .setNegativeButton(tr("关闭", "Close"), null)
            .show()
    }

    private fun showLanguageDialog() {
        val choices = arrayOf("中文", "English")
        val current = if (isZh) 0 else 1
        AlertDialog.Builder(this)
            .setTitle(tr("选择语言", "Choose Language"))
            .setSingleChoiceItems(choices, current) { dialog, which ->
                prefs.edit().putString("language", if (which == 0) "zh" else "en").apply()
                dialog.dismiss()
                recreate()
            }
            .setNegativeButton(tr("取消", "Cancel"), null)
            .show()
    }

    private fun showThemeDialog() {
        val choices = if (isZh) arrayOf("☀️ 白天模式", "🌙 黑夜模式") else arrayOf("☀️ Light mode", "🌙 Dark mode")
        val current = if (isDark) 1 else 0
        AlertDialog.Builder(this)
            .setTitle(tr("选择主题", "Choose Theme"))
            .setSingleChoiceItems(choices, current) { dialog, which ->
                prefs.edit().putString("theme", if (which == 1) "dark" else "light").apply()
                dialog.dismiss()
                recreate()
            }
            .setNegativeButton(tr("取消", "Cancel"), null)
            .show()
    }

    private fun showAbout() {
        AlertDialog.Builder(this)
            .setTitle("Hi Rider v0.4")
            .setMessage(
                tr(
                    "Hi Rider 是为骑手设计的实用工具。当前版本以新加坡天气与跑单参考为主，未来可扩展骑手工具、维修、用品与服务。",
                    "Hi Rider is a practical companion for riders. This version focuses on Singapore weather and riding conditions, with room for future rider tools, repair, shopping and services."
                )
            )
            .setPositiveButton(tr("知道了", "OK"), null)
            .show()
    }

    private fun showAreaPicker() {
        val current = selectedNames().toMutableSet()
        val labels = areas.map { areaLabel(it) }.toTypedArray()
        val checked = BooleanArray(areas.size) { i -> current.contains(areas[i].name) }
        val dialog = AlertDialog.Builder(this)
            .setTitle(tr("选择常用地区（最多6个）", "Choose areas (max 6)"))
            .setMultiChoiceItems(labels, checked) { d, which, isChecked ->
                checked[which] = isChecked
                if (isChecked && checked.count { it } > 6) {
                    checked[which] = false
                    (d as? AlertDialog)?.listView?.setItemChecked(which, false)
                    Toast.makeText(this, tr("一次最多选择6个地区", "You can select up to 6 areas"), Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(tr("取消", "Cancel"), null)
            .setPositiveButton(tr("保存", "Save"), null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val names = areas.indices.filter { checked[it] }.map { areas[it].name }
                if (names.isEmpty()) {
                    Toast.makeText(this, tr("至少选择1个地区", "Select at least 1 area"), Toast.LENGTH_SHORT).show()
                } else {
                    saveSelected(names)
                    updateSelectedLabel()
                    dialog.dismiss()
                    load()
                }
            }
        }
        dialog.show()
    }

    private fun getJson(urlText: String): JSONObject? {
        return try {
            val c = URL(urlText).openConnection() as HttpURLConnection
            c.connectTimeout = 9000
            c.readTimeout = 14000
            c.requestMethod = "GET"
            c.setRequestProperty("User-Agent", "HiRider/0.4 Android")
            c.inputStream.bufferedReader().use { JSONObject(it.readText()) }
        } catch (_: Exception) {
            null
        }
    }

    private fun parseReading(root: JSONObject?): ReadingSet? {
        if (root == null || root.optInt("code", -1) != 0) return null
        return try {
            val data = root.getJSONObject("data")
            val stationsJson = data.getJSONArray("stations")
            val stations = mutableListOf<Station>()
            for (i in 0 until stationsJson.length()) {
                val s = stationsJson.getJSONObject(i)
                val loc = s.getJSONObject("location")
                stations.add(
                    Station(
                        s.getString("id"),
                        s.optString("name", s.getString("id")),
                        loc.getDouble("latitude"),
                        loc.getDouble("longitude")
                    )
                )
            }
            val readings = data.getJSONArray("readings").getJSONObject(0)
            val valuesJson = readings.getJSONArray("data")
            val values = mutableMapOf<String, Double>()
            for (i in 0 until valuesJson.length()) {
                val x = valuesJson.getJSONObject(i)
                values[x.getString("stationId")] = x.getDouble("value")
            }
            ReadingSet(readings.getString("timestamp"), data.optString("readingUnit", ""), stations, values)
        } catch (_: Exception) {
            null
        }
    }

    private fun nearest(reading: ReadingSet?, lat: Double, lon: Double): Pair<Station, Double>? {
        if (reading == null) return null
        val usable = reading.stations.filter { reading.values.containsKey(it.id) }
        if (usable.isEmpty()) return null
        val s = usable.minByOrNull { (it.lat - lat).pow(2) + (it.lon - lon).pow(2) } ?: return null
        return s to (reading.values[s.id] ?: 0.0)
    }

    private fun formatTime(iso: String): String {
        return try {
            ZonedDateTime.parse(iso).withZoneSameInstant(zone).format(DateTimeFormatter.ofPattern("HH:mm"))
        } catch (_: Exception) {
            iso.takeLast(8).take(5)
        }
    }

    private fun forecastDisplay(raw: String): String {
        if (!isZh) return raw
        val s = raw.lowercase()
        return when {
            "thundery" in s -> "雷阵雨"
            "heavy rain" in s -> "大雨"
            "moderate rain" in s -> "中雨"
            "light rain" in s -> "小雨"
            "showers" in s -> "阵雨"
            "rain" in s -> "有雨"
            "windy" in s -> "有风"
            "partly cloudy" in s -> "局部多云"
            "cloudy" in s -> "多云"
            "fair" in s -> "晴到少云"
            else -> raw
        }
    }

    private fun severity(raw: String): Int {
        val s = raw.lowercase()
        return when {
            "thundery" in s || "heavy rain" in s -> 3
            "moderate rain" in s || "showers" in s || "rain" in s -> 2
            "windy" in s -> 1
            else -> 0
        }
    }

    private fun neaForecastMap(root: JSONObject?): Triple<Map<String, String>, String, String> {
        if (root == null || root.optInt("code", -1) != 0) return Triple(emptyMap(), "", "")
        return try {
            val item = root.getJSONObject("data").getJSONArray("items").getJSONObject(0)
            val forecasts = item.getJSONArray("forecasts")
            val map = mutableMapOf<String, String>()
            for (i in 0 until forecasts.length()) {
                val f = forecasts.getJSONObject(i)
                map[f.getString("area")] = f.getString("forecast")
            }
            val valid = item.getJSONObject("valid_period").optString("text", "")
            val updated = item.optString("update_timestamp", item.optString("timestamp", ""))
            Triple(map, valid, updated)
        } catch (_: Exception) {
            Triple(emptyMap(), "", "")
        }
    }

    private fun fetchModel(lat: Double, lon: Double): AreaModel {
        val vars = "temperature_2m,precipitation_probability,precipitation,weather_code,wind_speed_10m,wind_gusts_10m"
        val models = listOf("ecmwf_ifs025", "ncep_gfs_global", "icon_global")
        val results = models.mapNotNull { m ->
            getJson("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&hourly=$vars&models=$m&timezone=Asia%2FSingapore&forecast_days=2")
        }
        if (results.isEmpty()) throw IllegalStateException(tr("多模型资料暂时不可用", "Multi-model data unavailable"))

        val now = ZonedDateTime.now(zone)
        val today = now.toLocalDate().toString()

        fun indexFor(j: JSONObject, hour: Int): Int {
            val times = j.getJSONObject("hourly").getJSONArray("time")
            val target = String.format("%sT%02d:00", today, hour)
            for (i in 0 until times.length()) if (times.getString(i) == target) return i
            return -1
        }

        fun nearestIndex(j: JSONObject): Int {
            val times = j.getJSONObject("hourly").getJSONArray("time")
            var best = 0
            var bestDiff = Long.MAX_VALUE
            for (i in 0 until times.length()) {
                val d = kotlin.math.abs(Duration.between(now.toLocalDateTime(), LocalDateTime.parse(times.getString(i))).toMinutes())
                if (d < bestDiff) { best = i; bestDiff = d }
            }
            return best
        }

        fun block(a: Int, b: Int): Pair<Int, Int> {
            val modelValues = mutableListOf<Double>()
            for (j in results) {
                val probs = j.getJSONObject("hourly").getJSONArray("precipitation_probability")
                val vals = mutableListOf<Int>()
                for (h in a until b) {
                    val idx = indexFor(j, h)
                    if (idx >= 0) vals.add(probs.optInt(idx, 0))
                }
                if (vals.isNotEmpty()) modelValues.add(vals.average())
            }
            if (modelValues.isEmpty()) return 0 to 100
            val avg = modelValues.average().toInt()
            val spread = ((modelValues.maxOrNull() ?: 0.0) - (modelValues.minOrNull() ?: 0.0)).toInt()
            return avg to spread
        }

        val currentTemps = mutableListOf<Double>()
        val currentWinds = mutableListOf<Double>()
        val currentGusts = mutableListOf<Double>()
        for (j in results) {
            val h = j.getJSONObject("hourly")
            val idx = nearestIndex(j)
            currentTemps.add(h.getJSONArray("temperature_2m").optDouble(idx, Double.NaN))
            currentWinds.add(h.getJSONArray("wind_speed_10m").optDouble(idx, Double.NaN))
            currentGusts.add(h.getJSONArray("wind_gusts_10m").optDouble(idx, Double.NaN))
        }
        val b1 = block(18, 20)
        val b2 = block(20, 22)
        val b3 = block(22, 24)
        return AreaModel(
            currentTemps.filter { !it.isNaN() }.average(),
            currentWinds.filter { !it.isNaN() }.average(),
            currentGusts.filter { !it.isNaN() }.average(),
            intArrayOf(b1.first, b2.first, b3.first),
            intArrayOf(b1.second, b2.second, b3.second)
        )
    }

    private fun visibleBlocks(now: ZonedDateTime): List<Int> {
        return when {
            now.hour in 0..5 -> emptyList()
            now.hour < 20 -> listOf(0, 1, 2)
            now.hour < 22 -> listOf(1, 2)
            else -> listOf(2)
        }
    }

    private fun blockLabel(idx: Int): String = when (idx) {
        0 -> if (isZh) "6–8 PM" else "6–8 PM"
        1 -> if (isZh) "8–10 PM" else "8–10 PM"
        else -> if (isZh) "10 PM–12 AM" else "10 PM–12 AM"
    }

    private fun advice(level: Int): String = when (level) {
        2 -> tr("🔴 暂不建议", "🔴 Not recommended")
        1 -> tr("🟡 先观察", "🟡 Monitor first")
        else -> tr("🟢 较适合", "🟢 Good to go")
    }

    private fun confidence(level: Int): String = when (level) {
        2 -> tr("较高", "High")
        1 -> tr("中等", "Medium")
        else -> tr("较低", "Low")
    }

    private fun load() {
        val picked = selectedAreas()
        updateSelectedLabel()
        status.text = tr(
            "正在读取 ${picked.size} 个地区的官方与多模型资料…",
            "Loading official and multi-model data for ${picked.size} areas…"
        )
        summary.text = tr("🏍️ 骑手天气总览\n计算中…", "🏍️ Rider Weather Overview\nCalculating…")
        regionContainer.removeAllViews()
        addRegionCard(tr("读取中…", "Loading…"))

        thread {
            try {
                val nea2h = getJson("https://api-open.data.gov.sg/v2/real-time/api/two-hr-forecast")
                val rainfall = parseReading(getJson("https://api-open.data.gov.sg/v2/real-time/api/rainfall"))
                val tempReading = parseReading(getJson("https://api-open.data.gov.sg/v2/real-time/api/air-temperature"))
                val windReading = parseReading(getJson("https://api-open.data.gov.sg/v2/real-time/api/wind-speed"))
                val (forecastMap, neaValid, neaUpdated) = neaForecastMap(nea2h)
                val now = ZonedDateTime.now(zone)
                val active = visibleBlocks(now)

                val results = mutableListOf<AreaResult>()
                for (area in picked) {
                    val model = fetchModel(area.lat, area.lon)
                    val rainNear = nearest(rainfall, area.lat, area.lon)
                    val tempNear = nearest(tempReading, area.lat, area.lon)
                    val windNear = nearest(windReading, area.lat, area.lon)
                    val forecastRaw = forecastMap[area.name] ?: tr("官方资料暂不可用", "Official forecast unavailable")
                    val rainMm = rainNear?.second ?: 0.0
                    val tempC = tempNear?.second ?: model.temp
                    val windKmh = windNear?.second?.times(1.852) ?: model.wind
                    val remainingMax = if (active.isEmpty()) 0 else active.maxOf { model.blocks[it] }
                    val spread = if (active.isEmpty()) 100 else active.maxOf { model.spreads[it] }
                    val sev = severity(forecastRaw)
                    val level = when {
                        sev >= 3 || rainMm >= 1.0 || remainingMax >= 75 -> 2
                        sev >= 2 || rainMm > 0.0 || remainingMax >= 45 -> 1
                        else -> 0
                    }
                    val confidenceLevel = when {
                        spread <= 20 && forecastMap.containsKey(area.name) -> 2
                        spread <= 35 -> 1
                        else -> 0
                    }
                    results.add(
                        AreaResult(
                            area, forecastRaw, rainMm, rainNear?.first?.name ?: tr("附近测站", "Nearby station"),
                            tempC, windKmh, model.gust, model, level, confidenceLevel
                        )
                    )
                }

                val green = results.filter { it.adviceLevel == 0 }.map { areaLabel(it.area) }
                val yellow = results.filter { it.adviceLevel == 1 }.map { areaLabel(it.area) }
                val red = results.filter { it.adviceLevel == 2 }.map { areaLabel(it.area) }
                val joiner = if (isZh) "、" else ", "
                val summaryText = buildString {
                    append(tr("🏍️ 骑手天气总览", "🏍️ Rider Weather Overview"))
                    if (green.isNotEmpty()) append("\n" + tr("🟢 较适合：", "🟢 Good to go: ") + green.joinToString(joiner))
                    if (yellow.isNotEmpty()) append("\n" + tr("🟡 观察：", "🟡 Monitor: ") + yellow.joinToString(joiner))
                    if (red.isNotEmpty()) append("\n" + tr("🔴 暂不建议：", "🔴 Not recommended: ") + red.joinToString(joiner))
                    if (active.isEmpty()) {
                        append("\n\n" + tr("今晚 6PM–12AM 时段已结束。", "The 6 PM–12 AM riding window has ended."))
                    } else {
                        append("\n\n" + tr(
                            "判断以 NEA/MSS + 最近雨量站 + 剩余时段多模型为依据。",
                            "Based on NEA/MSS, the nearest rain station and remaining multi-model guidance."
                        ))
                    }
                }

                val cards = results.map { r ->
                    buildString {
                        append("📍 ${areaLabel(r.area)}")
                        append("\n🇸🇬 NEA/MSS：${forecastDisplay(r.forecastRaw)}")
                        append("\n🌧️ " + tr("5分钟雨量：", "5-min rain: ") + "${"%.1f".format(r.rainMm)} mm｜${r.rainStation}")
                        append("\n🌡️ ${"%.1f".format(r.tempC)}°C｜" + tr("风 ", "Wind ") + "${"%.1f".format(r.windKmh)} km/h｜" + tr("阵风参考 ", "Gust ref. ") + "${"%.1f".format(r.gustKmh)} km/h")
                        if (active.isEmpty()) {
                            append("\n📊 " + tr("晚间模型：当前不在 6PM–12AM 判断时段", "Evening model: outside the 6 PM–12 AM riding window"))
                        } else {
                            append("\n📊 " + tr("剩余时段模型风险：", "Remaining model risk:"))
                            active.forEach { idx ->
                                append("\n   ${blockLabel(idx)}：${r.model.blocks[idx]}%（" + tr("无雨参考 ", "dry reference ") + "${100 - r.model.blocks[idx]}%）")
                            }
                        }
                        append("\n🏍️ ${advice(r.adviceLevel)}｜" + tr("信心 ", "Confidence ") + confidence(r.confidenceLevel))
                    }
                }

                val appUpdated = now.format(DateTimeFormatter.ofPattern("HH:mm"))
                val rainUpdated = rainfall?.timestamp ?: ""
                runOnUiThread {
                    status.text = buildString {
                        append(tr("已更新 $appUpdated｜Hi Rider v0.4", "Updated $appUpdated｜Hi Rider v0.4"))
                        if (neaUpdated.isNotBlank()) append("｜NEA ${formatTime(neaUpdated)}")
                        if (rainUpdated.isNotBlank()) append("｜" + tr("雨量 ", "Rain ") + formatTime(rainUpdated))
                        if (neaValid.isNotBlank()) append("\n" + tr("NEA有效：", "NEA valid: ") + neaValid)
                    }
                    summary.text = summaryText
                    regionContainer.removeAllViews()
                    cards.forEach { addRegionCard(it) }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = tr("更新失败：", "Update failed: ") + (e.message ?: tr("网络或天气资料暂时不可用", "Network or weather data unavailable"))
                    summary.text = tr("🏍️ 骑手天气总览\n暂时无法完成判断", "🏍️ Rider Weather Overview\nUnable to complete the assessment")
                    regionContainer.removeAllViews()
                    addRegionCard(tr("请稍后按“重新更新”再试。", "Please tap Refresh and try again later."))
                }
            }
        }
    }
}
