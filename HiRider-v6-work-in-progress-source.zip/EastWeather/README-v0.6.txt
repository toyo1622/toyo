Hi Rider v0.6

OTP-gated build.
- Phone OTP is required when there is no active Firebase sign-in session.
- Android app-data backup is disabled so an old auth session is not restored after a fresh install.
- Firebase Analytics remains enabled.
- Singapore rider weather features are unchanged.
