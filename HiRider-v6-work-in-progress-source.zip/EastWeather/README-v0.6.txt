Hi Rider v0.6

Temporary direct-entry build.
- No phone OTP required to enter the app.
- Firebase Analytics remains enabled.
- OTP code is kept in source for easy re-enable later.
- Singapore rider weather features are unchanged.
