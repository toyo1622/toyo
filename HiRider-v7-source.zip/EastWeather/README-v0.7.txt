Hi Rider v0.7 - Malaysia layer

OTP / Firebase
- Phone OTP is required when there is no active Firebase sign-in session.
- Android app-data backup remains disabled so an old auth session is not restored after a fresh install.
- Firebase Analytics remains enabled.

Weather architecture
- Singapore keeps the existing NEA/MSS + nearby observation stations + ECMWF/GFS/ICON logic.
- Malaysia uses a separate ECMWF/GFS/ICON model path and never attaches to Singapore NEA stations.
- Area picker now labels Singapore and Malaysia areas separately.

Malaysia areas added in this work-in-progress build
- Johor: Johor Bahru, Iskandar Puteri, Pasir Gudang, Kulai, Pontian, Kota Tinggi, Kluang, Batu Pahat, Yong Peng, Muar, Tangkak, Segamat, Labis, Mersing, Endau, Pengerang.
- Kuala Lumpur: Kuala Lumpur, KLCC, Cheras, Kepong, Setapak, Bukit Jalil.

Important
- Version code/name are 7 / 0.7 so this build can update over v0.6 when signed with the same permanent key.
- Full Android/Gradle build was not run in this container because the supplied source package does not include a Gradle wrapper or Android SDK build environment. Kotlin parsing was checked; expected unresolved Android/Firebase references occur outside an Android build environment.
