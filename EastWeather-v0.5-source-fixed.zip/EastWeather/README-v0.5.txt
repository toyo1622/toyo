Hi Rider / EastWeather v0.5

New in v0.5
- Firebase Phone Authentication (SMS OTP) is required before the weather screen opens.
- Firebase Authentication keeps a user record for each verified phone account.
- Firebase Analytics is included for active-user/app usage statistics. No phone number is sent as an Analytics event parameter.
- Sign out is available in Settings.
- Version updated to 0.5 while retaining the Singapore rider-weather screen, area selection, NEA/MSS data, and ECMWF/GFS/ICON guidance.

Important
- Do NOT put google-services.json inside this ZIP if the ZIP is stored in a public repository.
- The supplied GitHub Actions workflow injects google-services.json from the repository secret GOOGLE_SERVICES_JSON.
- In Firebase Console, enable Authentication > Sign-in method > Phone.
- For real Android phone OTP, register the signing SHA-1/SHA-256 fingerprints for the Android app if Firebase requests them.
- Package name: com.eastweather.app
