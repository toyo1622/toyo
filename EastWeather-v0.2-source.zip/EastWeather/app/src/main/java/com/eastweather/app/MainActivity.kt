package com.eastweather.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.time.Duration
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import org.json.JSONObject
import kotlin.concurrent.thread
import kotlin.math.pow

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var current: TextView
    private lateinit var official: TextView
    private lateinit var rain: TextView
    private lateinit var slots: TextView
    private lateinit var grab: TextView

    private val zone = ZoneId.of("Asia/Singapore")
    private val tampinesLat = 1.345
    private val tampinesLon = 103.944
    private val pasirLat = 1.370
    private val pasirLon = 103.948

    data class Station(val id: String, val name: String, val lat: Double, val lon: Double)
    data class ReadingSet(
        val timestamp: String,
        val unit: String,
        val stations: List<Station>,
        val values: Map<String, Double>
    )
    data class AreaModel(
        val temp: Double,
        val wind: Double,
        val gust: Double,
        val blocks: IntArray,
        val spreads: IntArray
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 34, 32, 40)
            setBackgroundColor(Color.WHITE)
        }
        scroll.addView(root)
        setContentView(scroll)

        text("东部 Grab 天气", 27, Color.BLACK)
        text("Tampines + Pasir Ris｜NEA/MSS 官方优先 + 多模型", 15, Color.DKGRAY)
        status = text("正在更新天气…", 14, Color.GRAY)

        current = card("🌡️ 当前实况\n读取中…")
        official = card("🇸🇬 NEA/MSS 2小时官方预报\n读取中…")
        rain = card("🌧️ 5分钟实测雨量\n读取中…")
        slots = card("📊 今晚 6PM–12AM 多模型风险\n读取中…")
        grab = card("🏍️ Grab 判断\n计算中…")

        Button(this).apply {
            text = "重新更新"
            textSize = 17f
            setOnClickListener { load() }
            root.addView(this, LinearLayout.LayoutParams(-1, 145).apply { topMargin = 20 })
        }
        text(
            "说明：NEA/MSS 2小时预报与本地实测优先；ECMWF、GFS、ICON 用来补足未来数小时。百分比为多模型综合风险，不是 NEA 官方降雨概率。",
            13,
            Color.GRAY
        )
        load()
    }

    private fun text(s: String, size: Int, color: Int): TextView {
        val v = TextView(this)
        v.text = s
        v.textSize = size.toFloat()
        v.setTextColor(color)
        v.setPadding(0, 8, 0, 8)
        root.addView(v)
        return v
    }

    private fun card(s: String): TextView {
        val v = TextView(this)
        v.text = s
        v.textSize = 17f
        v.setTextColor(Color.BLACK)
        v.setPadding(24, 24, 24, 24)
        v.setBackgroundColor(Color.rgb(245, 247, 250))
        root.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 })
        return v
    }

    private fun getJson(urlText: String): JSONObject? {
        return try {
            val c = URL(urlText).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 12000
            c.requestMethod = "GET"
            c.setRequestProperty("User-Agent", "EastWeather/0.2 Android")
            c.inputStream.bufferedReader().use { JSONObject(it.readText()) }
        } catch (_: Exception) {
            null
        }
    }

    private fun parseReading(root: JSONObject?): ReadingSet? {
        if (root == null || root.optInt("code", -1) != 0) return null
        return try {
            val data = root.getJSONObject("data")
            val stationsJson = data.getJSONArray("stations")
            val stations = mutableListOf<Station>()
            for (i in 0 until stationsJson.length()) {
                val s = stationsJson.getJSONObject(i)
                val loc = s.getJSONObject("location")
                stations.add(
                    Station(
                        s.getString("id"),
                        s.optString("name", s.getString("id")),
                        loc.getDouble("latitude"),
                        loc.getDouble("longitude")
                    )
                )
            }
            val readings = data.getJSONArray("readings").getJSONObject(0)
            val valuesJson = readings.getJSONArray("data")
            val values = mutableMapOf<String, Double>()
            for (i in 0 until valuesJson.length()) {
                val x = valuesJson.getJSONObject(i)
                values[x.getString("stationId")] = x.getDouble("value")
            }
            ReadingSet(
                readings.getString("timestamp"),
                data.optString("readingUnit", ""),
                stations,
                values
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun nearest(reading: ReadingSet?, lat: Double, lon: Double): Pair<Station, Double>? {
        if (reading == null) return null
        val usable = reading.stations.filter { reading.values.containsKey(it.id) }
        if (usable.isEmpty()) return null
        val s = usable.minByOrNull { (it.lat - lat).pow(2) + (it.lon - lon).pow(2) } ?: return null
        return s to (reading.values[s.id] ?: 0.0)
    }

    private fun formatTime(iso: String): String {
        return try {
            ZonedDateTime.parse(iso).withZoneSameInstant(zone).format(DateTimeFormatter.ofPattern("HH:mm"))
        } catch (_: Exception) {
            iso.takeLast(8).take(5)
        }
    }

    private fun translateForecast(raw: String): String {
        val s = raw.lowercase()
        return when {
            "thundery" in s -> "雷阵雨"
            "heavy rain" in s -> "大雨"
            "moderate rain" in s -> "中雨"
            "light rain" in s -> "小雨"
            "showers" in s -> "阵雨"
            "rain" in s -> "有雨"
            "windy" in s -> "有风"
            "partly cloudy" in s -> "局部多云"
            "cloudy" in s -> "多云"
            "fair" in s -> "晴到少云"
            else -> raw
        }
    }

    private fun severity(raw: String): Int {
        val s = raw.lowercase()
        return when {
            "thundery" in s || "heavy rain" in s -> 3
            "showers" in s || "rain" in s -> 2
            "windy" in s -> 1
            else -> 0
        }
    }

    private fun neaForecast(root: JSONObject?, area: String): Triple<String, String, String>? {
        if (root == null || root.optInt("code", -1) != 0) return null
        return try {
            val item = root.getJSONObject("data").getJSONArray("items").getJSONObject(0)
            val forecasts = item.getJSONArray("forecasts")
            var forecast = "资料不足"
            for (i in 0 until forecasts.length()) {
                val f = forecasts.getJSONObject(i)
                if (f.getString("area") == area) {
                    forecast = f.getString("forecast")
                    break
                }
            }
            val valid = item.getJSONObject("valid_period").optString("text", "")
            val updated = item.optString("update_timestamp", item.optString("timestamp", ""))
            Triple(forecast, valid, updated)
        } catch (_: Exception) {
            null
        }
    }

    private fun fetchModel(lat: Double, lon: Double): AreaModel {
        val vars = "temperature_2m,precipitation_probability,precipitation,weather_code,wind_speed_10m,wind_gusts_10m"
        val models = listOf("ecmwf_ifs025", "ncep_gfs_global", "icon_global")
        val results = models.mapNotNull { m ->
            getJson("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&hourly=$vars&models=$m&timezone=Asia%2FSingapore&forecast_days=2")
        }
        if (results.isEmpty()) throw IllegalStateException("多模型天气资料暂时不可用")

        val now = ZonedDateTime.now(zone)
        val today = now.toLocalDate().toString()

        fun indexFor(j: JSONObject, hour: Int): Int {
            val times = j.getJSONObject("hourly").getJSONArray("time")
            val target = String.format("%sT%02d:00", today, hour)
            for (i in 0 until times.length()) if (times.getString(i) == target) return i
            return -1
        }

        fun nearestIndex(j: JSONObject): Int {
            val times = j.getJSONObject("hourly").getJSONArray("time")
            var best = 0
            var bestDiff = Long.MAX_VALUE
            for (i in 0 until times.length()) {
                val d = kotlin.math.abs(Duration.between(now.toLocalDateTime(), LocalDateTime.parse(times.getString(i))).toMinutes())
                if (d < bestDiff) { best = i; bestDiff = d }
            }
            return best
        }

        fun block(a: Int, b: Int): Pair<Int, Int> {
            val modelValues = mutableListOf<Double>()
            for (j in results) {
                val probs = j.getJSONObject("hourly").getJSONArray("precipitation_probability")
                val vals = mutableListOf<Int>()
                for (h in a until b) {
                    val idx = indexFor(j, h)
                    if (idx >= 0) vals.add(probs.optInt(idx, 0))
                }
                if (vals.isNotEmpty()) modelValues.add(vals.average())
            }
            if (modelValues.isEmpty()) return 0 to 100
            val avg = modelValues.average().toInt()
            val spread = ((modelValues.maxOrNull() ?: 0.0) - (modelValues.minOrNull() ?: 0.0)).toInt()
            return avg to spread
        }

        val currentTemps = mutableListOf<Double>()
        val currentWinds = mutableListOf<Double>()
        val currentGusts = mutableListOf<Double>()
        for (j in results) {
            val h = j.getJSONObject("hourly")
            val idx = nearestIndex(j)
            currentTemps.add(h.getJSONArray("temperature_2m").optDouble(idx, Double.NaN))
            currentWinds.add(h.getJSONArray("wind_speed_10m").optDouble(idx, Double.NaN))
            currentGusts.add(h.getJSONArray("wind_gusts_10m").optDouble(idx, Double.NaN))
        }
        val b1 = block(18, 20)
        val b2 = block(20, 22)
        val b3 = block(22, 24)

        return AreaModel(
            currentTemps.filter { !it.isNaN() }.average(),
            currentWinds.filter { !it.isNaN() }.average(),
            currentGusts.filter { !it.isNaN() }.average(),
            intArrayOf(b1.first, b2.first, b3.first),
            intArrayOf(b1.second, b2.second, b3.second)
        )
    }

    private fun load() {
        status.text = "正在读取 NEA/MSS 与多模型资料…"
        thread {
            try {
                val nea2h = getJson("https://api-open.data.gov.sg/v2/real-time/api/two-hr-forecast")
                val rainfall = parseReading(getJson("https://api-open.data.gov.sg/v2/real-time/api/rainfall"))
                val tempReading = parseReading(getJson("https://api-open.data.gov.sg/v2/real-time/api/air-temperature"))
                val windReading = parseReading(getJson("https://api-open.data.gov.sg/v2/real-time/api/wind-speed"))

                val tampOfficial = neaForecast(nea2h, "Tampines")
                val pasirOfficial = neaForecast(nea2h, "Pasir Ris")

                val tampRain = nearest(rainfall, tampinesLat, tampinesLon)
                val pasirRain = nearest(rainfall, pasirLat, pasirLon)
                val eastTemp = nearest(tempReading, (tampinesLat + pasirLat) / 2.0, (tampinesLon + pasirLon) / 2.0)
                val eastWind = nearest(windReading, (tampinesLat + pasirLat) / 2.0, (tampinesLon + pasirLon) / 2.0)

                val tampModel = fetchModel(tampinesLat, tampinesLon)
                val pasirModel = fetchModel(pasirLat, pasirLon)

                val tempC = eastTemp?.second ?: ((tampModel.temp + pasirModel.temp) / 2.0)
                val windKmh = eastWind?.second?.times(1.852) ?: ((tampModel.wind + pasirModel.wind) / 2.0)
                val gustKmh = (tampModel.gust + pasirModel.gust) / 2.0

                val avgBlocks = IntArray(3) { i -> ((tampModel.blocks[i] + pasirModel.blocks[i]) / 2.0).toInt() }
                val maxSpreads = IntArray(3) { i -> maxOf(tampModel.spreads[i], pasirModel.spreads[i]) }

                val now = ZonedDateTime.now(zone)
                val relevantIndex = when {
                    now.hour < 20 -> 0
                    now.hour < 22 -> 1
                    else -> 2
                }
                val remainingMax = when (relevantIndex) {
                    0 -> maxOf(avgBlocks[0], avgBlocks[1], avgBlocks[2])
                    1 -> maxOf(avgBlocks[1], avgBlocks[2])
                    else -> avgBlocks[2]
                }
                val spread = maxSpreads[relevantIndex]

                val tRaw = tampOfficial?.first ?: "官方资料暂不可用"
                val pRaw = pasirOfficial?.first ?: "官方资料暂不可用"
                val officialSeverity = maxOf(severity(tRaw), severity(pRaw))
                val tRain = tampRain?.second ?: 0.0
                val pRain = pasirRain?.second ?: 0.0
                val localRainMax = maxOf(tRain, pRain)

                val advice = when {
                    officialSeverity >= 3 || localRainMax >= 1.0 || remainingMax >= 75 -> "🔴 不建议贸然开工"
                    officialSeverity >= 2 || localRainMax > 0.0 || remainingMax >= 45 -> "🟡 需要观察雷达后再决定"
                    else -> "🟢 天气风险相对较低"
                }

                val confidence = when {
                    spread <= 20 && tampOfficial != null && pasirOfficial != null -> "较高"
                    spread <= 35 -> "中等"
                    else -> "较低"
                }

                val topRain = if (rainfall != null) {
                    rainfall.values.entries
                        .filter { it.value > 0.0 }
                        .sortedByDescending { it.value }
                        .take(3)
                        .map { e ->
                            val name = rainfall.stations.firstOrNull { it.id == e.key }?.name ?: e.key
                            "$name ${"%.1f".format(e.value)} mm"
                        }
                } else emptyList()

                val neaValid = tampOfficial?.second ?: pasirOfficial?.second ?: ""
                val neaUpdated = tampOfficial?.third ?: pasirOfficial?.third ?: ""
                val rainUpdated = rainfall?.timestamp ?: ""
                val appUpdated = now.format(DateTimeFormatter.ofPattern("HH:mm"))

                val officialText = buildString {
                    append("🇸🇬 NEA/MSS 未来2小时")
                    if (neaValid.isNotBlank()) append("｜$neaValid")
                    append("\nTampines：${translateForecast(tRaw)}")
                    append("\nPasir Ris：${translateForecast(pRaw)}")
                    if (neaUpdated.isNotBlank()) append("\n官方更新：${formatTime(neaUpdated)}")
                }

                val rainText = buildString {
                    append("🌧️ NEA 5分钟实测雨量")
                    append("\nTampines：${"%.1f".format(tRain)} mm")
                    if (tampRain != null) append("｜${tampRain.first.name}")
                    append("\nPasir Ris：${"%.1f".format(pRain)} mm")
                    if (pasirRain != null) append("｜${pasirRain.first.name}")
                    if (rainUpdated.isNotBlank()) append("\n实况时间：${formatTime(rainUpdated)}")
                    append("\n\n当前较大雨量站点：")
                    if (topRain.isEmpty()) append("暂无明显降雨") else append("\n" + topRain.joinToString("\n"))
                }

                fun line(label: String, idx: Int): String {
                    val avg = avgBlocks[idx]
                    val dry = 100 - avg
                    return "$label：$avg%（无雨参考 $dry%）\n  Tampines ${tampModel.blocks[idx]}%｜Pasir Ris ${pasirModel.blocks[idx]}%"
                }

                val slotText = "📊 多模型综合降雨风险\n" +
                    line("6–8 PM", 0) + "\n" +
                    line("8–10 PM", 1) + "\n" +
                    line("10 PM–12 AM", 2) +
                    "\n模型：ECMWF + GFS + ICON"

                val reason = buildString {
                    append("NEA：Tampines ${translateForecast(tRaw)}；Pasir Ris ${translateForecast(pRaw)}")
                    append("\n本地实测：Tampines ${"%.1f".format(tRain)} mm；Pasir Ris ${"%.1f".format(pRain)} mm / 5分钟")
                    append("\n剩余时段模型最高风险：$remainingMax%")
                    append("\n模型一致度信心：$confidence")
                }

                runOnUiThread {
                    status.text = "已更新 $appUpdated｜NEA/MSS + ECMWF + GFS + ICON（第二版）"
                    current.text = "🌡️ 当前东部实况\n温度 ${"%.1f".format(tempC)}°C\n风速 ${"%.1f".format(windKmh)} km/h｜模型阵风参考 ${"%.1f".format(gustKmh)} km/h"
                    official.text = officialText
                    rain.text = rainText
                    slots.text = slotText
                    grab.text = "🏍️ Grab 判断\n$advice\n\n$reason"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "更新失败：${e.message ?: "网络或天气资料暂时不可用"}"
                }
            }
        }
    }
}
