package com.eastweather.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.content.Context
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.time.Duration
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import org.json.JSONObject
import kotlin.concurrent.thread
import kotlin.math.pow

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var selectedText: TextView
    private lateinit var summary: TextView
    private lateinit var regionContainer: LinearLayout
    private lateinit var chooseButton: Button

    private val zone = ZoneId.of("Asia/Singapore")
    private val prefs by lazy { getSharedPreferences("east_weather", Context.MODE_PRIVATE) }

    data class AreaDef(val name: String, val zh: String, val lat: Double, val lon: Double) {
        fun label() = "$name $zh"
    }
    data class Station(val id: String, val name: String, val lat: Double, val lon: Double)
    data class ReadingSet(
        val timestamp: String,
        val unit: String,
        val stations: List<Station>,
        val values: Map<String, Double>
    )
    data class AreaModel(
        val temp: Double,
        val wind: Double,
        val gust: Double,
        val blocks: IntArray,
        val spreads: IntArray
    )
    data class AreaResult(
        val area: AreaDef,
        val forecastRaw: String,
        val rainMm: Double,
        val rainStation: String,
        val tempC: Double,
        val windKmh: Double,
        val gustKmh: Double,
        val model: AreaModel,
        val adviceLevel: Int,
        val adviceText: String,
        val confidence: String
    )

    private val areas = listOf(
        AreaDef("Tampines", "淡滨尼", 1.345, 103.944),
        AreaDef("Pasir Ris", "巴西立", 1.370, 103.948),
        AreaDef("Bedok", "勿洛", 1.321, 103.924),
        AreaDef("Changi", "樟宜", 1.357, 103.987),
        AreaDef("Paya Lebar", "巴耶利峇", 1.358, 103.914),
        AreaDef("Hougang", "后港", 1.361218, 103.886),
        AreaDef("Punggol", "榜鹅", 1.401, 103.904),
        AreaDef("Sengkang", "盛港", 1.384, 103.891443),
        AreaDef("Serangoon", "实龙岗", 1.357, 103.865),
        AreaDef("Geylang", "芽笼", 1.318, 103.884),
        AreaDef("Marine Parade", "马林百列", 1.297, 103.891),
        AreaDef("Kallang", "加冷", 1.312, 103.862),
        AreaDef("City", "市中心", 1.292, 103.844),
        AreaDef("Toa Payoh", "大巴窑", 1.334304, 103.856327),
        AreaDef("Ang Mo Kio", "宏茂桥", 1.375, 103.839),
        AreaDef("Bishan", "碧山", 1.350772, 103.839),
        AreaDef("Woodlands", "兀兰", 1.432, 103.786528),
        AreaDef("Yishun", "义顺", 1.418, 103.839),
        AreaDef("Sembawang", "三巴旺", 1.445, 103.818495),
        AreaDef("Jurong East", "裕廊东", 1.326, 103.737),
        AreaDef("Jurong West", "裕廊西", 1.34039, 103.705),
        AreaDef("Clementi", "金文泰", 1.315, 103.760),
        AreaDef("Bukit Batok", "武吉巴督", 1.353, 103.754),
        AreaDef("Queenstown", "女皇镇", 1.291, 103.78576),
        AreaDef("Sentosa", "圣淘沙", 1.243, 103.832)
    )

    private val defaultNames = listOf("Tampines", "Pasir Ris", "Bedok", "Changi")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 30, 28, 40)
            setBackgroundColor(Color.WHITE)
        }
        scroll.addView(root)
        setContentView(scroll)

        text("新加坡 Grab 天气", 27, Color.BLACK)
        text("NEA/MSS 官方优先 + ECMWF/GFS/ICON 多模型", 15, Color.DKGRAY)
        status = text("正在准备…", 14, Color.GRAY)

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chooseButton = Button(this).apply {
            text = "选择地区"
            textSize = 16f
            setOnClickListener { showAreaPicker() }
        }
        val refresh = Button(this).apply {
            text = "重新更新"
            textSize = 16f
            setOnClickListener { load() }
        }
        controls.addView(chooseButton, LinearLayout.LayoutParams(0, 130, 1f).apply { marginEnd = 8 })
        controls.addView(refresh, LinearLayout.LayoutParams(0, 130, 1f).apply { marginStart = 8 })
        root.addView(controls, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })

        selectedText = text("", 14, Color.DKGRAY)
        summary = card("🏍️ 多地区 Grab 总览\n读取中…")
        regionContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(regionContainer)

        text(
            "说明：可一次选择最多6个地区；选择会自动保存。NEA/MSS 2小时预报与本地实测优先，多模型用来补足未来数小时。已经过去的晚间时段会自动隐藏。",
            13,
            Color.GRAY
        )
        updateSelectedLabel()
        load()
    }

    private fun text(s: String, size: Int, color: Int): TextView {
        val v = TextView(this)
        v.text = s
        v.textSize = size.toFloat()
        v.setTextColor(color)
        v.setPadding(0, 8, 0, 8)
        root.addView(v)
        return v
    }

    private fun card(s: String): TextView {
        val v = TextView(this)
        v.text = s
        v.textSize = 17f
        v.setTextColor(Color.BLACK)
        v.setPadding(24, 24, 24, 24)
        v.setBackgroundColor(Color.rgb(245, 247, 250))
        root.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 })
        return v
    }

    private fun addRegionCard(s: String): TextView {
        val v = TextView(this)
        v.text = s
        v.textSize = 16.5f
        v.setTextColor(Color.BLACK)
        v.setPadding(24, 24, 24, 24)
        v.setBackgroundColor(Color.rgb(245, 247, 250))
        regionContainer.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 })
        return v
    }

    private fun selectedNames(): List<String> {
        val saved = prefs.getString("selected_areas", null)
        val list = saved?.split("|")?.filter { it.isNotBlank() } ?: defaultNames
        return list.filter { n -> areas.any { it.name == n } }.ifEmpty { defaultNames }
    }

    private fun selectedAreas(): List<AreaDef> {
        val names = selectedNames()
        return names.mapNotNull { n -> areas.firstOrNull { it.name == n } }
    }

    private fun saveSelected(names: List<String>) {
        prefs.edit().putString("selected_areas", names.joinToString("|")).apply()
    }

    private fun updateSelectedLabel() {
        val picked = selectedAreas()
        chooseButton.text = "选择地区（${picked.size}）"
        selectedText.text = "常用地区：" + picked.joinToString("、") { it.label() }
    }

    private fun showAreaPicker() {
        val current = selectedNames().toMutableSet()
        val labels = areas.map { it.label() }.toTypedArray()
        val checked = BooleanArray(areas.size) { i -> current.contains(areas[i].name) }
        val dialog = AlertDialog.Builder(this)
            .setTitle("选择常用地区（最多6个）")
            .setMultiChoiceItems(labels, checked) { d, which, isChecked ->
                checked[which] = isChecked
                if (isChecked) {
                    val count = checked.count { it }
                    if (count > 6) {
                        checked[which] = false
                        (d as? AlertDialog)?.listView?.setItemChecked(which, false)
                        Toast.makeText(this, "一次最多选择6个地区", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("取消", null)
            .setPositiveButton("保存", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val names = areas.indices.filter { checked[it] }.map { areas[it].name }
                if (names.isEmpty()) {
                    Toast.makeText(this, "至少选择1个地区", Toast.LENGTH_SHORT).show()
                } else {
                    saveSelected(names)
                    updateSelectedLabel()
                    dialog.dismiss()
                    load()
                }
            }
        }
        dialog.show()
    }

    private fun getJson(urlText: String): JSONObject? {
        return try {
            val c = URL(urlText).openConnection() as HttpURLConnection
            c.connectTimeout = 9000
            c.readTimeout = 14000
            c.requestMethod = "GET"
            c.setRequestProperty("User-Agent", "EastWeather/0.3 Android")
            c.inputStream.bufferedReader().use { JSONObject(it.readText()) }
        } catch (_: Exception) {
            null
        }
    }

    private fun parseReading(root: JSONObject?): ReadingSet? {
        if (root == null || root.optInt("code", -1) != 0) return null
        return try {
            val data = root.getJSONObject("data")
            val stationsJson = data.getJSONArray("stations")
            val stations = mutableListOf<Station>()
            for (i in 0 until stationsJson.length()) {
                val s = stationsJson.getJSONObject(i)
                val loc = s.getJSONObject("location")
                stations.add(
                    Station(
                        s.getString("id"),
                        s.optString("name", s.getString("id")),
                        loc.getDouble("latitude"),
                        loc.getDouble("longitude")
                    )
                )
            }
            val readings = data.getJSONArray("readings").getJSONObject(0)
            val valuesJson = readings.getJSONArray("data")
            val values = mutableMapOf<String, Double>()
            for (i in 0 until valuesJson.length()) {
                val x = valuesJson.getJSONObject(i)
                values[x.getString("stationId")] = x.getDouble("value")
            }
            ReadingSet(
                readings.getString("timestamp"),
                data.optString("readingUnit", ""),
                stations,
                values
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun nearest(reading: ReadingSet?, lat: Double, lon: Double): Pair<Station, Double>? {
        if (reading == null) return null
        val usable = reading.stations.filter { reading.values.containsKey(it.id) }
        if (usable.isEmpty()) return null
        val s = usable.minByOrNull { (it.lat - lat).pow(2) + (it.lon - lon).pow(2) } ?: return null
        return s to (reading.values[s.id] ?: 0.0)
    }

    private fun formatTime(iso: String): String {
        return try {
            ZonedDateTime.parse(iso).withZoneSameInstant(zone).format(DateTimeFormatter.ofPattern("HH:mm"))
        } catch (_: Exception) {
            iso.takeLast(8).take(5)
        }
    }

    private fun translateForecast(raw: String): String {
        val s = raw.lowercase()
        return when {
            "thundery" in s -> "雷阵雨"
            "heavy rain" in s -> "大雨"
            "moderate rain" in s -> "中雨"
            "light rain" in s -> "小雨"
            "showers" in s -> "阵雨"
            "rain" in s -> "有雨"
            "windy" in s -> "有风"
            "partly cloudy" in s -> "局部多云"
            "cloudy" in s -> "多云"
            "fair" in s -> "晴到少云"
            else -> raw
        }
    }

    private fun severity(raw: String): Int {
        val s = raw.lowercase()
        return when {
            "thundery" in s || "heavy rain" in s -> 3
            "moderate rain" in s || "showers" in s || "rain" in s -> 2
            "windy" in s -> 1
            else -> 0
        }
    }

    private fun neaForecastMap(root: JSONObject?): Triple<Map<String, String>, String, String> {
        if (root == null || root.optInt("code", -1) != 0) return Triple(emptyMap(), "", "")
        return try {
            val item = root.getJSONObject("data").getJSONArray("items").getJSONObject(0)
            val forecasts = item.getJSONArray("forecasts")
            val map = mutableMapOf<String, String>()
            for (i in 0 until forecasts.length()) {
                val f = forecasts.getJSONObject(i)
                map[f.getString("area")] = f.getString("forecast")
            }
            val valid = item.getJSONObject("valid_period").optString("text", "")
            val updated = item.optString("update_timestamp", item.optString("timestamp", ""))
            Triple(map, valid, updated)
        } catch (_: Exception) {
            Triple(emptyMap(), "", "")
        }
    }

    private fun fetchModel(lat: Double, lon: Double): AreaModel {
        val vars = "temperature_2m,precipitation_probability,precipitation,weather_code,wind_speed_10m,wind_gusts_10m"
        val models = listOf("ecmwf_ifs025", "ncep_gfs_global", "icon_global")
        val results = models.mapNotNull { m ->
            getJson("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&hourly=$vars&models=$m&timezone=Asia%2FSingapore&forecast_days=2")
        }
        if (results.isEmpty()) throw IllegalStateException("多模型资料暂时不可用")

        val now = ZonedDateTime.now(zone)
        val today = now.toLocalDate().toString()

        fun indexFor(j: JSONObject, hour: Int): Int {
            val times = j.getJSONObject("hourly").getJSONArray("time")
            val target = String.format("%sT%02d:00", today, hour)
            for (i in 0 until times.length()) if (times.getString(i) == target) return i
            return -1
        }

        fun nearestIndex(j: JSONObject): Int {
            val times = j.getJSONObject("hourly").getJSONArray("time")
            var best = 0
            var bestDiff = Long.MAX_VALUE
            for (i in 0 until times.length()) {
                val d = kotlin.math.abs(Duration.between(now.toLocalDateTime(), LocalDateTime.parse(times.getString(i))).toMinutes())
                if (d < bestDiff) { best = i; bestDiff = d }
            }
            return best
        }

        fun block(a: Int, b: Int): Pair<Int, Int> {
            val modelValues = mutableListOf<Double>()
            for (j in results) {
                val probs = j.getJSONObject("hourly").getJSONArray("precipitation_probability")
                val vals = mutableListOf<Int>()
                for (h in a until b) {
                    val idx = indexFor(j, h)
                    if (idx >= 0) vals.add(probs.optInt(idx, 0))
                }
                if (vals.isNotEmpty()) modelValues.add(vals.average())
            }
            if (modelValues.isEmpty()) return 0 to 100
            val avg = modelValues.average().toInt()
            val spread = ((modelValues.maxOrNull() ?: 0.0) - (modelValues.minOrNull() ?: 0.0)).toInt()
            return avg to spread
        }

        val currentTemps = mutableListOf<Double>()
        val currentWinds = mutableListOf<Double>()
        val currentGusts = mutableListOf<Double>()
        for (j in results) {
            val h = j.getJSONObject("hourly")
            val idx = nearestIndex(j)
            currentTemps.add(h.getJSONArray("temperature_2m").optDouble(idx, Double.NaN))
            currentWinds.add(h.getJSONArray("wind_speed_10m").optDouble(idx, Double.NaN))
            currentGusts.add(h.getJSONArray("wind_gusts_10m").optDouble(idx, Double.NaN))
        }
        val b1 = block(18, 20)
        val b2 = block(20, 22)
        val b3 = block(22, 24)
        return AreaModel(
            currentTemps.filter { !it.isNaN() }.average(),
            currentWinds.filter { !it.isNaN() }.average(),
            currentGusts.filter { !it.isNaN() }.average(),
            intArrayOf(b1.first, b2.first, b3.first),
            intArrayOf(b1.second, b2.second, b3.second)
        )
    }

    private fun visibleBlocks(now: ZonedDateTime): List<Int> {
        return when {
            now.hour in 0..5 -> emptyList()
            now.hour < 20 -> listOf(0, 1, 2)
            now.hour < 22 -> listOf(1, 2)
            else -> listOf(2)
        }
    }

    private fun blockLabel(idx: Int): String = when (idx) {
        0 -> "6–8 PM"
        1 -> "8–10 PM"
        else -> "10 PM–12 AM"
    }

    private fun load() {
        val picked = selectedAreas()
        updateSelectedLabel()
        status.text = "正在读取 ${picked.size} 个地区的官方与多模型资料…"
        summary.text = "🏍️ 多地区 Grab 总览\n计算中…"
        regionContainer.removeAllViews()
        addRegionCard("读取中…")

        thread {
            try {
                val nea2h = getJson("https://api-open.data.gov.sg/v2/real-time/api/two-hr-forecast")
                val rainfall = parseReading(getJson("https://api-open.data.gov.sg/v2/real-time/api/rainfall"))
                val tempReading = parseReading(getJson("https://api-open.data.gov.sg/v2/real-time/api/air-temperature"))
                val windReading = parseReading(getJson("https://api-open.data.gov.sg/v2/real-time/api/wind-speed"))
                val (forecastMap, neaValid, neaUpdated) = neaForecastMap(nea2h)
                val now = ZonedDateTime.now(zone)
                val active = visibleBlocks(now)

                val results = mutableListOf<AreaResult>()
                for (area in picked) {
                    val model = fetchModel(area.lat, area.lon)
                    val rainNear = nearest(rainfall, area.lat, area.lon)
                    val tempNear = nearest(tempReading, area.lat, area.lon)
                    val windNear = nearest(windReading, area.lat, area.lon)
                    val forecastRaw = forecastMap[area.name] ?: "官方资料暂不可用"
                    val rainMm = rainNear?.second ?: 0.0
                    val tempC = tempNear?.second ?: model.temp
                    val windKmh = windNear?.second?.times(1.852) ?: model.wind
                    val remainingMax = if (active.isEmpty()) 0 else active.maxOf { model.blocks[it] }
                    val spread = if (active.isEmpty()) 100 else active.maxOf { model.spreads[it] }
                    val sev = severity(forecastRaw)
                    val level = when {
                        sev >= 3 || rainMm >= 1.0 || remainingMax >= 75 -> 2
                        sev >= 2 || rainMm > 0.0 || remainingMax >= 45 -> 1
                        else -> 0
                    }
                    val advice = when (level) {
                        2 -> "🔴 暂不建议"
                        1 -> "🟡 先观察"
                        else -> "🟢 较适合"
                    }
                    val confidence = when {
                        spread <= 20 && forecastMap.containsKey(area.name) -> "较高"
                        spread <= 35 -> "中等"
                        else -> "较低"
                    }
                    results.add(
                        AreaResult(
                            area, forecastRaw, rainMm, rainNear?.first?.name ?: "附近测站",
                            tempC, windKmh, model.gust, model, level, advice, confidence
                        )
                    )
                }

                val green = results.filter { it.adviceLevel == 0 }.map { it.area.name }
                val yellow = results.filter { it.adviceLevel == 1 }.map { it.area.name }
                val red = results.filter { it.adviceLevel == 2 }.map { it.area.name }
                val summaryText = buildString {
                    append("🏍️ 多地区 Grab 总览")
                    if (green.isNotEmpty()) append("\n🟢 较适合：${green.joinToString("、")}")
                    if (yellow.isNotEmpty()) append("\n🟡 观察：${yellow.joinToString("、")}")
                    if (red.isNotEmpty()) append("\n🔴 暂不建议：${red.joinToString("、")}")
                    if (active.isEmpty()) append("\n\n今晚 6PM–12AM 时段已结束。")
                    else append("\n\n判断以 NEA/MSS + 最近雨量站 + 剩余时段多模型为依据。")
                }

                val cards = results.map { r ->
                    buildString {
                        append("📍 ${r.area.label()}")
                        append("\n🇸🇬 NEA/MSS：${translateForecast(r.forecastRaw)}")
                        append("\n🌧️ 5分钟雨量：${"%.1f".format(r.rainMm)} mm｜${r.rainStation}")
                        append("\n🌡️ ${"%.1f".format(r.tempC)}°C｜风 ${"%.1f".format(r.windKmh)} km/h｜阵风参考 ${"%.1f".format(r.gustKmh)} km/h")
                        if (active.isEmpty()) {
                            append("\n📊 晚间模型：当前不在 6PM–12AM 判断时段")
                        } else {
                            append("\n📊 剩余时段模型风险：")
                            active.forEach { idx ->
                                append("\n   ${blockLabel(idx)}：${r.model.blocks[idx]}%（无雨参考 ${100 - r.model.blocks[idx]}%）")
                            }
                        }
                        append("\n🏍️ ${r.adviceText}｜信心 ${r.confidence}")
                    }
                }

                val appUpdated = now.format(DateTimeFormatter.ofPattern("HH:mm"))
                val rainUpdated = rainfall?.timestamp ?: ""
                runOnUiThread {
                    status.text = buildString {
                        append("已更新 $appUpdated｜第三版")
                        if (neaUpdated.isNotBlank()) append("｜NEA ${formatTime(neaUpdated)}")
                        if (rainUpdated.isNotBlank()) append("｜雨量 ${formatTime(rainUpdated)}")
                        if (neaValid.isNotBlank()) append("\nNEA有效：$neaValid")
                    }
                    summary.text = summaryText
                    regionContainer.removeAllViews()
                    cards.forEach { addRegionCard(it) }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "更新失败：${e.message ?: "网络或天气资料暂时不可用"}"
                    summary.text = "🏍️ 多地区 Grab 总览\n暂时无法完成判断"
                    regionContainer.removeAllViews()
                    addRegionCard("请稍后按“重新更新”再试。")
                }
            }
        }
    }
}
