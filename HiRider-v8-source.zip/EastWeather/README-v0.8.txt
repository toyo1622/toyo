Hi Rider v0.8 - country picker, Malaysia expansion, overnight forecast, weather alerts

Version
- versionCode 8
- versionName 0.8
- Login/About/User-Agent strings updated to v0.8.
- Designed to update over earlier builds when signed with the same permanent release key.

Area selection
- Country-first picker: choose Singapore or Malaysia first, then choose areas.
- Maximum 6 selected areas total across both countries.
- Singapore keeps the existing area list and NEA/MSS + nearby observation-station logic.
- Malaysia keeps a separate model-only path and never attaches to Singapore NEA stations.

Malaysia coverage
- Johor: all 10 districts are represented, with major rider towns/corridors including Johor Bahru, Skudai, Ulu Tiram, Iskandar Puteri, Gelang Patah, Pasir Gudang, Masai, Senai, Kulai, Pontian, Pekan Nanas, Kota Tinggi, Desaru, Pengerang, Kluang, Simpang Renggam, Ayer Hitam, Batu Pahat, Parit Raja, Rengit, Yong Peng, Muar, Tangkak, Segamat, Labis, Chaah, Mersing and Endau.
- Kuala Lumpur: Kuala Lumpur, KLCC, Cheras, Kepong, Setapak, Bukit Jalil.
- Selangor / Klang Valley: Serdang, Seri Kembangan, Cyberjaya, Petaling Jaya, Shah Alam, Subang Jaya, Puchong, Kajang, Bangi, Ampang, Klang.
- Putrajaya added as its own federal-territory group.

Clock display
- User-facing times use a 12-hour clock. English shows AM/PM; Chinese shows 上午/下午/晚上/凌晨.
- Internal forecast calculations still use 24-hour values, so forecast logic and the 03:00 overnight cutoff are unchanged.

Hourly forecast window
- Earliest selectable start time is 06:00.
- Start time can be selected from 06:00 through 23:00.
- Forecast continues hourly across midnight through 03:00 the following day.
- Hours after midnight are labelled as Next day / 隔天.

Weather alerts
- Android POST_NOTIFICATIONS permission added for Android 13+.
- WorkManager checks selected areas approximately once per hour while alerts are enabled.
- Background alert uses ECMWF / GFS / ICON model guidance and warns for likely rain or strong gusts in the next hour.
- Duplicate alerts for the same area and target hour are suppressed.
- Alerts can be turned on/off in Settings.

Important build note
- This source package still does not include a Gradle wrapper or Android SDK environment.
- Kotlin parsing can be checked locally, but a full Android build should be run in the existing GitHub Actions environment or Android Studio.
