package com.eastweather.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.time.Duration
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale
import kotlin.math.abs

class WeatherAlertWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : Worker(appContext, workerParams) {

    private data class Area(
        val name: String,
        val zh: String,
        val lat: Double,
        val lon: Double,
        val country: String
    )

    private data class Point(
        val time: ZonedDateTime,
        val probability: Double,
        val rainMm: Double,
        val gustKmh: Double
    )

    private val zone = ZoneId.of("Asia/Singapore")
    private val models = listOf("ecmwf_ifs025", "ncep_gfs_global", "icon_global")

    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("hi_rider", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("weather_alerts", true)) return Result.success()

        val jsonText = inputData.getString("areas_json").orEmpty()
        if (jsonText.isBlank()) return Result.success()
        val isZh = inputData.getString("language") == "zh"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            applicationContext.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return Result.success()
        val areas = parseAreas(jsonText)
        if (areas.isEmpty()) return Result.success()

        val now = ZonedDateTime.now(zone)
        val target = now.plusHours(1).withMinute(0).withSecond(0).withNano(0)
        var anyWeatherResponse = false

        areas.forEach { area ->
            val points = models.mapNotNull { model ->
                runCatching { fetchNearest(area, model, target) }.getOrNull()
            }
            if (points.isEmpty()) return@forEach
            anyWeatherResponse = true

            val probabilities = points.map { it.probability }.filterNot { it.isNaN() }
            val rains = points.map { it.rainMm }.filterNot { it.isNaN() }
            val gusts = points.map { it.gustKmh }.filterNot { it.isNaN() }
            val probability = probabilities.averageOrNaN()
            val rainMm = rains.averageOrNaN()
            val gustKmh = gusts.maxOrNull() ?: Double.NaN

            val severity = when {
                (!probability.isNaN() && probability >= 70.0) ||
                    (!rainMm.isNaN() && rainMm >= 4.0) ||
                    (!gustKmh.isNaN() && gustKmh >= 55.0) -> 2
                (!probability.isNaN() && probability >= 55.0) ||
                    (!rainMm.isNaN() && rainMm >= 1.0) ||
                    (!gustKmh.isNaN() && gustKmh >= 45.0) -> 1
                else -> 0
            }
            if (severity == 0) return@forEach

            val alertKey = "${area.name}|${target}"
            val prefKey = "last_weather_alert_${area.name.replace(" ", "_")}".lowercase(Locale.ROOT)
            if (prefs.getString(prefKey, null) == alertKey) return@forEach

            showNotification(area, target, probability, rainMm, gustKmh, severity, isZh)
            prefs.edit().putString(prefKey, alertKey).apply()
        }

        return if (anyWeatherResponse) Result.success() else Result.retry()
    }

    private fun parseAreas(text: String): List<Area> {
        val arr = runCatching { JSONArray(text) }.getOrNull() ?: return emptyList()
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val name = o.optString("name")
                if (name.isBlank()) continue
                add(
                    Area(
                        name = name,
                        zh = o.optString("zh", name),
                        lat = o.optDouble("lat"),
                        lon = o.optDouble("lon"),
                        country = o.optString("country", "SG")
                    )
                )
            }
        }
    }

    private fun fetchNearest(area: Area, model: String, target: ZonedDateTime): Point? {
        val url = buildString {
            append("https://api.open-meteo.com/v1/forecast?latitude=").append(area.lat)
            append("&longitude=").append(area.lon)
            append("&hourly=precipitation_probability,precipitation,wind_gusts_10m")
            append("&models=").append(model)
            append("&timezone=").append(if (area.country == "MY") "Asia%2FKuala_Lumpur" else "Asia%2FSingapore")
            append("&forecast_days=2")
        }
        val json = getJson(url)
        val hourly = json.optJSONObject("hourly") ?: return null
        val times = hourly.optJSONArray("time") ?: JSONArray()
        val probs = hourly.optJSONArray("precipitation_probability") ?: JSONArray()
        val rain = hourly.optJSONArray("precipitation") ?: JSONArray()
        val gusts = hourly.optJSONArray("wind_gusts_10m") ?: JSONArray()

        var nearest: Point? = null
        var nearestMinutes = Long.MAX_VALUE
        for (i in 0 until times.length()) {
            val ldt = runCatching { LocalDateTime.parse(times.optString(i)) }.getOrNull() ?: continue
            val time = ldt.atZone(zone)
            val diff = abs(Duration.between(time, target).toMinutes())
            if (diff > 90 || diff >= nearestMinutes) continue
            nearestMinutes = diff
            nearest = Point(
                time = time,
                probability = probs.optDouble(i, Double.NaN),
                rainMm = rain.optDouble(i, Double.NaN),
                gustKmh = gusts.optDouble(i, Double.NaN)
            )
        }
        return nearest
    }

    private fun showNotification(
        area: Area,
        target: ZonedDateTime,
        probability: Double,
        rainMm: Double,
        gustKmh: Double,
        severity: Int,
        isZh: Boolean
    ) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "hirider_weather_alerts"
        val channel = NotificationChannel(
            channelId,
            if (isZh) "Hi Rider 天气预警" else "Hi Rider Weather Alerts",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = if (isZh) "下一小时降雨和强阵风提醒" else "Next-hour rain and strong-gust alerts"
        }
        manager.createNotificationChannel(channel)

        val intent = Intent(applicationContext, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            applicationContext,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val place = if (isZh) area.zh else area.name
        val timeText = formatTime12(target.hour, isZh)
        val details = buildList {
            if (!probability.isNaN()) add(if (isZh) "降雨 ${probability.toInt()}%" else "rain ${probability.toInt()}%")
            if (!rainMm.isNaN()) add(String.format(Locale.US, "%.1f mm", rainMm))
            if (!gustKmh.isNaN() && gustKmh >= 35) add(if (isZh) "阵风 ${gustKmh.toInt()} km/h" else "gust ${gustKmh.toInt()} km/h")
        }.joinToString(" · ")

        val title = if (severity >= 2) {
            if (isZh) "⚠️ Hi Rider 强天气预警" else "⚠️ Hi Rider Weather Alert"
        } else {
            if (isZh) "🌧️ Hi Rider 天气提醒" else "🌧️ Hi Rider Weather Notice"
        }
        val body = if (isZh) "$place · 下一小时 $timeText · $details" else "$place · next hour $timeText · $details"

        val notification = android.app.Notification.Builder(applicationContext, channelId)
            .setSmallIcon(R.drawable.ic_hirider)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(android.app.Notification.BigTextStyle().bigText(body))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        manager.notify(area.name.hashCode(), notification)
    }

    private fun formatTime12(hour24: Int, isZh: Boolean): String {
        val h = hour24.coerceIn(0, 23)
        val h12 = when (val v = h % 12) { 0 -> 12; else -> v }
        if (!isZh) return String.format(Locale.US, "%d:00 %s", h12, if (h < 12) "AM" else "PM")
        val period = when (h) {
            in 0..5 -> "凌晨"
            in 6..11 -> "上午"
            12 -> "中午"
            in 13..17 -> "下午"
            else -> "晚上"
        }
        return String.format(Locale.US, "%s %d:00", period, h12)
    }

    private fun getJson(urlText: String): JSONObject {
        val conn = (URL(urlText).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 9000
            readTimeout = 12000
            setRequestProperty("User-Agent", "HiRider/0.8 Android")
            setRequestProperty("Accept", "application/json")
        }
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return JSONObject(text)
        } finally {
            conn.disconnect()
        }
    }

    private fun List<Double>.averageOrNaN(): Double = if (isEmpty()) Double.NaN else average()
}
