import SwiftUI

struct ContentView: View {
    @State private var selectedCountry = "Singapore"

    private let countries = ["Singapore", "Malaysia"]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    VStack(spacing: 8) {
                        Image(systemName: "cloud.rain.fill")
                            .font(.system(size: 56))
                        Text("Hi Rider")
                            .font(.largeTitle.bold())
                        Text("iOS Prototype v0.1")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.top, 28)

                    VStack(alignment: .leading, spacing: 12) {
                        Text("Country / 国家")
                            .font(.headline)

                        Picker("Country", selection: $selectedCountry) {
                            ForEach(countries, id: \.self) { country in
                                Text(country).tag(country)
                            }
                        }
                        .pickerStyle(.segmented)
                    }
                    .padding()
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18))

                    VStack(alignment: .leading, spacing: 14) {
                        Label("Weather / 天气", systemImage: "cloud.sun.fill")
                            .font(.title3.bold())

                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(selectedCountry == "Singapore" ? "Singapore East" : "Johor")
                                    .font(.headline)
                                Text("Demo weather card")
                                    .foregroundStyle(.secondary)
                            }

                            Spacer()

                            VStack(alignment: .trailing, spacing: 4) {
                                Text("29°C")
                                    .font(.title2.bold())
                                Text("Rain 45%")
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    .padding()
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18))

                    VStack(alignment: .leading, spacing: 10) {
                        Text("First test goal")
                            .font(.headline)
                        Label("GitHub macOS runner can generate the Xcode project", systemImage: "hammer.fill")
                        Label("iOS Simulator build completes without signing", systemImage: "iphone")
                        Label("Android files remain untouched", systemImage: "checkmark.shield.fill")
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18))

                    Text("Next: real weather data → Firebase login → notifications")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.vertical)
                }
                .padding()
            }
            .navigationTitle("Hi Rider")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    ContentView()
}
