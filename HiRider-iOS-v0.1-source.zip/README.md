# Hi Rider iOS Prototype v0.1

This is the first cloud-build test for Hi Rider iOS.

Goal:
- Generate an Xcode project using XcodeGen
- Build for iOS Simulator on GitHub Actions
- No Apple signing or developer account required for this build test
- Does not modify the Android app

Files:
- project.yml
- HiRiderIOS/HiRiderIOSApp.swift
- HiRiderIOS/ContentView.swift
