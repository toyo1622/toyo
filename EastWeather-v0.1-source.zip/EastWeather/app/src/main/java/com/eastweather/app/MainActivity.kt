package com.eastweather.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.net.URL
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var current: TextView
    private lateinit var slots: TextView
    private lateinit var grab: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36,42,36,42); setBackgroundColor(Color.WHITE) }
        scroll.addView(root); setContentView(scroll)
        title("东部 Grab 天气", 28)
        text("Tampines + Pasir Ris｜官方短临 + 多模型综合", 15, Color.DKGRAY)
        status = text("正在更新天气…", 15, Color.GRAY)
        current = card("现在天气\n读取中…")
        slots = card("今晚 6PM–12AM\n读取中…")
        grab = card("🏍️ Grab 判断\n计算中…")
        Button(this).apply { text="重新更新"; textSize=17f; setOnClickListener { load() }; root.addView(this, LinearLayout.LayoutParams(-1,150).apply{topMargin=20}) }
        text("说明：NEA/MSS 短临资料优先；ECMWF、GFS、ICON 等模型用于交叉判断。综合风险不是 NEA 官方降雨概率。", 13, Color.GRAY)
        load()
    }
    private fun title(s:String, size:Int)=text(s,size,Color.BLACK)
    private fun text(s:String,size:Int,color:Int):TextView { val v=TextView(this); v.text=s; v.textSize=size.toFloat(); v.setTextColor(color); v.setPadding(0,10,0,10); root.addView(v); return v }
    private fun card(s:String):TextView { val v=text(s,18,Color.BLACK); v.setPadding(28,28,28,28); v.setBackgroundColor(Color.rgb(245,247,250)); root.addView(v, LinearLayout.LayoutParams(-1,-2).apply{topMargin=18}); return v }

    private fun load() { status.text="正在比较天气资料…"; thread {
        try {
            val lat=1.3547; val lon=103.9430
            val vars="temperature_2m,precipitation_probability,precipitation,weather_code,wind_speed_10m,wind_gusts_10m"
            val models=listOf("ecmwf_ifs025","ncep_gfs_global","icon_global")
            val results=models.map { m -> JSONObject(URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&hourly=$vars&models=$m&timezone=Asia%2FSingapore&forecast_days=2").readText()) }
            val h=results.first().getJSONObject("hourly"); val times=h.getJSONArray("time")
            val now=java.time.ZonedDateTime.now(java.time.ZoneId.of("Asia/Singapore")); val today=now.toLocalDate().toString()
            fun idx(hour:Int):Int { for(i in 0 until times.length()) if(times.getString(i).startsWith(today) && times.getString(i).endsWith(String.format("T%02d:00",hour))) return i; return 0 }
            fun avgProb(hour:Int):Int { val i=idx(hour); return results.map { it.getJSONObject("hourly").getJSONArray("precipitation_probability").optInt(i,0) }.average().toInt() }
            val iNow=(0 until times.length()).minByOrNull { kotlin.math.abs(java.time.Duration.between(now.toLocalDateTime(), java.time.LocalDateTime.parse(times.getString(it))).toMinutes()) } ?: 0
            val temp=h.getJSONArray("temperature_2m").optDouble(iNow); val wind=h.getJSONArray("wind_speed_10m").optDouble(iNow); val gust=h.getJSONArray("wind_gusts_10m").optDouble(iNow)
            fun block(a:Int,b:Int):Int=(a until b).map{avgProb(it)}.average().toInt()
            val p1=block(18,20); val p2=block(20,22); val p3=block(22,24)
            val max=maxOf(p1,p2,p3); val advice=when { max>=70 -> "🔴 不建议贸然开工"; max>=45 -> "🟡 需要观察雷达后再决定"; else -> "🟢 天气风险相对较低" }
            runOnUiThread {
                status.text="已更新｜综合 ECMWF + GFS + ICON（第一版）"
                current.text="现在｜Tampines / Pasir Ris\n🌡️ ${"%.1f".format(temp)}°C\n💨 风速 ${"%.1f".format(wind)} km/h｜阵风 ${"%.1f".format(gust)} km/h"
                slots.text="今晚综合降雨风险\n6–8 PM：$p1%\n8–10 PM：$p2%\n10 PM–12 AM：$p3%"
                grab.text="🏍️ Grab 判断\n$advice\n\n第一版先以多模型为基础；下一版接入 NEA/MSS 2小时地区预报与本地实况，提高临近开工时的判断。"
            }
        } catch(e:Exception) { runOnUiThread { status.text="更新失败：${e.message}" } }
    }}
}
