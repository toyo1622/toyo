package com.eastweather.app

import android.app.Activity
import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.FirebaseException
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.time.Duration
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sqrt

class MainActivity : Activity() {

    data class AreaDef(val name: String, val zh: String, val lat: Double, val lon: Double)
    data class Station(val id: String, val name: String, val lat: Double, val lon: Double)
    data class ReadingSet(
        val timestamp: String,
        val stations: List<Station>,
        val values: Map<String, Double>,
        val unit: String
    )
    data class ModelPoint(
        val time: ZonedDateTime,
        val probability: Double,
        val rainMm: Double,
        val tempC: Double,
        val windKmh: Double,
        val gustKmh: Double
    )
    data class ModelSeries(val model: String, val points: List<ModelPoint>)
    data class BlockResult(
        val time: ZonedDateTime,
        val severity: Int,
        val probability: Double,
        val rainMm: Double,
        val tempC: Double,
        val windKmh: Double,
        val gustKmh: Double,
        val confidence: String,
        val modelCount: Int
    )
    data class AreaResult(
        val area: AreaDef,
        val forecastRaw: String,
        val tempC: Double,
        val rainMm: Double,
        val windKmh: Double,
        val rainStation: String,
        val blocks: List<BlockResult>,
        val adviceLevel: Int
    )

    private val prefs by lazy { getSharedPreferences("hi_rider", MODE_PRIVATE) }
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val analytics by lazy { FirebaseAnalytics.getInstance(this) }

    private var isDark = false
    private var isZh = false
    private var bgColor = Color.rgb(244, 247, 250)
    private var cardColor = Color.WHITE
    private var textColor = Color.rgb(25, 38, 50)
    private var subTextColor = Color.rgb(89, 103, 117)
    private var mutedColor = Color.rgb(230, 235, 240)
    private var accentColor = Color.rgb(23, 91, 138)

    private lateinit var root: LinearLayout
    private lateinit var regionContainer: LinearLayout
    private lateinit var selectedText: TextView
    private lateinit var refreshButton: Button
    private lateinit var statusText: TextView

    private var verificationId: String? = null
    private var resendToken: PhoneAuthProvider.ForceResendingToken? = null
    private var loginPhone: String = ""

    // NEA/MSS two-hour forecast areas and label coordinates.
    private val areas = listOf(
        AreaDef("Ang Mo Kio", "宏茂桥", 1.375, 103.839),
        AreaDef("Bedok", "勿洛", 1.321, 103.924),
        AreaDef("Bishan", "碧山", 1.350772, 103.839),
        AreaDef("Boon Lay", "文礼", 1.304, 103.701),
        AreaDef("Bukit Batok", "武吉巴督", 1.353, 103.754),
        AreaDef("Bukit Merah", "红山", 1.277, 103.819),
        AreaDef("Bukit Panjang", "武吉班让", 1.362, 103.77195),
        AreaDef("Bukit Timah", "武吉知马", 1.325, 103.791),
        AreaDef("Central Water Catchment", "中央集水区", 1.38, 103.805),
        AreaDef("Changi", "樟宜", 1.357, 103.987),
        AreaDef("Choa Chu Kang", "蔡厝港", 1.377, 103.745),
        AreaDef("City", "市中心", 1.292, 103.844),
        AreaDef("Clementi", "金文泰", 1.315, 103.76),
        AreaDef("Geylang", "芽笼", 1.318, 103.884),
        AreaDef("Hougang", "后港", 1.361218, 103.886),
        AreaDef("Jalan Bahar", "惹兰巴哈", 1.347, 103.67),
        AreaDef("Jurong East", "裕廊东", 1.326, 103.737),
        AreaDef("Jurong Island", "裕廊岛", 1.266, 103.699),
        AreaDef("Jurong West", "裕廊西", 1.34039, 103.705),
        AreaDef("Kallang", "加冷", 1.312, 103.862),
        AreaDef("Lim Chu Kang", "林厝港", 1.423, 103.717332),
        AreaDef("Mandai", "万礼", 1.419, 103.812),
        AreaDef("Marine Parade", "马林百列", 1.297, 103.891),
        AreaDef("Novena", "诺维娜", 1.327, 103.826),
        AreaDef("Pasir Ris", "巴西立", 1.37, 103.948),
        AreaDef("Paya Lebar", "巴耶利峇", 1.358, 103.914),
        AreaDef("Pioneer", "先驱", 1.315, 103.675),
        AreaDef("Pulau Tekong", "德光岛", 1.403, 104.053),
        AreaDef("Pulau Ubin", "乌敏岛", 1.404, 103.96),
        AreaDef("Punggol", "榜鹅", 1.401, 103.904),
        AreaDef("Queenstown", "女皇镇", 1.291, 103.78576),
        AreaDef("Seletar", "实里达", 1.404, 103.869),
        AreaDef("Sembawang", "三巴旺", 1.445, 103.818495),
        AreaDef("Sengkang", "盛港", 1.384, 103.891443),
        AreaDef("Sentosa", "圣淘沙", 1.243, 103.832),
        AreaDef("Serangoon", "实龙岗", 1.357, 103.865),
        AreaDef("Southern Islands", "南部岛屿", 1.208, 103.842),
        AreaDef("Sungei Kadut", "双溪加株", 1.413, 103.756),
        AreaDef("Tampines", "淡滨尼", 1.345, 103.944),
        AreaDef("Tanglin", "东陵", 1.308, 103.813),
        AreaDef("Tengah", "登加", 1.374, 103.715),
        AreaDef("Toa Payoh", "大巴窑", 1.334304, 103.856327),
        AreaDef("Tuas", "大士", 1.294947, 103.635),
        AreaDef("Western Islands", "西部岛屿", 1.205926, 103.746),
        AreaDef("Western Water Catchment", "西部集水区", 1.405, 103.689),
        AreaDef("Woodlands", "兀兰", 1.432, 103.786528),
        AreaDef("Yishun", "义顺", 1.418, 103.839)
    )

    private val defaultNames = listOf("Tampines", "Pasir Ris", "Bedok", "Paya Lebar", "Changi", "City")

    override fun onCreate(savedInstanceState: Bundle?) {
        val p = getSharedPreferences("hi_rider", MODE_PRIVATE)
        isDark = p.getString("theme", "light") == "dark"
        isZh = p.getString("language", "en") == "zh"
        setTheme(if (isDark) R.style.AppThemeDark else R.style.AppThemeLight)
        super.onCreate(savedInstanceState)
        applyPalette()

        // Require Firebase Phone OTP for new users. Existing signed-in users can enter directly.
        if (auth.currentUser != null) {
            showMain()
        } else {
            showLogin()
        }
    }

    private fun applyPalette() {
        if (isDark) {
            bgColor = Color.rgb(17, 24, 32)
            cardColor = Color.rgb(29, 39, 49)
            textColor = Color.rgb(240, 244, 248)
            subTextColor = Color.rgb(176, 189, 201)
            mutedColor = Color.rgb(48, 61, 73)
            accentColor = Color.rgb(91, 174, 230)
        } else {
            bgColor = Color.rgb(244, 247, 250)
            cardColor = Color.WHITE
            textColor = Color.rgb(25, 38, 50)
            subTextColor = Color.rgb(89, 103, 117)
            mutedColor = Color.rgb(230, 235, 240)
            accentColor = Color.rgb(23, 91, 138)
        }
        window.statusBarColor = bgColor
        window.navigationBarColor = bgColor
    }

    private fun t(en: String, zh: String): String = if (isZh) zh else en

    // ---------------------- Firebase Phone OTP ----------------------

    private fun showLogin() {
        auth.setLanguageCode(if (isZh) "zh" else "en")

        val scroll = ScrollView(this).apply { setBackgroundColor(bgColor) }
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(42), dp(24), dp(32))
        }
        scroll.addView(wrap, LinearLayout.LayoutParams(-1, -2))

        val title = TextView(this).apply {
            text = "Hi Rider v0.6"
            textSize = 30f
            setTextColor(textColor)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        wrap.addView(title)

        val subtitle = TextView(this).apply {
            text = t(
                "Sign in with your phone number to continue.",
                "使用手机号码登录后才可以继续。"
            )
            textSize = 16f
            setTextColor(subTextColor)
            setPadding(0, dp(8), 0, dp(22))
        }
        wrap.addView(subtitle)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(cardColor, 18f)
        }
        wrap.addView(box, LinearLayout.LayoutParams(-1, -2))

        val phoneLabel = label(t("Phone number", "手机号码"))
        box.addView(phoneLabel)

        val phoneInput = EditText(this).apply {
            hint = "+65 91234567 / +60 ..."
            setTextColor(textColor)
            setHintTextColor(subTextColor)
            inputType = InputType.TYPE_CLASS_PHONE
            textSize = 18f
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            backgroundTintList = ColorStateList.valueOf(accentColor)
        }
        box.addView(phoneInput, LinearLayout.LayoutParams(-1, -2))

        val sendButton = Button(this).apply {
            text = t("Send OTP", "发送验证码")
            styleButton(this)
        }
        box.addView(sendButton, marginTop(12))

        val otpInput = EditText(this).apply {
            hint = t("6-digit OTP", "6位验证码")
            setTextColor(textColor)
            setHintTextColor(subTextColor)
            inputType = InputType.TYPE_CLASS_NUMBER
            textSize = 20f
            setSingleLine(true)
            visibility = View.GONE
            setPadding(dp(12), dp(10), dp(12), dp(10))
            backgroundTintList = ColorStateList.valueOf(accentColor)
        }
        box.addView(otpInput, marginTop(14))

        val verifyButton = Button(this).apply {
            text = t("Verify & enter", "验证并进入")
            styleButton(this)
            visibility = View.GONE
        }
        box.addView(verifyButton, marginTop(10))

        val resendButton = Button(this).apply {
            text = t("Resend OTP", "重新发送验证码")
            setAllCaps(false)
            setTextColor(accentColor)
            backgroundTintList = ColorStateList.valueOf(if (isDark) Color.rgb(40, 52, 64) else Color.rgb(236, 244, 250))
            visibility = View.GONE
        }
        box.addView(resendButton, marginTop(8))

        val loginStatus = TextView(this).apply {
            textSize = 14f
            setTextColor(subTextColor)
            setPadding(0, dp(14), 0, 0)
        }
        box.addView(loginStatus)

        val privacy = TextView(this).apply {
            text = t(
                "Your phone number is used for Firebase sign-in/account records. Hi Rider Analytics records app usage, not your phone number.",
                "手机号码只用于 Firebase 登录及账户记录。Hi Rider 的使用统计不会把你的手机号码作为分析资料发送。"
            )
            textSize = 13f
            setTextColor(subTextColor)
            setPadding(0, dp(18), 0, 0)
        }
        wrap.addView(privacy)

        val language = Button(this).apply {
            text = if (isZh) "English" else "中文"
            setAllCaps(false)
            setTextColor(accentColor)
            backgroundTintList = ColorStateList.valueOf(if (isDark) Color.rgb(40, 52, 64) else Color.rgb(236, 244, 250))
            setOnClickListener {
                isZh = !isZh
                prefs.edit().putString("language", if (isZh) "zh" else "en").apply()
                recreate()
            }
        }
        wrap.addView(language, marginTop(18))

        fun requestOtp(force: Boolean) {
            val normalized = normalizePhone(phoneInput.text.toString())
            if (!normalized.matches(Regex("^\\+[1-9]\\d{7,14}$"))) {
                loginStatus.text = t(
                    "Enter a valid international phone number, for example +65 91234567.",
                    "请输入正确的国际手机号码，例如 +65 91234567。"
                )
                return
            }
            loginPhone = normalized
            sendButton.isEnabled = false
            resendButton.isEnabled = false
            loginStatus.text = t("Sending OTP…", "正在发送验证码…")

            val builder = PhoneAuthOptions.newBuilder(auth)
                .setPhoneNumber(normalized)
                .setTimeout(60L, TimeUnit.SECONDS)
                .setActivity(this)
                .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                    override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                        loginStatus.text = t("Number verified. Signing in…", "号码已验证，正在登录…")
                        signInWithCredential(credential, loginStatus)
                    }

                    override fun onVerificationFailed(e: FirebaseException) {
                        sendButton.isEnabled = true
                        resendButton.isEnabled = true
                        loginStatus.text = t("OTP failed: ", "验证码发送失败：") + friendlyAuthError(e)
                    }

                    override fun onCodeSent(
                        id: String,
                        token: PhoneAuthProvider.ForceResendingToken
                    ) {
                        verificationId = id
                        resendToken = token
                        otpInput.visibility = View.VISIBLE
                        verifyButton.visibility = View.VISIBLE
                        resendButton.visibility = View.VISIBLE
                        sendButton.isEnabled = true
                        resendButton.isEnabled = true
                        loginStatus.text = t(
                            "OTP sent. Enter the 6-digit code.",
                            "验证码已发送，请输入6位验证码。"
                        )
                    }
                })

            if (force && resendToken != null) builder.setForceResendingToken(resendToken!!)
            PhoneAuthProvider.verifyPhoneNumber(builder.build())
        }

        sendButton.setOnClickListener { requestOtp(false) }
        resendButton.setOnClickListener { requestOtp(true) }
        verifyButton.setOnClickListener {
            val id = verificationId
            val code = otpInput.text.toString().trim()
            if (id.isNullOrBlank() || code.length < 6) {
                loginStatus.text = t("Enter the 6-digit OTP first.", "请先输入6位验证码。")
            } else {
                verifyButton.isEnabled = false
                loginStatus.text = t("Checking OTP…", "正在验证验证码…")
                val credential = PhoneAuthProvider.getCredential(id, code)
                signInWithCredential(credential, loginStatus) { verifyButton.isEnabled = true }
            }
        }

        setContentView(scroll)
    }

    private fun signInWithCredential(
        credential: PhoneAuthCredential,
        status: TextView,
        onDone: (() -> Unit)? = null
    ) {
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                onDone?.invoke()
                if (task.isSuccessful) {
                    val b = Bundle().apply {
                        putString(FirebaseAnalytics.Param.METHOD, "phone")
                    }
                    analytics.logEvent(FirebaseAnalytics.Event.LOGIN, b)
                    Toast.makeText(this, t("Login successful", "登录成功"), Toast.LENGTH_SHORT).show()
                    showMain()
                } else {
                    status.text = t("Verification failed: ", "验证失败：") +
                        friendlyAuthError(task.exception ?: Exception("Unknown error"))
                }
            }
    }

    private fun friendlyAuthError(e: Throwable): String {
        val raw = e.message ?: e.javaClass.simpleName
        return raw.take(180)
    }

    private fun normalizePhone(raw: String): String {
        val clean = raw.trim().replace(Regex("[\\s()\\-]"), "")
        if (clean.startsWith("+")) return clean
        return if (clean.length == 8 && clean.all { it.isDigit() }) "+65$clean" else clean
    }

    // ---------------------- Main weather screen ----------------------

    private fun showMain() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bgColor)
            isFillViewport = true
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(32))
        }
        scroll.addView(root, LinearLayout.LayoutParams(-1, -2))
        setContentView(scroll)

        buildHeader()
        buildControls()

        statusText = TextView(this).apply {
            text = t("Preparing", "准备中")
            textSize = 14f
            setTextColor(subTextColor)
            setPadding(dp(4), dp(12), dp(4), dp(8))
        }
        root.addView(statusText)

        regionContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        root.addView(regionContainer, LinearLayout.LayoutParams(-1, -2))

        val note = TextView(this).apply {
            text = t(
                "Select up to 6 areas. Tap for hourly details from morning through midnight. Past hours are hidden. NEA/MSS provides a 2-hour area forecast; hourly values come from weather models.",
                "最多选择6个地区；点击查看从早上到午夜的逐小时预报，已过去的时段自动隐藏。NEA/MSS 提供未来两小时的地区预报；逐小时数值来自天气模型。"
            )
            textSize = 12.5f
            setTextColor(subTextColor)
            setPadding(dp(4), dp(18), dp(4), dp(6))
        }
        root.addView(note)

        load()
    }

    private fun buildHeader() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val title = TextView(this).apply {
            text = "Hi Rider"
            textSize = 28f
            setTextColor(textColor)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val subtitle = TextView(this).apply {
            text = t("Weather companion for riders", "骑士天气助手")
            textSize = 14f
            setTextColor(subTextColor)
        }
        titleWrap.addView(title)
        titleWrap.addView(subtitle)
        row.addView(titleWrap, LinearLayout.LayoutParams(0, -2, 1f))

        val settings = Button(this).apply {
            text = "⚙"
            textSize = 20f
            contentDescription = t("Settings", "设置")
            setAllCaps(false)
            setTextColor(textColor)
            backgroundTintList = ColorStateList.valueOf(if (isDark) Color.rgb(40, 52, 64) else Color.rgb(232, 238, 244))
            setOnClickListener { showSettings() }
        }
        row.addView(settings, LinearLayout.LayoutParams(dp(58), dp(52)))
        root.addView(row)
    }

    private fun buildControls() {
        selectedText = TextView(this).apply {
            textSize = 14f
            setTextColor(subTextColor)
            setPadding(0, dp(18), 0, dp(8))
        }
        root.addView(selectedText)
        updateSelectedLabel()

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val chooseButton = Button(this).apply {
            text = t("Choose areas", "选择地区")
            styleButton(this)
            setOnClickListener { showAreaPicker() }
        }
        refreshButton = Button(this).apply {
            text = t("Refresh", "刷新")
            styleButton(this)
            setOnClickListener { load() }
        }
        controls.addView(chooseButton, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        controls.addView(refreshButton, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        root.addView(controls)
    }

    private fun selectedAreas(): List<AreaDef> {
        val saved = prefs.getString("selected_areas", null)
        val names = if (saved.isNullOrBlank()) defaultNames else saved.split("|").filter { it.isNotBlank() }
        val selected = names.mapNotNull { n -> areas.firstOrNull { it.name == n } }
        return if (selected.isEmpty()) areas.filter { it.name in defaultNames } else selected.take(6)
    }

    private fun selectedNames(): List<String> = selectedAreas().map { if (isZh) it.zh else it.name }

    private fun updateSelectedLabel() {
        selectedText.text = t("Selected: ", "已选：") + selectedNames().joinToString(", ")
    }

    private fun showAreaPicker() {
        val current = selectedAreas().map { it.name }.toMutableSet()
        val labels = areas.map { if (isZh) it.zh else it.name }.toTypedArray()
        val checked = BooleanArray(areas.size) { areas[it].name in current }

        val dialog = AlertDialog.Builder(this)
            .setTitle(t("Choose areas (max 6)", "选择地区（最多6个）"))
            .setMultiChoiceItems(labels, checked) { dlg, which, isChecked ->
                checked[which] = isChecked
                if (isChecked && checked.count { it } > 6) {
                    checked[which] = false
                    (dlg as AlertDialog).listView.setItemChecked(which, false)
                    Toast.makeText(this, t("You can select up to 6 areas", "最多只能选择6个地区"), Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(t("Cancel", "取消"), null)
            .setPositiveButton(t("Save", "保存"), null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val picked = areas.filterIndexed { index, _ -> dialog.listView.isItemChecked(index) }
                if (picked.isEmpty()) {
                    Toast.makeText(this, t("Select at least 1 area", "至少选择1个地区"), Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                prefs.edit().putString("selected_areas", picked.take(6).joinToString("|") { it.name }).apply()
                updateSelectedLabel()
                dialog.dismiss()
                load()
            }
        }
        dialog.show()
    }

    private fun showSettings() {
        val items = arrayOf(
            t("Areas (${selectedAreas().size})", "地区（${selectedAreas().size}）"),
            t("Forecast start time", "预报开始时间"),
            t("Language: English", "语言：中文"),
            t("Theme: ", "主题：") + if (isDark) t("Dark", "深色") else t("Light", "浅色"),
            t("About Hi Rider", "关于 Hi Rider")
        )
        AlertDialog.Builder(this)
            .setTitle(t("Settings", "设置"))
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showAreaPicker()
                    1 -> showForecastTimeDialog()
                    2 -> showLanguageDialog()
                    3 -> showThemeDialog()
                    4 -> showAbout()
                }
            }
            .setNegativeButton(t("Close", "关闭"), null)
            .show()
    }

    private fun showForecastTimeDialog() {
        val hours = (5..20).toList().toIntArray()
        val labels = hours.map { String.format(Locale.US, "%02d:00", it) }.toTypedArray()
        val current = prefs.getInt("forecast_start_hour", 6)
        AlertDialog.Builder(this)
            .setTitle(t("Forecast start time", "预报开始时间"))
            .setSingleChoiceItems(labels, hours.indexOf(current)) { dialog, index ->
                prefs.edit().putInt("forecast_start_hour", hours[index]).apply()
                dialog.dismiss()
                load()
            }
            .show()
    }

    private fun showLanguageDialog() {
        val labels = arrayOf("English", "中文")
        AlertDialog.Builder(this)
            .setTitle(t("Choose Language", "选择语言"))
            .setSingleChoiceItems(labels, if (isZh) 1 else 0) { dialog, which ->
                prefs.edit().putString("language", if (which == 1) "zh" else "en").apply()
                dialog.dismiss()
                recreate()
            }
            .show()
    }

    private fun showThemeDialog() {
        val labels = arrayOf(t("Light", "浅色"), t("Dark", "深色"))
        AlertDialog.Builder(this)
            .setTitle(t("Choose Theme", "选择主题"))
            .setSingleChoiceItems(labels, if (isDark) 1 else 0) { dialog, which ->
                prefs.edit().putString("theme", if (which == 1) "dark" else "light").apply()
                dialog.dismiss()
                recreate()
            }
            .show()
    }

    private fun showAbout() {
        AlertDialog.Builder(this)
            .setTitle(t("About Hi Rider", "关于 Hi Rider"))
            .setMessage(
                t(
                    "Hi Rider v0.6\n\nHi Rider is a practical companion for riders. This temporary version enters directly without phone OTP. Firebase Analytics remains enabled for usage statistics.\n\nWeather: NEA/MSS + ECMWF/GFS/ICON.",
                    "Hi Rider v0.6\n\nHi Rider 是给骑士使用的实用助手。这个临时版本会直接进入，不需要手机 OTP；Firebase Analytics 使用统计继续保留。\n\n天气资料：NEA/MSS + ECMWF/GFS/ICON。"
                )
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun confirmSignOut() {
        AlertDialog.Builder(this)
            .setTitle(t("Sign out", "退出登录"))
            .setMessage(t("You will need OTP to enter again.", "下次进入时需要重新使用验证码登录。"))
            .setNegativeButton(t("Cancel", "取消"), null)
            .setPositiveButton(t("Sign out", "退出")) { _, _ ->
                auth.signOut()
                showLogin()
            }
            .show()
    }

    private fun load() {
        refreshButton.isEnabled = false
        statusText.text = t(
            "Loading official and multi-model data for ${selectedAreas().size} areas…",
            "正在载入 ${selectedAreas().size} 个地区的官方及多模型天气资料…"
        )
        regionContainer.removeAllViews()
        val loading = card(t("Rider Weather Overview\n\nCalculating…", "骑士天气总览\n\n计算中…"))
        regionContainer.addView(loading)

        analytics.logEvent("weather_refresh", Bundle().apply {
            putLong("area_count", selectedAreas().size.toLong())
        })

        Thread {
            try {
                val selected = selectedAreas()
                val nea = runCatching { fetchTwoHourForecast() }.getOrElse { Triple(emptyMap(), "", "") }
                val rain = runCatching {
                    fetchReading("https://api-open.data.gov.sg/v2/real-time/api/rainfall", "mm")
                }.getOrElse { ReadingSet("", emptyList(), emptyMap(), "mm") }
                val temp = runCatching {
                    fetchReading("https://api-open.data.gov.sg/v2/real-time/api/air-temperature", "°C")
                }.getOrElse { ReadingSet("", emptyList(), emptyMap(), "°C") }
                val wind = runCatching {
                    fetchReading("https://api-open.data.gov.sg/v2/real-time/api/wind-speed", "km/h")
                }.getOrElse { ReadingSet("", emptyList(), emptyMap(), "km/h") }

                val targets = targetTimes()
                val results = selected.map { area ->
                    val ecmwf = runCatching { fetchModel(area, "ecmwf_ifs025") }.getOrNull()
                    val gfs = runCatching { fetchModel(area, "ncep_gfs_global") }.getOrNull()
                    val icon = runCatching { fetchModel(area, "icon_global") }.getOrNull()
                    buildAreaResult(
                        area = area,
                        forecast = nea.first[area.name].orEmpty(),
                        rain = rain,
                        temp = temp,
                        wind = wind,
                        series = listOfNotNull(ecmwf, gfs, icon),
                        targets = targets
                    )
                }

                runOnUiThread {
                    renderResults(results, nea.second, rain.timestamp)
                    refreshButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    regionContainer.removeAllViews()
                    regionContainer.addView(
                        card(
                            t(
                                "Unable to complete the assessment\n\nNetwork or weather data unavailable.\nPlease tap Refresh and try again later.\n\n${e.message ?: ""}",
                                "无法完成天气评估\n\n网络或天气资料暂时不可用。\n请稍后按刷新再试。\n\n${e.message ?: ""}"
                            )
                        )
                    )
                    statusText.text = t("Update failed", "更新失败")
                    refreshButton.isEnabled = true
                }
            }
        }.start()
    }

    private fun renderResults(results: List<AreaResult>, neaUpdated: String, rainUpdated: String) {
        regionContainer.removeAllViews()
        if (results.isEmpty()) {
            regionContainer.addView(card(t("No weather data available", "暂时没有天气资料")))
            return
        }

        val red = results.filter { it.adviceLevel >= 2 }
        val yellow = results.filter { it.adviceLevel == 1 }
        val green = results.filter { it.adviceLevel == 0 }

        val summary = buildString {
            append(t("Rider Weather Overview", "骑士天气总览"))
            append("\n\n")
            if (red.isNotEmpty()) {
                append("🔴 ").append(t("Not recommended: ", "不建议："))
                append(red.joinToString(", ") { areaLabel(it.area) }).append("\n")
            }
            if (yellow.isNotEmpty()) {
                append("🟡 ").append(t("Monitor: ", "先观察："))
                append(yellow.joinToString(", ") { areaLabel(it.area) }).append("\n")
            }
            if (green.isNotEmpty()) {
                append("🟢 ").append(t("Good to go: ", "可以出发："))
                append(green.joinToString(", ") { areaLabel(it.area) }).append("\n")
            }
            append("\n")
            append(t(
                "Based on NEA/MSS, the nearest rain station and remaining multi-model guidance.",
                "依据 NEA/MSS、附近雨量站，以及其余时段的多模型参考。"
            ))
        }
        regionContainer.addView(card(summary.toString()))

        results.forEach { addRegionCard(it) }

        val updated = listOf(neaUpdated, rainUpdated).firstOrNull { it.isNotBlank() }
        statusText.text = if (updated.isNullOrBlank()) {
            t("Updated ${ZonedDateTime.now(zone).format(DateTimeFormatter.ofPattern("HH:mm"))}",
                "已更新 ${ZonedDateTime.now(zone).format(DateTimeFormatter.ofPattern("HH:mm"))}")
        } else {
            t("Updated ${formatApiTime(updated)}", "已更新 ${formatApiTime(updated)}")
        }
    }

    private fun addRegionCard(r: AreaResult) {
        val first = r.blocks.firstOrNull()
        val preview = buildString {
            append(areaLabel(r.area)).append("  ·  ").append(advice(r.adviceLevel))
            append("\nNEA/MSS: ").append(if (r.forecastRaw.isBlank()) "—" else forecastDisplay(r.forecastRaw))
            if (first != null) append("  ·  ").append(blockLabel(first.time))
            append("\n").append(t("Tap for hourly details", "点击查看逐小时详情"))
        }
        val compact = card(preview)
        compact.setOnClickListener { showRegionDetails(r) }
        regionContainer.addView(compact, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
    }

    private fun showRegionDetails(r: AreaResult) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(cardColor, 16f)
        }

        val headingRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = areaLabel(r.area)
            textSize = 21f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(textColor)
        }
        headingRow.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val badge = TextView(this).apply {
            text = when (r.adviceLevel) {
                2 -> "🔴 " + t("Not recommended", "不建议")
                1 -> "🟡 " + t("Monitor first", "先观察")
                else -> "🟢 " + t("Good to go", "可以出发")
            }
            textSize = 13f
            setTextColor(textColor)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = rounded(if (isDark) Color.rgb(45, 58, 70) else Color.rgb(238, 243, 247), 18f)
        }
        headingRow.addView(badge)
        box.addView(headingRow)

        val official = TextView(this).apply {
            val forecast = if (r.forecastRaw.isBlank()) t("Official forecast unavailable", "官方预报暂时不可用") else forecastDisplay(r.forecastRaw)
            text = "NEA/MSS  ·  $forecast"
            textSize = 15f
            setTextColor(textColor)
            setPadding(0, dp(10), 0, dp(5))
        }
        box.addView(official)

        val obs = TextView(this).apply {
            text = buildString {
                append(t("Nearby station", "附近观测站")).append(": ").append(r.rainStation.ifBlank { "—" })
                append("\n")
                append(t("5-min rain", "5分钟雨量")).append(": ").append(num(r.rainMm)).append(" mm")
                if (!r.tempC.isNaN()) append("  ·  ").append(num(r.tempC)).append("°C")
                if (!r.windKmh.isNaN()) append("  ·  ").append(t("Wind ", "风速 ")).append(num(r.windKmh)).append(" km/h")
            }
            textSize = 13.5f
            setTextColor(subTextColor)
            setPadding(0, 0, 0, dp(9))
        }
        box.addView(obs)

        if (r.blocks.isEmpty()) {
            val ended = TextView(this).apply {
                text = t("Today's selected forecast window has ended.", "今天所选的预报时段已经结束。")
                textSize = 14f
                setTextColor(subTextColor)
            }
            box.addView(ended)
        } else {
            r.blocks.forEach { b ->
                val tv = TextView(this).apply {
                    val icon = when (b.severity) { 2 -> "🔴"; 1 -> "🟡"; else -> "🟢" }
                    text = buildString {
                        append(icon).append("  ").append(blockLabel(b.time)).append("   ")
                        append(advice(b.severity)).append("\n")
                        if (b.modelCount > 0) {
                            append(t("Rain ", "降雨 ")).append(num0(b.probability)).append("%")
                            append("  ·  ").append(num(b.rainMm)).append(" mm")
                            if (!b.tempC.isNaN()) append("  ·  ").append(num(b.tempC)).append("°C")
                            if (!b.gustKmh.isNaN()) append("  ·  ").append(t("Gust ", "阵风 ")).append(num0(b.gustKmh)).append(" km/h")
                            append("\n").append(t("Confidence ", "可信度 ")).append(confidenceLabel(b.confidence))
                            append("  ·  ").append(b.modelCount).append(" ").append(t("models", "模型"))
                        } else {
                            append(t("Multi-model data unavailable", "多模型资料暂时不可用"))
                        }
                    }
                    textSize = 13.5f
                    setTextColor(textColor)
                    setPadding(dp(10), dp(9), dp(10), dp(9))
                    background = rounded(if (isDark) Color.rgb(35, 47, 58) else Color.rgb(247, 249, 251), 10f)
                }
                box.addView(tv, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })
            }
        }

        val scroll = ScrollView(this).apply { addView(box) }
        AlertDialog.Builder(this)
            .setView(scroll)
            .setPositiveButton(t("Close", "关闭"), null)
            .show()
    }

    // ---------------------- Weather data ----------------------

    private val zone: ZoneId = ZoneId.of("Asia/Singapore")

    private fun fetchTwoHourForecast(): Triple<Map<String, String>, String, String> {
        val json = getJson("https://api-open.data.gov.sg/v2/real-time/api/two-hr-forecast")
        val data = json.optJSONObject("data") ?: json
        val items = data.optJSONArray("items") ?: JSONArray()
        if (items.length() == 0) return Triple(emptyMap(), "", "")
        val item = items.optJSONObject(0) ?: return Triple(emptyMap(), "", "")
        val forecasts = item.optJSONArray("forecasts") ?: JSONArray()
        val map = linkedMapOf<String, String>()
        for (i in 0 until forecasts.length()) {
            val o = forecasts.optJSONObject(i) ?: continue
            val area = o.optString("area")
            val forecast = o.optString("forecast")
            if (area.isNotBlank()) map[area] = forecast
        }
        val updated = item.optString("updated_timestamp", data.optString("updated_timestamp", ""))
        val valid = item.optJSONObject("valid_period")?.let {
            listOf(it.optString("start"), it.optString("end")).filter { s -> s.isNotBlank() }.joinToString(" – ")
        }.orEmpty()
        return Triple(map, updated, valid)
    }

    private fun fetchReading(url: String, unit: String): ReadingSet {
        val json = getJson(url)
        val data = json.optJSONObject("data") ?: json
        val stationsJson = data.optJSONArray("stations") ?: JSONArray()
        val stations = mutableListOf<Station>()
        for (i in 0 until stationsJson.length()) {
            val o = stationsJson.optJSONObject(i) ?: continue
            val loc = o.optJSONObject("location") ?: continue
            val lat = loc.optDouble("latitude", Double.NaN)
            val lon = loc.optDouble("longitude", Double.NaN)
            if (lat.isNaN() || lon.isNaN()) continue
            stations += Station(
                id = o.optString("id", o.optString("deviceId")),
                name = o.optString("name", o.optString("id")),
                lat = lat,
                lon = lon
            )
        }

        val readings = data.optJSONArray("readings") ?: JSONArray()
        val reading = if (readings.length() > 0) readings.optJSONObject(0) else null
        val valuesJson = reading?.optJSONArray("data") ?: JSONArray()
        val values = linkedMapOf<String, Double>()
        for (i in 0 until valuesJson.length()) {
            val o = valuesJson.optJSONObject(i) ?: continue
            val id = o.optString("stationId", o.optString("station_id"))
            val value = o.optDouble("value", Double.NaN)
            if (id.isNotBlank() && !value.isNaN()) values[id] = value
        }
        val timestamp = reading?.optString("timestamp").orEmpty()
        return ReadingSet(timestamp, stations, values, unit)
    }

    private fun fetchModel(area: AreaDef, model: String): ModelSeries {
        val url = buildString {
            append("https://api.open-meteo.com/v1/forecast?latitude=").append(area.lat)
            append("&longitude=").append(area.lon)
            append("&hourly=temperature_2m,precipitation_probability,precipitation,weather_code,wind_speed_10m,wind_gusts_10m")
            append("&models=").append(model)
            append("&timezone=Asia%2FSingapore&forecast_days=2")
        }
        val json = getJson(url)
        val hourly = json.optJSONObject("hourly") ?: return ModelSeries(model, emptyList())
        val times = hourly.optJSONArray("time") ?: JSONArray()
        val temp = hourly.optJSONArray("temperature_2m") ?: JSONArray()
        val probs = hourly.optJSONArray("precipitation_probability") ?: JSONArray()
        val rain = hourly.optJSONArray("precipitation") ?: JSONArray()
        val winds = hourly.optJSONArray("wind_speed_10m") ?: JSONArray()
        val gusts = hourly.optJSONArray("wind_gusts_10m") ?: JSONArray()
        val points = mutableListOf<ModelPoint>()
        for (i in 0 until times.length()) {
            val timeText = times.optString(i)
            val ldt = runCatching { LocalDateTime.parse(timeText) }.getOrNull() ?: continue
            points += ModelPoint(
                time = ldt.atZone(zone),
                probability = probs.optDouble(i, Double.NaN),
                rainMm = rain.optDouble(i, Double.NaN),
                tempC = temp.optDouble(i, Double.NaN),
                windKmh = winds.optDouble(i, Double.NaN),
                gustKmh = gusts.optDouble(i, Double.NaN)
            )
        }
        return ModelSeries(model, points)
    }

    private fun buildAreaResult(
        area: AreaDef,
        forecast: String,
        rain: ReadingSet,
        temp: ReadingSet,
        wind: ReadingSet,
        series: List<ModelSeries>,
        targets: List<ZonedDateTime>
    ): AreaResult {
        val rainNear = nearest(area, rain)
        val tempNear = nearest(area, temp)
        val windNear = nearest(area, wind)

        val rainMm = rainNear?.second ?: Double.NaN
        val tempC = tempNear?.second ?: Double.NaN
        val windKmh = windNear?.second ?: Double.NaN
        val stationName = rainNear?.first?.name.orEmpty()

        val nearSeverity = max(forecastSeverity(forecast), observationSeverity(rainMm, windKmh))
        val now = ZonedDateTime.now(zone)

        val blocks = targets.map { target ->
            val pts = series.mapNotNull { nearest(it, target) }
            val probs = pts.map { it.probability }.filterNot { it.isNaN() }
            val rains = pts.map { it.rainMm }.filterNot { it.isNaN() }
            val temps = pts.map { it.tempC }.filterNot { it.isNaN() }
            val winds = pts.map { it.windKmh }.filterNot { it.isNaN() }
            val gusts = pts.map { it.gustKmh }.filterNot { it.isNaN() }

            val pAvg = probs.averageOrNaN()
            val rainAvg = rains.averageOrNaN()
            val tempAvg = temps.averageOrNaN()
            val windAvg = winds.averageOrNaN()
            val gustMax = gusts.maxOrNull() ?: Double.NaN
            val spread = if (probs.size >= 2) (probs.maxOrNull()!! - probs.minOrNull()!!) else Double.NaN
            var sev = modelSeverity(pAvg, rainAvg, gustMax)
            if (Duration.between(now, target).toMinutes() in 0..150) sev = max(sev, nearSeverity)
            val confidence = when {
                pts.size >= 3 && (spread.isNaN() || spread <= 25.0) -> "High"
                pts.size >= 2 -> "Medium"
                else -> "Low"
            }
            BlockResult(target, sev, pAvg, rainAvg, tempAvg, windAvg, gustMax, confidence, pts.size)
        }

        val overall = max(nearSeverity, blocks.maxOfOrNull { it.severity } ?: 0)
        return AreaResult(area, forecast, tempC, rainMm, windKmh, stationName, blocks, overall)
    }

    private fun targetTimes(): List<ZonedDateTime> {
        val now = ZonedDateTime.now(zone)
        val d = now.toLocalDate()
        val start = prefs.getInt("forecast_start_hour", 6).coerceIn(5, 20)
        // Show every hour from the chosen morning/daytime start through midnight.
        val candidates = (start..24).map { d.atStartOfDay(zone).plusHours(it.toLong()) }
        return candidates.filter { !it.isBefore(now.minusMinutes(15)) }
    }

    private fun nearest(area: AreaDef, reading: ReadingSet): Pair<Station, Double>? {
        return reading.stations
            .filter { reading.values.containsKey(it.id) }
            .minByOrNull { distanceKm(area.lat, area.lon, it.lat, it.lon) }
            ?.let { it to (reading.values[it.id] ?: Double.NaN) }
    }

    private fun nearest(series: ModelSeries, target: ZonedDateTime): ModelPoint? {
        val usable = series.points.filter {
            abs(Duration.between(it.time, target).toMinutes()) <= 90
        }
        return usable.minByOrNull { abs(Duration.between(it.time, target).toMinutes()) }
    }

    private fun distanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val x = Math.toRadians(lon2 - lon1) * cos(Math.toRadians((lat1 + lat2) / 2.0))
        val y = Math.toRadians(lat2 - lat1)
        return sqrt(x.pow(2) + y.pow(2)) * 6371.0
    }

    private fun forecastSeverity(raw: String): Int {
        val s = raw.lowercase(Locale.ROOT)
        return when {
            s.contains("thundery") || s.contains("heavy rain") -> 2
            s.contains("moderate rain") || s.contains("showers") || s.contains("rain") -> 1
            else -> 0
        }
    }

    private fun observationSeverity(rainMm: Double, windKmh: Double): Int {
        var sev = 0
        if (!rainMm.isNaN()) {
            sev = when {
                rainMm >= 2.0 -> 2
                rainMm >= 0.2 -> 1
                else -> sev
            }
        }
        if (!windKmh.isNaN()) {
            sev = max(sev, when {
                windKmh >= 45 -> 2
                windKmh >= 30 -> 1
                else -> 0
            })
        }
        return sev
    }

    private fun modelSeverity(prob: Double, rainMm: Double, gustKmh: Double): Int {
        return when {
            (!prob.isNaN() && prob >= 70) || (!rainMm.isNaN() && rainMm >= 4.0) || (!gustKmh.isNaN() && gustKmh >= 55) -> 2
            (!prob.isNaN() && prob >= 40) || (!rainMm.isNaN() && rainMm >= 1.0) || (!gustKmh.isNaN() && gustKmh >= 40) -> 1
            else -> 0
        }
    }

    private fun getJson(urlText: String): JSONObject {
        val conn = (URL(urlText).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 9000
            readTimeout = 12000
            setRequestProperty("User-Agent", "HiRider/0.5 Android")
            setRequestProperty("Accept", "application/json")
        }
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return JSONObject(text)
        } finally {
            conn.disconnect()
        }
    }

    // ---------------------- Display helpers ----------------------

    private fun forecastDisplay(raw: String): String {
        if (!isZh) return raw
        val s = raw.lowercase(Locale.ROOT)
        return when {
            s.contains("thundery") -> "雷阵雨"
            s.contains("heavy rain") -> "大雨"
            s.contains("moderate rain") -> "中雨"
            s.contains("light rain") -> "小雨"
            s.contains("showers") -> "阵雨"
            s.contains("partly cloudy") -> "局部多云"
            s.contains("cloudy") -> "多云"
            s.contains("fair") -> "晴朗"
            s.contains("windy") -> "有风"
            else -> raw
        }
    }

    private fun advice(severity: Int): String = when (severity) {
        2 -> t("Not recommended", "不建议")
        1 -> t("Monitor first", "先观察")
        else -> t("Good to go", "可以出发")
    }

    private fun confidenceLabel(value: String): String = when (value) {
        "High" -> t("High", "高")
        "Medium" -> t("Medium", "中")
        else -> t("Low", "低")
    }

    private fun blockLabel(time: ZonedDateTime): String = time.format(DateTimeFormatter.ofPattern("h a", Locale.US))

    private fun areaLabel(a: AreaDef): String = if (isZh) a.zh else a.name

    private fun formatApiTime(raw: String): String {
        return runCatching {
            ZonedDateTime.parse(raw).withZoneSameInstant(zone).format(DateTimeFormatter.ofPattern("HH:mm"))
        }.getOrElse { raw.takeLast(8).take(5).ifBlank { raw } }
    }

    private fun num(v: Double): String = if (v.isNaN()) "—" else String.format(Locale.US, "%.1f", v)
    private fun num0(v: Double): String = if (v.isNaN()) "—" else String.format(Locale.US, "%.0f", v)
    private fun List<Double>.averageOrNaN(): Double = if (isEmpty()) Double.NaN else average()

    private fun label(s: String): TextView = TextView(this).apply {
        text = s
        textSize = 14f
        setTextColor(subTextColor)
        setPadding(0, 0, 0, dp(4))
    }

    private fun card(s: String): TextView = TextView(this).apply {
        text = s
        textSize = 16f
        setTextColor(textColor)
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(cardColor, 16f)
    }

    private fun rounded(color: Int, radiusDp: Float): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radiusDp.toInt()).toFloat()
        setColor(color)
    }

    private fun styleButton(button: Button) {
        button.setAllCaps(false)
        button.setTextColor(Color.WHITE)
        button.textSize = 15f
        button.backgroundTintList = ColorStateList.valueOf(if (isDark) Color.rgb(47, 128, 181) else accentColor)
        button.setPadding(dp(12), dp(9), dp(12), dp(9))
    }

    private fun marginTop(top: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
}
