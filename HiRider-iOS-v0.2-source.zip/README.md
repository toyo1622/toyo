# Hi Rider iOS v0.2

First functional iOS prototype for Hi Rider.

Included:
- Country-first flow: Singapore / Malaysia
- Singapore selected six regions:
  - Tampines
  - Pasir Ris
  - Bedok
  - Changi
  - Hougang
  - Punggol
- Malaysia locations from current Hi Rider v8 plan
- Real hourly forecast using Open-Meteo
- Temperature, rain probability, precipitation, weather code/icon, wind gust
- Time window keeps the useful riding hours and continues to 03:00
- Chinese / English switch
- Selection persistence with AppStorage
- No Apple signing required for GitHub Simulator build

Not yet included:
- Firebase Google login
- Firebase Phone OTP
- Notifications
- Multi-model confidence calculation
- Radar
- App Store signing / TestFlight
