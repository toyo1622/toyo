import SwiftUI

@main
struct HiRiderIOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
