import Foundation

@MainActor
final class WeatherViewModel: ObservableObject {
    @Published var hours: [HourlyWeather] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var lastUpdated: Date?

    private struct APIResponse: Decodable {
        let timezone: String
        let utc_offset_seconds: Int
        let hourly: HourlyData
    }

    private struct HourlyData: Decodable {
        let time: [String]
        let temperature_2m: [Double]
        let precipitation_probability: [Int]
        let precipitation: [Double]
        let weather_code: [Int]
        let wind_gusts_10m: [Double]
    }

    func load(region: WeatherRegion) async {
        isLoading = true
        errorMessage = nil

        defer { isLoading = false }

        var components = URLComponents(string: "https://api.open-meteo.com/v1/forecast")!
        components.queryItems = [
            URLQueryItem(name: "latitude", value: String(region.latitude)),
            URLQueryItem(name: "longitude", value: String(region.longitude)),
            URLQueryItem(name: "hourly", value: "temperature_2m,precipitation_probability,precipitation,weather_code,wind_gusts_10m"),
            URLQueryItem(name: "timezone", value: "auto"),
            URLQueryItem(name: "forecast_days", value: "2")
        ]

        guard let url = components.url else {
            errorMessage = "Invalid weather URL"
            return
        }

        do {
            let (data, response) = try await URLSession.shared.data(from: url)

            guard let http = response as? HTTPURLResponse,
                  (200...299).contains(http.statusCode) else {
                throw URLError(.badServerResponse)
            }

            let decoded = try JSONDecoder().decode(APIResponse.self, from: data)
            let calendar = Calendar(identifier: .gregorian)

            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "en_US_POSIX")
            formatter.dateFormat = "yyyy-MM-dd'T'HH:mm"
            formatter.timeZone = TimeZone(secondsFromGMT: decoded.utc_offset_seconds)

            let tz = TimeZone(secondsFromGMT: decoded.utc_offset_seconds) ?? .current
            let now = Date()
            var localCalendar = calendar
            localCalendar.timeZone = tz

            let currentHour = localCalendar.date(bySetting: .minute, value: 0, of: now) ?? now
            let currentHourValue = localCalendar.component(.hour, from: now)

            let todayStart = localCalendar.startOfDay(for: now)
            let start: Date
            let end: Date

            if currentHourValue <= 3 {
                start = currentHour
                end = localCalendar.date(bySettingHour: 3, minute: 0, second: 0, of: todayStart) ?? now
            } else if currentHourValue < 6 {
                start = localCalendar.date(bySettingHour: 6, minute: 0, second: 0, of: todayStart) ?? now
                let tomorrow = localCalendar.date(byAdding: .day, value: 1, to: todayStart) ?? now
                end = localCalendar.date(bySettingHour: 3, minute: 0, second: 0, of: tomorrow) ?? tomorrow
            } else {
                start = currentHour
                let tomorrow = localCalendar.date(byAdding: .day, value: 1, to: todayStart) ?? now
                end = localCalendar.date(bySettingHour: 3, minute: 0, second: 0, of: tomorrow) ?? tomorrow
            }

            let count = min(
                decoded.hourly.time.count,
                decoded.hourly.temperature_2m.count,
                decoded.hourly.precipitation_probability.count,
                decoded.hourly.precipitation.count,
                decoded.hourly.weather_code.count,
                decoded.hourly.wind_gusts_10m.count
            )

            var parsed: [HourlyWeather] = []
            for index in 0..<count {
                guard let date = formatter.date(from: decoded.hourly.time[index]) else { continue }
                guard date >= start && date <= end else { continue }

                parsed.append(
                    HourlyWeather(
                        time: date,
                        temperature: decoded.hourly.temperature_2m[index],
                        rainProbability: decoded.hourly.precipitation_probability[index],
                        precipitation: decoded.hourly.precipitation[index],
                        weatherCode: decoded.hourly.weather_code[index],
                        windGust: decoded.hourly.wind_gusts_10m[index]
                    )
                )
            }

            hours = parsed
            lastUpdated = Date()
        } catch {
            errorMessage = error.localizedDescription
            hours = []
        }
    }
}
