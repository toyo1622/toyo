import Foundation

enum AppLanguage: String, CaseIterable, Identifiable {
    case zh
    case en

    var id: String { rawValue }

    var title: String {
        switch self {
        case .zh: return "中文"
        case .en: return "English"
        }
    }
}

enum Country: String, CaseIterable, Identifiable {
    case singapore = "Singapore"
    case malaysia = "Malaysia"

    var id: String { rawValue }

    func displayName(_ language: AppLanguage) -> String {
        switch (self, language) {
        case (.singapore, .zh): return "新加坡"
        case (.singapore, .en): return "Singapore"
        case (.malaysia, .zh): return "马来西亚"
        case (.malaysia, .en): return "Malaysia"
        }
    }
}

struct WeatherRegion: Identifiable, Hashable {
    let id: String
    let country: Country
    let group: String
    let nameEN: String
    let nameZH: String
    let latitude: Double
    let longitude: Double

    func displayName(_ language: AppLanguage) -> String {
        language == .zh ? nameZH : nameEN
    }
}

enum RegionCatalog {
    static let all: [WeatherRegion] = [
        // Singapore — selected six regions
        .init(id: "sg-tampines", country: .singapore, group: "Singapore", nameEN: "Tampines", nameZH: "淡滨尼", latitude: 1.3521, longitude: 103.9442),
        .init(id: "sg-pasir-ris", country: .singapore, group: "Singapore", nameEN: "Pasir Ris", nameZH: "巴西立", latitude: 1.3730, longitude: 103.9493),
        .init(id: "sg-bedok", country: .singapore, group: "Singapore", nameEN: "Bedok", nameZH: "勿洛", latitude: 1.3236, longitude: 103.9273),
        .init(id: "sg-changi", country: .singapore, group: "Singapore", nameEN: "Changi", nameZH: "樟宜", latitude: 1.3644, longitude: 103.9915),
        .init(id: "sg-hougang", country: .singapore, group: "Singapore", nameEN: "Hougang", nameZH: "后港", latitude: 1.3712, longitude: 103.8924),
        .init(id: "sg-punggol", country: .singapore, group: "Singapore", nameEN: "Punggol", nameZH: "榜鹅", latitude: 1.4043, longitude: 103.9020),

        // Johor
        .init(id: "my-jb", country: .malaysia, group: "Johor", nameEN: "Johor Bahru", nameZH: "新山", latitude: 1.4927, longitude: 103.7414),
        .init(id: "my-kulai", country: .malaysia, group: "Johor", nameEN: "Kulai", nameZH: "古来", latitude: 1.6561, longitude: 103.6032),
        .init(id: "my-pontian", country: .malaysia, group: "Johor", nameEN: "Pontian", nameZH: "笨珍", latitude: 1.4860, longitude: 103.3890),
        .init(id: "my-kota-tinggi", country: .malaysia, group: "Johor", nameEN: "Kota Tinggi", nameZH: "哥打丁宜", latitude: 1.7381, longitude: 103.8999),
        .init(id: "my-kluang", country: .malaysia, group: "Johor", nameEN: "Kluang", nameZH: "居銮", latitude: 2.0251, longitude: 103.3328),
        .init(id: "my-batu-pahat", country: .malaysia, group: "Johor", nameEN: "Batu Pahat", nameZH: "峇株巴辖", latitude: 1.8548, longitude: 102.9325),
        .init(id: "my-yong-peng", country: .malaysia, group: "Johor", nameEN: "Yong Peng", nameZH: "永平", latitude: 2.0136, longitude: 103.0659),
        .init(id: "my-muar", country: .malaysia, group: "Johor", nameEN: "Muar", nameZH: "麻坡", latitude: 2.0442, longitude: 102.5689),
        .init(id: "my-tangkak", country: .malaysia, group: "Johor", nameEN: "Tangkak", nameZH: "东甲", latitude: 2.2673, longitude: 102.5453),
        .init(id: "my-segamat", country: .malaysia, group: "Johor", nameEN: "Segamat", nameZH: "昔加末", latitude: 2.5148, longitude: 102.8158),
        .init(id: "my-mersing", country: .malaysia, group: "Johor", nameEN: "Mersing", nameZH: "丰盛港", latitude: 2.4312, longitude: 103.8405),

        // Kuala Lumpur / Selangor / Putrajaya
        .init(id: "my-kl", country: .malaysia, group: "KL / Selangor / Putrajaya", nameEN: "Kuala Lumpur", nameZH: "吉隆坡", latitude: 3.1390, longitude: 101.6869),
        .init(id: "my-pj", country: .malaysia, group: "KL / Selangor / Putrajaya", nameEN: "Petaling Jaya", nameZH: "八打灵再也", latitude: 3.1073, longitude: 101.6067),
        .init(id: "my-shah-alam", country: .malaysia, group: "KL / Selangor / Putrajaya", nameEN: "Shah Alam", nameZH: "莎阿南", latitude: 3.0733, longitude: 101.5185),
        .init(id: "my-subang-jaya", country: .malaysia, group: "KL / Selangor / Putrajaya", nameEN: "Subang Jaya", nameZH: "梳邦再也", latitude: 3.0438, longitude: 101.5806),
        .init(id: "my-klang", country: .malaysia, group: "KL / Selangor / Putrajaya", nameEN: "Klang", nameZH: "巴生", latitude: 3.0430, longitude: 101.4450),
        .init(id: "my-kajang", country: .malaysia, group: "KL / Selangor / Putrajaya", nameEN: "Kajang", nameZH: "加影", latitude: 2.9935, longitude: 101.7874),
        .init(id: "my-serdang", country: .malaysia, group: "KL / Selangor / Putrajaya", nameEN: "Serdang", nameZH: "沙登", latitude: 3.0278, longitude: 101.7067),
        .init(id: "my-cyberjaya", country: .malaysia, group: "KL / Selangor / Putrajaya", nameEN: "Cyberjaya", nameZH: "赛城", latitude: 2.9213, longitude: 101.6559),
        .init(id: "my-putrajaya", country: .malaysia, group: "KL / Selangor / Putrajaya", nameEN: "Putrajaya", nameZH: "布城", latitude: 2.9264, longitude: 101.6964)
    ]

    static func regions(for country: Country) -> [WeatherRegion] {
        all.filter { $0.country == country }
    }
}

struct HourlyWeather: Identifiable {
    let id = UUID()
    let time: Date
    let temperature: Double
    let rainProbability: Int
    let precipitation: Double
    let weatherCode: Int
    let windGust: Double

    var symbolName: String {
        switch weatherCode {
        case 0: return "sun.max.fill"
        case 1, 2: return "cloud.sun.fill"
        case 3: return "cloud.fill"
        case 45, 48: return "cloud.fog.fill"
        case 51...67: return "cloud.drizzle.fill"
        case 71...77: return "cloud.snow.fill"
        case 80...82: return "cloud.heavyrain.fill"
        case 85, 86: return "cloud.snow.fill"
        case 95...99: return "cloud.bolt.rain.fill"
        default: return "cloud.fill"
        }
    }
}
