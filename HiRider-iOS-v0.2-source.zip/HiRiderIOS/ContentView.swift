import SwiftUI

struct ContentView: View {
    @AppStorage("language") private var languageRaw = AppLanguage.zh.rawValue
    @AppStorage("selectedCountry") private var selectedCountryRaw = Country.singapore.rawValue
    @AppStorage("selectedRegionID") private var selectedRegionID = "sg-tampines"

    @StateObject private var weather = WeatherViewModel()

    private var language: AppLanguage {
        get { AppLanguage(rawValue: languageRaw) ?? .zh }
        nonmutating set { languageRaw = newValue.rawValue }
    }

    private var country: Country {
        get { Country(rawValue: selectedCountryRaw) ?? .singapore }
        nonmutating set {
            selectedCountryRaw = newValue.rawValue
            if let first = RegionCatalog.regions(for: newValue).first {
                selectedRegionID = first.id
            }
        }
    }

    private var availableRegions: [WeatherRegion] {
        RegionCatalog.regions(for: country)
    }

    private var selectedRegion: WeatherRegion {
        availableRegions.first(where: { $0.id == selectedRegionID })
        ?? availableRegions.first
        ?? RegionCatalog.all[0]
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    header

                    countryCard
                    regionCard
                    currentWeatherCard
                    hourlyCard
                }
                .padding()
            }
            .navigationTitle("Hi Rider")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button("中文") { languageRaw = AppLanguage.zh.rawValue }
                        Button("English") { languageRaw = AppLanguage.en.rawValue }
                    } label: {
                        Label(language.title, systemImage: "globe")
                    }
                }
            }
            .task {
                await weather.load(region: selectedRegion)
            }
            .onChange(of: selectedRegionID) { _, _ in
                Task { await weather.load(region: selectedRegion) }
            }
        }
    }

    private var header: some View {
        VStack(spacing: 8) {
            Image(systemName: "cloud.bolt.rain.fill")
                .font(.system(size: 52))
                .symbolRenderingMode(.multicolor)

            Text(language == .zh ? "骑士天气" : "Rider Weather")
                .font(.title2.bold())

            Text(language == .zh
                 ? "小时天气 · 看到凌晨 3 点"
                 : "Hourly weather · through 3 AM")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .padding(.top, 8)
    }

    private var countryCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(language == .zh ? "国家" : "Country")
                .font(.headline)

            Picker(language == .zh ? "国家" : "Country",
                   selection: Binding(
                    get: { country },
                    set: { country = $0 }
                   )) {
                ForEach(Country.allCases) { item in
                    Text(item.displayName(language)).tag(item)
                }
            }
            .pickerStyle(.segmented)
        }
        .cardStyle()
    }

    private var regionCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(language == .zh ? "地区" : "Area")
                .font(.headline)

            Picker(language == .zh ? "选择地区" : "Select area",
                   selection: $selectedRegionID) {
                ForEach(availableRegions) { region in
                    Text(region.displayName(language)).tag(region.id)
                }
            }
            .pickerStyle(.menu)

            Text(selectedRegion.displayName(language))
                .font(.title3.bold())
        }
        .cardStyle()
    }

    @ViewBuilder
    private var currentWeatherCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(language == .zh ? "现在 / 最近一小时" : "Now / nearest hour")
                    .font(.headline)
                Spacer()

                if weather.isLoading {
                    ProgressView()
                }
            }

            if let first = weather.hours.first {
                HStack(spacing: 14) {
                    Image(systemName: first.symbolName)
                        .font(.system(size: 44))
                        .symbolRenderingMode(.multicolor)

                    VStack(alignment: .leading, spacing: 4) {
                        Text("\(Int(first.temperature.rounded()))°C")
                            .font(.largeTitle.bold())
                        Text((language == .zh ? "下雨概率 " : "Rain ") + "\(first.rainProbability)%")
                            .foregroundStyle(.secondary)
                    }

                    Spacer()

                    VStack(alignment: .trailing, spacing: 4) {
                        Text(String(format: "%.1f mm", first.precipitation))
                        Text(language == .zh
                             ? "阵风 \(Int(first.windGust.rounded())) km/h"
                             : "Gust \(Int(first.windGust.rounded())) km/h")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
            } else if let error = weather.errorMessage {
                Label(error, systemImage: "exclamationmark.triangle.fill")
                    .foregroundStyle(.orange)
            } else if !weather.isLoading {
                Text(language == .zh ? "暂时没有天气资料" : "No weather data available")
                    .foregroundStyle(.secondary)
            }
        }
        .cardStyle()
    }

    private var hourlyCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(language == .zh ? "小时天气" : "Hourly weather")
                    .font(.headline)

                Spacer()

                Button {
                    Task { await weather.load(region: selectedRegion) }
                } label: {
                    Image(systemName: "arrow.clockwise")
                }
                .disabled(weather.isLoading)
            }

            if weather.hours.isEmpty && weather.isLoading {
                HStack {
                    Spacer()
                    ProgressView()
                    Spacer()
                }
                .padding(.vertical, 16)
            } else {
                ForEach(weather.hours) { hour in
                    HourlyRow(hour: hour, language: language)

                    if hour.id != weather.hours.last?.id {
                        Divider()
                    }
                }
            }

            if let updated = weather.lastUpdated {
                Text((language == .zh ? "更新：" : "Updated: ") + updated.formatted(date: .omitted, time: .shortened))
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .trailing)
            }
        }
        .cardStyle()
    }
}

private struct HourlyRow: View {
    let hour: HourlyWeather
    let language: AppLanguage

    var body: some View {
        HStack(spacing: 12) {
            Text(hour.time.formatted(date: .omitted, time: .shortened))
                .font(.system(.body, design: .rounded).monospacedDigit())
                .frame(width: 74, alignment: .leading)

            Image(systemName: hour.symbolName)
                .font(.title3)
                .symbolRenderingMode(.multicolor)
                .frame(width: 30)

            VStack(alignment: .leading, spacing: 2) {
                Text("\(Int(hour.temperature.rounded()))°C")
                    .font(.headline)

                Text(language == .zh
                     ? "雨 \(hour.rainProbability)% · \(String(format: "%.1f", hour.precipitation)) mm"
                     : "Rain \(hour.rainProbability)% · \(String(format: "%.1f", hour.precipitation)) mm")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Text(language == .zh
                 ? "阵风 \(Int(hour.windGust.rounded()))"
                 : "G \(Int(hour.windGust.rounded()))")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 2)
    }
}

private extension View {
    func cardStyle() -> some View {
        self
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18))
    }
}

#Preview {
    ContentView()
}
