package com.eastweather.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/**
 * Checks the small, publicly hosted update manifest without requesting a login,
 * phone number, push token, SMS permission, or access to Firebase user records.
 *
 * Publish a *tested*, permanently signed APK first. Only then raise the
 * manifest's versionCode and update its download URL.
 */
object HiRiderUpdateChecker {
    private const val MANIFEST_URL =
        "https://raw.githubusercontent.com/toyo1622/toyo/main/hirider-update.json"

    fun check(activity: Activity, isZh: Boolean, manual: Boolean = false) {
        thread(name = "hirider-update-check") {
            val result = runCatching {
                val connection = URL(MANIFEST_URL).openConnection() as HttpURLConnection
                connection.connectTimeout = 6000
                connection.readTimeout = 6000
                connection.setRequestProperty("Accept", "application/json")
                connection.setRequestProperty("Cache-Control", "no-cache")
                try {
                    if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                        error("Unexpected update response: ${connection.responseCode}")
                    }
                    val json = connection.inputStream.bufferedReader(Charsets.UTF_8).use {
                        JSONObject(it.readText())
                    }
                    val latestCode = json.getLong("versionCode")
                    val currentCode = installedVersionCode(activity)
                    if (latestCode <= currentCode) null else json
                } finally {
                    connection.disconnect()
                }
            }

            activity.runOnUiThread {
                if (activity.isFinishing || activity.isDestroyed) return@runOnUiThread
                result.onSuccess { update ->
                    if (update == null) {
                        if (manual) Toast.makeText(
                            activity,
                            if (isZh) "已经是最新版本" else "You're using the latest version",
                            Toast.LENGTH_LONG
                        ).show()
                        return@onSuccess
                    }

                    val url = update.optString("apkUrl")
                    val uri = Uri.parse(url)
                    // Never open an arbitrary URL from remotely editable JSON.
                    if (uri.scheme != "https" || uri.host != "github.com" ||
                        !uri.path.orEmpty().startsWith("/toyo1622/toyo/releases/")) {
                        if (manual) Toast.makeText(
                            activity,
                            if (isZh) "升级链接无效" else "Invalid update link",
                            Toast.LENGTH_LONG
                        ).show()
                        return@onSuccess
                    }

                    val latestName = update.optString("versionName", "new")
                    val notes = update.optString(if (isZh) "notesZh" else "notesEn")
                    val message = if (isZh) {
                        "Hi Rider $latestName 已发布。\n\n" +
                            (if (notes.isBlank()) "下载安装新版后，直接覆盖旧版即可。" else notes) +
                            "\n\n按「下载升级」，浏览器会打开 APK 下载链接。"
                    } else {
                        "Hi Rider $latestName is available.\n\n" +
                            (if (notes.isBlank()) "Install over the existing app." else notes) +
                            "\n\nTap Download update to open the APK download in your browser."
                    }
                    AlertDialog.Builder(activity)
                        .setTitle(if (isZh) "发现新版本" else "Update available")
                        .setMessage(message)
                        .setNegativeButton(if (isZh) "稍后" else "Later", null)
                        .setPositiveButton(if (isZh) "下载升级" else "Download update") { _, _ ->
                            runCatching {
                                activity.startActivity(Intent(Intent.ACTION_VIEW, uri))
                            }.onFailure {
                                Toast.makeText(
                                    activity,
                                    if (isZh) "无法打开下载链接" else "Can't open download link",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                        .show()
                }.onFailure {
                    // Startup must never be blocked by a failed network request.
                    if (manual) Toast.makeText(
                        activity,
                        if (isZh) "暂时无法检查更新，请稍后再试" else "Can't check for updates right now",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun installedVersionCode(activity: Activity): Long {
        val info = activity.packageManager.getPackageInfo(activity.packageName, 0)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.longVersionCode
        } else {
            info.versionCode.toLong()
        }
    }
}
